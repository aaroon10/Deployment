using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using crmDataImporter.Business;
using crmDataImporter.Service.Business;
using LumenWorks.Framework.IO.Csv;
using System.IO;
using Newtonsoft.Json;

namespace DataImporter
{
    public static class DataImporter
    {
        //[Disable]
        [FunctionName("DataImporter")]
        public static void Run([TimerTrigger("0 */1 * * * *")]TimerInfo myTimer, TraceWriter log)
        {
            //System.Configuration.ConfigurationManager.AppSettings.Get("abc");

            //var lobj = JsonConvert.DeserializeObject(System.Configuration.ConfigurationManager.AppSettings.Get("abc"));
            //System.Configuration.ConfigurationManager.GetSection("Data");

            var lobjImport = new crmDataImporter.Service.Business.ImportFactory();
            lobjImport.PollDBs(1);
            lobjImport.ProcessQueue(1);

            //try
            //{
            //    string lsPath = @"C:\\Users\\Mark\\Documents\\NInumber2.txt";

            //    var myCsv = new LumenWorks.Framework.IO.Csv.CsvReader(new System.IO.StreamReader(lsPath.ToString()), true, ',');
            //    myCsv.ReadNextRecord();
            //}
            //catch (Exception ex)
            //{
            //    log.Error(ex.ToString());
            //}



            //_myCsv = New LumenWorks.Framework.IO.Csv.CsvReader(New IO.StreamReader(_filePath), _hasHeaders, _delimiter)
            //_myCsv.DefaultParseErrorAction = LumenWorks.Framework.IO.Csv.ParseErrorAction.ThrowException
            //_myCsv.MissingFieldAction = LumenWorks.Framework.IO.Csv.MissingFieldAction.ReplaceByNull
            //_myCsv.SupportsMultiline = True

            log.Info($"C# Timer trigger function executed at: {DateTime.Now}");
        }
    }
}
