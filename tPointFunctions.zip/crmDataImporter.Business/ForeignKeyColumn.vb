Imports crmRepositoryWeb.Classes
Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' Defines a foreign key relationship
''' </summary>
<Serializable()> _
Public Class ForeignKeyColumn
    Implements crmDataImporter.Business.IDatabaseObject

#Region " Fields "

    Private _Id, _CreatedBy, _UpdatedBy, _ComponentFieldId As Integer
    Private _Created, _Updated As Date
    Private _SourceField As String

#End Region

#Region " Properties "

    Private ReadOnly Property UserId() As Integer
        Get
            Return clsCookieHelper.CurrentEmployeeId
        End Get
    End Property


    ''' <summary>
    ''' Unique identifier for the key
    ''' </summary>
    Public Property Id() As Integer Implements IDatabaseObject.Id
        Get
            Return _Id
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Id = Value
        End Set
    End Property

    ''' <summary>
    ''' Not implemented
    ''' </summary>
    <Xml.Serialization.XmlIgnore()> _
    Public Property Name() As String Implements IDatabaseObject.Name
        Get
            Throw New NotImplementedException
        End Get
        Set(ByVal Value As String)
            Throw New NotImplementedException
        End Set
    End Property

    ''' <summary>
    ''' The date that the key was created
    ''' </summary>
    Public Property Created() As Date Implements IDatabaseObject.Created
        Get
            Return _Created
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Created = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the user who created the key
    ''' </summary>
    Public Property CreatedBy() As Integer Implements IDatabaseObject.CreatedBy
        Get
            Return _CreatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _CreatedBy = Value
        End Set
    End Property

    ''' <summary>
    ''' The date that the key was updated
    ''' </summary>
    Public Property Updated() As Date Implements IDatabaseObject.Updated
        Get
            Return _Updated
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Updated = Value
        End Set
    End Property

    ''' <summary>
    ''' The user id of the person who updated the key
    ''' </summary>
    Public Property UpdatedBy() As Integer Implements IDatabaseObject.UpdatedBy
        Get
            Return _UpdatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _UpdatedBy = Value
        End Set
    End Property


    ''' <summary>
    ''' The id of the field in the primary component for the key to relate back to
    ''' </summary>
    Public Property ComponentFieldId() As Integer
        Get
            Return _ComponentFieldId
        End Get
        Set(ByVal Value As Integer)
            _ComponentFieldId = Value
        End Set
    End Property

    ''' <summary>
    ''' The name of the source field used for the key
    ''' </summary>
    Public Property SourceField() As String
        Get
            Return _SourceField
        End Get
        Set(ByVal Value As String)
            _SourceField = Value
        End Set
    End Property

#End Region

#Region " Methods "

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Load a key from a DataRow
    ''' </summary>
    Public Sub New(ByVal loadFromRow As DataRow)
        Me.Load(loadFromRow)
    End Sub

    ''' <summary>
    ''' Create a new key for the specified component field id and source field
    ''' </summary>
    Public Sub New(ByVal componentField As Integer, ByVal sourceField As String)
        _ComponentFieldId = componentField
        _SourceField = sourceField
    End Sub

    ''' <summary>
    ''' Load a key from a DataRow
    ''' </summary>
    Public Sub Load(ByVal fromRow As DataRow)
        _Id = fromRow.Item("Id")
        _Created = fromRow.Item("Created")
        _CreatedBy = fromRow.Item("CreatedBy")
        _Updated = fromRow.Item("Updated")
        _CreatedBy = fromRow.Item("CreatedBy")
        _ComponentFieldId = fromRow.Item("CompFieldId")
        _SourceField = fromRow.Item("SourceField")
    End Sub

    ''' <summary>
    ''' Save the key to the database
    ''' </summary>
    Public Sub Save(ByVal forMapping As Integer)
        Dim params(5) As SqlClient.SqlParameter

        params(0) = New SqlClient.SqlParameter("@@Id", Me.Id)

        If Me.Id.Equals(0) Then _
            params(1) = New SqlClient.SqlParameter("@@CreatedBy", Me.UserId)

        params(2) = New SqlClient.SqlParameter("@@UpdatedBy", Me.UserId)
        params(3) = New SqlClient.SqlParameter("@@MappingId", forMapping)
        params(4) = New SqlClient.SqlParameter("@@CompFieldId", Me.ComponentFieldId)
        params(5) = New SqlClient.SqlParameter("@@SourceField", Me.SourceField)

        Dim returnId As Integer = SqlHelper.ExecuteScalar(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_SaveForeignKey", params)

        If Not Me.Id.Equals(returnId) Then _
            _Id = returnId
    End Sub

#End Region

End Class
