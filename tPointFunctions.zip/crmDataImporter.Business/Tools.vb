Imports Microsoft.ApplicationBlocks.Data

Public Class Tools

    'INCOMPLETE
    Public Shared Function JobListViewId() As Integer
        Dim viewId As Integer = SqlHelper.ExecuteScalar(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.Text, "select id from g_view where name = 'APP - Data Import Jobs List' and busObjId = (select id from g_busobj where name = 'APP - Data Import Job')")

        If viewId.Equals(0) Then _
            Throw New Exception("CRITICAL - Configuration for Data Imports not found!")

        Return viewId
    End Function

    'INCOMPLETE
    Public Shared Function JobFormViewId() As Integer
        Dim viewId As Integer = SqlHelper.ExecuteScalar(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.Text, "select id from g_view where name = 'App - Data Import Job Form' and busObjId = (select id from g_busobj where name = 'APP - Data Import Job')")

        If viewId.Equals(0) Then _
            Throw New Exception("CRITICAL - Configuration for Data Imports not found!")

        Return viewId
    End Function

    'INCOMPLETE
    Public Shared Function PackageListViewId()
        Dim viewId As Integer = SqlHelper.ExecuteScalar(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.Text, "select id from g_view where name = 'APP - Data Import Headers List' and busObjId = (select id from g_busobj where name = 'APP - Data Import')")

        If viewId.Equals(0) Then _
            Throw New Exception("CRITICAL - Configuration for Data Imports not found!")

        Return viewId
    End Function

    'INCOMPLETE
    Public Shared Sub BindBusObjectsToList(ByRef list As Web.UI.WebControls.DropDownList)
        Dim busObjects As DataSet = SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.Text, "select id, name from g_busObj order by name")
        crmRepositoryWeb.Classes.clsHelper.BindList(busObjects, list)
        busObjects.Dispose()
    End Sub

    'INCOMPLETE
    Public Shared Sub BindBusObjectsToListReportsOnly(ByRef list As Web.UI.WebControls.DropDownList)
        Dim objectBase As New crmRepository.clsObjectBase
        objectBase.strConn = crmRepositoryWeb.Classes.clsHelper.strConn
        crmRepositoryWeb.Classes.clsHelper.BindList(objectBase.listBOreports, list, True, "reportName")
    End Sub

    'INCOMPLETE
    Public Shared Function ExistingImportId(ByVal withName As String) As Integer
        Return SqlHelper.ExecuteScalar(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.Text, "select id from g_DataImport_Header where name = @@name", New SqlClient.SqlParameter("@@name", withName))
    End Function

    'INCOMPLETE
    Public Shared Function RawJobData(ByVal forJobId As Integer, ByVal IsExport As Boolean) As DataSet

        If (IsExport) Then
            Return SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, _
                                                CommandType.Text, _
                                                "select * from g_DataExport_Job jb inner join g_DataExport_DataFile fl on jb.DiskFileId=fl.id where jb.Id = @JobId", _
                                                New SqlClient.SqlParameter("@JobId", forJobId))
        Else
            Return SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, _
                                                CommandType.Text, _
                                                "select * from g_DataImport_Job where Id = @JobId", _
                                                New SqlClient.SqlParameter("@JobId", forJobId))
        End If

    End Function

    'INCOMPLETE
    Public Shared Function ComponentReportName(ByVal componentId As Integer) As String
        Dim reportName As Object = SqlHelper.ExecuteScalar(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.Text, "select reportName from g_busComp where id = @@id", New SqlClient.SqlParameter("@@id", componentId))

        If Not IsDBNull(reportName) AndAlso Not IsNothing(reportName) Then _
            Return reportName
        Return String.Empty
    End Function

    'INCOMPLETE
    Public Shared Function ComponentsByReportName(ByVal forObject As Integer) As DataSet
        Return SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.Text, _
                        "select g_BusComp.id, g_busComp.name, g_BusComp.reportName from g_BusComp inner join g_busObjBusComp on g_BusComp.id = g_busObjBusComp.busCompId where not nullif(g_busComp.reportName, '') is null and g_busObjBusComp.busObjId = @@selectedId order by g_busComp.reportName", _
                        New SqlClient.SqlParameter("@@selectedId", forObject))
    End Function

    Public Function List(ByVal teamIdList As String) As DataSet
        Try
            'Dim colParam() As SqlClient.SqlParameter
            'Dim objda As Microsoft.ApplicationBlocks.Data.SqlHelper
            If teamIdList = "" Then
                Return Nothing
            End If
            Dim sql As String
            sql = "SELECT distinct u_campaignHdr.id, u_campaignHdr.Name, diallerType ,isnull(attINT04,0) as branchScriptId, isnull(attBIT01,0) as demo, isnull(attTXT01,'') as method FROM u_campaignHdr INNER JOIN " & _
                  "u_objectTeam ON u_campaignHdr.id = u_objectTeam.objectId " & _
                  "WHERE     (u_objectTeam.objectType = 3) AND (u_objectTeam.teamId IN (" & teamIdList & ")) AND u_campaignHdr.endDate >= getDate() " & _
                  " AND u_campaignHdr.startDate <= getDate()" & _
                  " ORDER BY u_campaignHdr.Name"
            Return Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.Text, sql)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

End Class
