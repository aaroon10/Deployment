Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' Provides collection storage for ForeignKey objects
''' </summary>
<Serializable()> _
Public Class StaticFieldCollection
    Inherits crmDataImporter.Business.MappedFieldCollection

    ''' <summary>
    ''' Loads a collection for the specified parent mapping
    ''' </summary>
    Public Sub New(ByVal forParent As crmDataImporter.Business.DataMapping)
        MyBase.New(forParent)
    End Sub

    ''' <summary>
    ''' Not implemented
    ''' </summary>
    Public Overrides Function ContainsCompletePath() As Boolean
        Throw New NotImplementedException
    End Function

    ''' <summary>
    ''' Loads the collection with saved static fields for a mapping
    ''' </summary>
    Public Overrides Sub LoadFromDb(ByVal ParentMapping As crmDataImporter.Business.DataMapping)
        MyBase.ParentMappingId = ParentMapping.Id

        Dim rawData As DataSet = SqlHelper.ExecuteDataset(ParentMapping.ConnectionString, CommandType.StoredProcedure, "g_DataImport_StaticField_GetCollectionv2", _
                                                                    New SqlClient.SqlParameter("@@MappingId", MyBase.ParentMappingId))

        If Not IsNothing(rawData) AndAlso Not IsNothing(rawData.Tables) AndAlso Not rawData.Tables(0).Rows.Count.Equals(0) Then

            For Each fieldRow As DataRow In rawData.Tables(0).Rows
                Me.Add(New crmDataImporter.Business.MappedField(fieldRow))
            Next

            rawData.Dispose()
        End If
    End Sub

    Public Overrides Sub Save()
        'drop saved fields first, unfortunately making the created/by fields fairly meaningless
        SqlHelper.ExecuteNonQuery(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_DeleteStaticFields", _
                                                                    New SqlClient.SqlParameter("@@MappingId", Me.ParentMappingId))

        'save each stored field
        For Each myField As crmDataImporter.Business.MappedField In Me
            myField.Save(Me.ParentMappingId)
        Next
    End Sub

End Class
