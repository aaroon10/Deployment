
''' <summary>
''' Some basic things that help keep objects consistent
''' </summary>
Public Interface IDatabaseObject

    Property Id() As Integer
    Property Name() As String
    Property Created() As Date
    Property CreatedBy() As Integer
    Property Updated() As Date
    Property UpdatedBy() As Integer

End Interface
