Imports crmRepositoryWeb.Classes
Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' The main object for holding data import configuration
''' </summary>
<Serializable()>
Public Class DataImport
    Implements IDisposable
    Implements crmDataImporter.Business.IDatabaseObject

#Region " Fields "

    Private _Created, _Updated As Date
    Private _VerifyFileIntegrity, _HasHeaders As Boolean
    Private _Name, _SourceColumns(), _ConnectionString, _FileId As String
    Private _Id, _CreatedBy, _UpdatedBy, _DestinationObjectId, _CampaignId As Integer
    Private _DataMappings As crmDataImporter.Business.DataMappingCollection
    Private _ErrorOption As crmDataImporter.Business.Enums.ErrorOption
    Private _DupeOption As crmDataImporter.Business.Enums.DuplicationOption
    Private _DiallerExport As crmDataImporter.Business.Enums.DiallerTypes
    Private _Jobs As JobCollection
    Private _StructureFile As DataSource
    Private _ToPurge As ArrayList
    Private _DiallerExportConfig_raw As String
    Private _DiallerProvider As API.HostedDialler
    Private _Delimiter As Char

#End Region

#Region " Properties "

    Private ReadOnly Property UserId() As Integer
        Get
            If IsNothing(Web.HttpContext.Current) Then _
                 Return Me.UpdatedBy
            Return clsCookieHelper.CurrentEmployeeId
        End Get
    End Property

    Public Property FileId() As String
        Get
            Return _FileId
        End Get
        Set(ByVal Value As String)
            _FileId = Value
        End Set
    End Property

    Public Property HasHeaders() As Boolean
        Get
            Return _HasHeaders
        End Get
        Set(ByVal Value As Boolean)
            _HasHeaders = Value
        End Set
    End Property

    Public Property Delimiter() As Char
        Get
            Return _Delimiter
        End Get
        Set(ByVal Value As Char)
            _Delimiter = Value
        End Set
    End Property

    'INCOMPLETE

    Public Property ConnectionString() As String
        Get
            If IsNothing(_ConnectionString) OrElse _ConnectionString.Equals(String.Empty) Then _
                Return crmRepositoryWeb.Classes.clsHelper.strConn()

            Return _ConnectionString
        End Get
        Set(ByVal Value As String)
            _ConnectionString = Value
        End Set
    End Property

    ''' <summary>
    ''' Unique identifier for the import
    ''' </summary>
    Public Property Id() As Integer Implements crmDataImporter.Business.IDatabaseObject.Id
        Get
            Return _Id
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Id = Value
        End Set
    End Property

    ''' <summary>
    ''' The name given to the import
    ''' </summary>
    Public Property Name() As String Implements crmDataImporter.Business.IDatabaseObject.Name
        Get
            Return _Name
        End Get
        Set(ByVal Value As String)
            _Name = Value
        End Set
    End Property

    ''' <summary>
    ''' The date that the import was created
    ''' </summary>
    Public Property Created() As Date Implements crmDataImporter.Business.IDatabaseObject.Created
        Get
            Return _Created
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Created = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the user who created the import
    ''' </summary>
    Public Property CreatedBy() As Integer Implements crmDataImporter.Business.IDatabaseObject.CreatedBy
        Get
            Return _CreatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _CreatedBy = Value
        End Set
    End Property

    ''' <summary>
    ''' The date that the import was updated
    ''' </summary>
    Public Property Updated() As Date Implements crmDataImporter.Business.IDatabaseObject.Updated
        Get
            Return _Updated
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Updated = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the user who updated the import
    ''' </summary>
    Public Property UpdatedBy() As Integer Implements crmDataImporter.Business.IDatabaseObject.UpdatedBy
        Get
            Return _UpdatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _UpdatedBy = Value
        End Set
    End Property


    '''' <summary>
    '''' Indicates whether or not the file should have some integrity checks done before going too far
    '''' </summary>
    'Public Property VerifyFileIntegrity() As Boolean
    '    Get
    '        Return _VerifyFileIntegrity
    '    End Get
    '    Set(ByVal Value As Boolean)
    '        _VerifyFileIntegrity = Value
    '    End Set
    'End Property

    'INCOMPLETE
    ''' <summary>
    ''' The file name of the CSV file on disk used for building the structure - can be passed to a job to re-use
    ''' </summary>
    Public Property StructureFile() As DataSource
        Get
            If IsNothing(_StructureFile) Then _
                _StructureFile = New DataSource
            Return _StructureFile
        End Get
        Set(ByVal Value As DataSource)
            _StructureFile = Value
        End Set
    End Property

    'INCOMPLETE
    Public ReadOnly Property ToPurge() As ArrayList
        Get
            If IsNothing(_ToPurge) Then _
                _ToPurge = New ArrayList
            Return _ToPurge
        End Get
    End Property

    'INCOMPLETE
    <Xml.Serialization.XmlIgnore()> _
    Public ReadOnly Property Jobs() As JobCollection
        Get
            If IsNothing(_Jobs) And Not Serializing.IsDeserializing Then _
                _Jobs = New JobCollection(Me)

            Return _Jobs
        End Get
    End Property

    ''' <summary>
    ''' The id of the destination business object
    ''' </summary>
    Public Property DestinationObjectId() As Integer
        Get
            Return _DestinationObjectId
        End Get
        Set(ByVal Value As Integer)
            _DestinationObjectId = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns a code object for the destination business object
    ''' </summary>
    Public ReadOnly Property DestinationObject() As crmRepository.clsObjectBase
        Get
            Dim myObject As New crmRepository.clsObjectBase
            myObject.strConn = Me.ConnectionString
            myObject.userId = Me.UserId
            myObject.id = Me.DestinationObjectId
            myObject.getDetail()

            Return myObject
        End Get
    End Property

    ''' <summary>
    ''' Contains the data mappings for the import
    ''' </summary>
    Public ReadOnly Property DataMappings() As crmDataImporter.Business.DataMappingCollection
        Get
            If IsNothing(_DataMappings) And Not Serializing.IsDeserializing Then _
                _DataMappings = New crmDataImporter.Business.DataMappingCollection(Me)

            Return _DataMappings
        End Get
    End Property

    ''' <summary>
    ''' Enum selection for error option
    ''' </summary>
    Public Property ErrorOption() As crmDataImporter.Business.Enums.ErrorOption
        Get
            Return _ErrorOption
        End Get
        Set(ByVal Value As crmDataImporter.Business.Enums.ErrorOption)
            _ErrorOption = Value
        End Set
    End Property

    ''' <summary>
    ''' Enum selection for duplication option
    ''' </summary>
    Public Property DupeOption() As crmDataImporter.Business.Enums.DuplicationOption
        Get
            Return _DupeOption
        End Get
        Set(ByVal Value As crmDataImporter.Business.Enums.DuplicationOption)
            _DupeOption = Value
        End Set
    End Property

    ''' <summary>
    ''' Id of campaign to associate records with when writing to CM Contact business object
    ''' </summary>
    Public Property CampaignId() As Integer
        Get
            Return _CampaignId
        End Get
        Set(ByVal Value As Integer)
            _CampaignId = Value
        End Set
    End Property

    ''' <summary>
    ''' Enum selection for dialler export option
    ''' </summary>
    Public Property DiallerExport() As crmDataImporter.Business.Enums.DiallerTypes
        Get
            Return _DiallerExport
        End Get
        Set(ByVal Value As crmDataImporter.Business.Enums.DiallerTypes)
            _DiallerExport = Value
        End Set
    End Property

    <Xml.Serialization.XmlIgnoreAttribute()> _
    Public ReadOnly Property DiallerExportConfig() As Xml.XmlDocument
        Get
            Dim myConfig As Xml.XmlDocument = Nothing

            If Not String.IsNullOrEmpty(Me.DiallerExportConfig_raw) Then
                myConfig = New Xml.XmlDocument
                myConfig.LoadXml(Me.DiallerExportConfig_raw)
            End If

            Return myConfig
        End Get
    End Property

    Public Property DiallerExportConfig_raw() As String
        Get
            Return _DiallerExportConfig_raw
        End Get
        Set(ByVal value As String)
            _DiallerExportConfig_raw = value
        End Set
    End Property

    <Xml.Serialization.XmlIgnoreAttribute()> _
    Public Property DiallerProvider() As API.HostedDialler
        Get
            If IsNothing(_DiallerProvider) Then
                _DiallerProvider = API.HostedDiallerManager.SuitableProvider(Me.DiallerExport)
                If Not IsNothing(_DiallerProvider) Then _
                    _DiallerProvider.Init(Me.CampaignId, Me.DiallerExportConfig)
            End If

            Return _DiallerProvider
        End Get
        Set(ByVal value As API.HostedDialler)
            _DiallerProvider = value
        End Set
    End Property

    ''' <summary>
    ''' String array of source column names taken from first row in CSV
    ''' </summary>
    Public ReadOnly Property SourceColumns() As String()
        Get
            If IsNothing(_SourceColumns) OrElse _SourceColumns.Length.Equals(0) Then
                'Dim myDataObject As API.DataObject = StructureFile.GetDataObject

                'ReDim _SourceColumns(myDataObject.Columns.Length - 1)
                'Array.Copy(myDataObject.Columns, _SourceColumns, myDataObject.Columns.Length)
                ReDim _SourceColumns(Me.StructureFile.DataProvider.Columns.Length - 1)
                Array.Copy(Me.StructureFile.DataProvider.Columns, _SourceColumns, Me.StructureFile.DataProvider.Columns.Length)

                'myDataObject.Dispose()
            End If

            Return _SourceColumns
        End Get
    End Property

#End Region

#Region " Methods "

    Public Sub New()
        'set the default here
        Me.ErrorOption = Enums.ErrorOption.RollbackOnError
        Me.DupeOption = Enums.DuplicationOption.SkipNew
    End Sub

    ''' <summary>
    ''' Load a data import from its id
    ''' </summary>
    Public Sub New(ByVal loadFromId As Integer)
        Me.Load(loadFromId)
    End Sub

    Public Sub New(ByVal loadFromId As Integer, ByVal connectStr As String)
        Me.Load(loadFromId, connectStr)
    End Sub

    ''' <summary>
    ''' Load a data import from a DataRow
    ''' </summary>
    Public Sub New(ByVal loadFromRow As DataRow)
        Me.Load(loadFromRow)
    End Sub

    ''' <summary>
    ''' Takes care if tidying up when we're done with the object
    ''' </summary>
    Public Sub Dispose() Implements System.IDisposable.Dispose
        'decided to hang onto files for now
        'If IO.File.Exists(StructureFile) Then _
        '    IO.File.Delete(StructureFile)

        'run the garbage collection sp to delete field mappings that have become orphaned
        ' - on second thoughts, don't think we need to!!
        If Not IsNothing(_StructureFile) Then _
            _StructureFile.Dispose()
    End Sub

    ''' <summary>
    ''' Loads a DataRow from an ID and calls the second Load method, passing the DataRow
    ''' </summary>
    Public Sub Load(ByVal fromId As Integer)
        Dim rawData As DataSet = SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_GetDetail", New SqlClient.SqlParameter("@Id", fromId))

        If IsNothing(rawData) OrElse IsNothing(rawData.Tables) OrElse rawData.Tables(0).Rows.Count.Equals(0) Then _
            Throw New Exception("DataImport with Id " & fromId & " was not found")

        Me.Load(rawData.Tables(0).Rows(0))

        rawData.Dispose()
    End Sub

    Public Sub Load(ByVal fromId As Integer, ByVal connectStr As String)
        _ConnectionString = connectStr
        Dim rawData As DataSet = SqlHelper.ExecuteDataset(connectStr, CommandType.StoredProcedure, "g_DataImport_GetDetail", New SqlClient.SqlParameter("@Id", fromId))

        If IsNothing(rawData) OrElse IsNothing(rawData.Tables) OrElse rawData.Tables(0).Rows.Count.Equals(0) Then _
            Throw New Exception("DataImport with Id " & fromId & " was not found")

        Me.Load(rawData.Tables(0).Rows(0))

        rawData.Dispose()
    End Sub

    ''' <summary>
    ''' Loads an import from a DataRow
    ''' </summary>
    Public Sub Load(ByVal fromRow As DataRow)
        _Id = fromRow.Item("Id")
        _Name = fromRow.Item("Name")
        _DestinationObjectId = fromRow.Item("BusObjectId")
        _ErrorOption = fromRow.Item("ErrorOption")
        _DupeOption = fromRow.Item("DupeOption")
        _CampaignId = fromRow.Item("CampaignId")
        _DiallerExport = fromRow.Item("DiallerExport")

        If IsDBNull(fromRow.Item("HasHeaders")) Then
            _HasHeaders = 1
        Else
            _HasHeaders = fromRow.Item("HasHeaders")
        End If

        If IsDBNull(fromRow.Item("Delimiter")) Then
            _Delimiter = ","
        Else
            _Delimiter = fromRow.Item("Delimiter")
        End If

        If Not IsDBNull(fromRow.Item("StructureFileId")) AndAlso Convert.ToInt32(fromRow.Item("StructureFileId")) > 0 Then _
            _StructureFile = New DataSource(Convert.ToInt32(fromRow.Item("StructureFileId")), Me.ConnectionString, True, ",", True) 'Default to file has headers and comma delimited (source columns)
        '_StructureFile = New DataSource(Convert.ToInt32(fromRow.Item("StructureFileId")))

        If Not IsDBNull(fromRow.Item("DiallerExportConfig")) Then _
            _DiallerExportConfig_raw = fromRow.Item("DiallerExportConfig")

        If IsDBNull(fromRow.Item("Fileid")) Then
            _FileId = ""
        Else
            _FileId = fromRow.Item("Fileid")
        End If




    End Sub

    ''' <summary>
    ''' Saves the complete data import to the database
    ''' </summary>
    Public Sub Save()
        'if we have nochanges selected (only possible if loaded existing settings) then do not save!!
        'If Not Me.NoChanges Then

        If Not Me.ToPurge.Count.Equals(0) Then
            For Each myFile As Object In _ToPurge
                DirectCast(myFile, DataSource).Purge()
            Next
        End If

        If Not Me.StructureFile.DiskPath.Equals(String.Empty) Then _
            Me.StructureFile.Save()

        'first off save the import header
        Dim params(13) As SqlClient.SqlParameter

        params(0) = New SqlClient.SqlParameter("@@Id", Me.Id)

        If Me.Id.Equals(0) Then _
            params(1) = New SqlClient.SqlParameter("@@CreatedBy", Me.UserId)

        params(2) = New SqlClient.SqlParameter("@@UpdatedBy", Me.UserId)
        params(3) = New SqlClient.SqlParameter("@@Name", Me.Name)
        params(4) = New SqlClient.SqlParameter("@@BusObjectId", Me.DestinationObjectId)
        params(5) = New SqlClient.SqlParameter("@@StructureFileId", Me.StructureFile.Id)
        params(6) = New SqlClient.SqlParameter("@@ErrorOption", Me.ErrorOption)
        params(7) = New SqlClient.SqlParameter("@@DupeOption", Me.DupeOption)
        params(8) = New SqlClient.SqlParameter("@@CampaignId", Me.CampaignId)
        params(9) = New SqlClient.SqlParameter("@@DiallerExport", Me.DiallerExport)

        If Not String.IsNullOrEmpty(Me.DiallerExportConfig_raw) Then _
            params(10) = New SqlClient.SqlParameter("@@DiallerExportConfig", Me.DiallerExportConfig_raw)

        params(11) = New SqlClient.SqlParameter("@@FileId", Me.FileId)
        params(12) = New SqlClient.SqlParameter("@@HasHeaders", Me.HasHeaders)
        params(13) = New SqlClient.SqlParameter("@@Delimiter", Me.Delimiter)

        Dim returnId As Integer = SqlHelper.ExecuteScalar(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_SaveHeaderv2", params)

        If Not Me.Id.Equals(returnId) Then _
            _Id = returnId

        'now save all the child objects/collections
        DataMappings.ParentImportId = Me.Id 'ensures correct id is not with collection
        DataMappings.Save()

        'Jobs.ParentImportId = Me.Id
        'Jobs.Save()
        'End If
    End Sub

    'INCOMPLETE
    Public Sub CopyTo(ByRef destinationImport As DataImport)
        'main copying is handled by stored procedure
        'only manual task is to copy the structure file

        Dim newFile As DataSource = Me.StructureFile.Copy

        Dim copiedImportId As Integer = SqlHelper.ExecuteScalar(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_CopyImport", _
                                                                    New SqlClient.SqlParameter() { _
                                                                        New SqlClient.SqlParameter("@@SourceImportId", Me.Id), _
                                                                        New SqlClient.SqlParameter("@@DataSourceId", newFile.Id), _
                                                                        New SqlClient.SqlParameter("@@UserId", Me.UserId)})

        destinationImport = New DataImport(copiedImportId)
    End Sub

    Public Function GetHeaderDetails(ByVal id As Integer) As DataSet

        Dim rawData As DataSet = SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_GetDetail", New SqlClient.SqlParameter("@Id", id))

        If IsNothing(rawData) OrElse IsNothing(rawData.Tables) OrElse rawData.Tables(0).Rows.Count.Equals(0) Then _
            Throw New Exception("DataImport with Id " & id & " was not found")

        Return rawData

        rawData.Dispose()
    End Function

#End Region

End Class
