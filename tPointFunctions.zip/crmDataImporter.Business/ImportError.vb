Imports crmRepositoryWeb.Classes
Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' 
''' </summary>
<Serializable()> _
Public Class ImportError
    Implements crmDataImporter.Business.IDatabaseObject

#Region " Fields "

    Private _Id, _CreatedBy, _UpdatedBy, _ParentJobId, _LineNum As Integer
    Private _ErrorDetails, _ConnectionString As String
    Private _Created, _Updated As Date

#End Region

#Region " Properties "

    Private ReadOnly Property UserId() As Integer
        Get
            If IsNothing(Web.HttpContext.Current) Then _
                Return Me.UpdatedBy
            Return clsCookieHelper.CurrentEmployeeId
        End Get
    End Property

    Public Property ConnectionString() As String
        Get
            If IsNothing(_ConnectionString) OrElse _ConnectionString.Equals(String.Empty) Then _
                Return crmRepositoryWeb.Classes.clsHelper.strConn

            Return _ConnectionString
        End Get
        Set(ByVal Value As String)
            _ConnectionString = Value
        End Set
    End Property

    ''' <summary>
    ''' Unique identifier for the error
    ''' </summary>
    Public Property Id() As Integer Implements IDatabaseObject.Id
        Get
            Return _Id
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Id = Value
        End Set
    End Property

    ''' <summary>
    ''' Not implemented
    ''' </summary>
    <Xml.Serialization.XmlIgnore()> _
    Public Property Name() As String Implements IDatabaseObject.Name
        Get
            Throw New NotImplementedException
        End Get
        Set(ByVal Value As String)
            Throw New NotImplementedException
        End Set
    End Property

    ''' <summary>
    ''' The date that the error was created
    ''' </summary>
    Public Property Created() As Date Implements IDatabaseObject.Created
        Get
            Return _Created
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Created = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the user who created the error (i.e. user who initiated the import Job)
    ''' </summary>
    Public Property CreatedBy() As Integer Implements IDatabaseObject.CreatedBy
        Get
            Return _CreatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _CreatedBy = Value
        End Set
    End Property

    ''' <summary>
    ''' The date that the error was updated
    ''' </summary>
    Public Property Updated() As Date Implements IDatabaseObject.Updated
        Get
            Return _Updated
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Updated = Value
        End Set
    End Property

    ''' <summary>
    ''' The user id of the person who updated the error
    ''' </summary>
    Public Property UpdatedBy() As Integer Implements IDatabaseObject.UpdatedBy
        Get
            Return _UpdatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _UpdatedBy = Value
        End Set
    End Property

    'INCOMPLETE
    Public Property ParentJobId() As Integer
        Get
            Return _ParentJobId
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _ParentJobId = Value
        End Set
    End Property

    'INCOMPLETE
    Public Property LineNum() As Integer
        Get
            Return _LineNum
        End Get
        Set(ByVal value As Integer)
            _LineNum = value
        End Set
    End Property

    'INCOMPLETE
    Public Property ErrorDetails() As String
        Get
            Return _ErrorDetails
        End Get
        Set(ByVal value As String)
            _ErrorDetails = value
        End Set
    End Property

#End Region

#Region " Methods "

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Load an error from a DataRow
    ''' </summary>
    Public Sub New(ByVal loadFromRow As DataRow, ByVal connectionString As String)
        Me.Load(loadFromRow, connectionString)
    End Sub

    'INCOMPLETE
    ''' <summary>
    ''' Create a new error for the specified parent Job
    ''' </summary>
    Public Sub New(ByVal jobId As Integer)
        _ParentJobId = jobId
    End Sub

    ''' <summary>
    ''' Load an error from a DataRow
    ''' </summary>
    Public Sub Load(ByVal fromRow As DataRow, ByVal connectionString As String)
        _Id = fromRow.Item("Id")
        _Created = fromRow.Item("Created")
        _CreatedBy = fromRow.Item("CreatedBy")
        _Updated = fromRow.Item("Updated")
        _CreatedBy = fromRow.Item("CreatedBy")
        _ParentJobId = fromRow.Item("JobId")
        _LineNum = fromRow.Item("LineNum")
        _ErrorDetails = fromRow.Item("ErrorDetails")

        Me.ConnectionString = connectionString
    End Sub

    'INCOMPLETE
    Public Sub Save()
        Me.Save(Me.ParentJobId)
    End Sub

    ''' <summary>
    ''' Save the key to the database
    ''' </summary>
    Public Sub Save(ByVal parentJobId As Integer)
        Dim params(6) As SqlClient.SqlParameter

        params(0) = New SqlClient.SqlParameter("@@Id", Me.Id)

        If Me.Id.Equals(0) Then _
            params(1) = New SqlClient.SqlParameter("@@CreatedBy", Me.UserId)

        params(2) = New SqlClient.SqlParameter("@@UpdatedBy", Me.UserId)
        params(3) = New SqlClient.SqlParameter("@@JobId", parentJobId)
        params(4) = New SqlClient.SqlParameter("@@LineNum", Me.LineNum)
        params(5) = New SqlClient.SqlParameter("@@ErrorDetails", Me.ErrorDetails)

        Dim returnId As Integer = SqlHelper.ExecuteScalar(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_SaveImportError", params)

        If Not Me.Id.Equals(returnId) Then _
            _Id = returnId
    End Sub

#End Region

End Class
