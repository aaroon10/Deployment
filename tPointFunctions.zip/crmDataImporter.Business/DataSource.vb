Imports crmRepositoryWeb.Classes
Imports Microsoft.ApplicationBlocks.Data

'INCOMPLETE
<Serializable()> _
Public Class DataSource
    Implements IDatabaseObject
    Implements IDisposable

    Private _DiskPath, _Name, _ConnectionString As String
    Private _Created, _Updated As Date
    Private _Id, _CreatedBy, _UpdatedBy As Integer
    Private _DataProvider As API.DataObject
    Private _HasHeaders As Boolean
    Private _Delimiter As Char

    Private ReadOnly Property UserId() As Integer
        Get
            If IsNothing(Web.HttpContext.Current) Then _
                Return Me.UpdatedBy

            Return clsCookieHelper.CurrentEmployeeId
        End Get
    End Property


    Public Property ConnectionString() As String
        Get
            If IsNothing(_ConnectionString) OrElse _ConnectionString.Equals(String.Empty) Then _
                Return crmRepositoryWeb.Classes.clsHelper.strConn

            Return _ConnectionString
        End Get
        Set(ByVal Value As String)
            _ConnectionString = Value
        End Set
    End Property

    Public Property Id() As Integer Implements IDatabaseObject.Id
        Get
            Return _Id
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Id = Value
        End Set
    End Property

    Public Property Created() As Date Implements IDatabaseObject.Created
        Get
            Return _Created
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Created = Value
        End Set
    End Property

    Public Property CreatedBy() As Integer Implements IDatabaseObject.CreatedBy
        Get
            Return _CreatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _CreatedBy = Value
        End Set
    End Property

    Public Property Updated() As Date Implements IDatabaseObject.Updated
        Get
            Return _Updated
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Updated = Value
        End Set
    End Property

    Public Property UpdatedBy() As Integer Implements IDatabaseObject.UpdatedBy
        Get
            Return _UpdatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                 Throw New Exception("Property value can only be set while deserializing object")
            _UpdatedBy = Value
        End Set
    End Property

    Public Property Name() As String Implements IDatabaseObject.Name
        Get
            Return _Name
        End Get
        Set(ByVal value As String)
            _Name = value
        End Set
    End Property

    Public Property HasHeaders() As Boolean
        Get
            Return _HasHeaders
        End Get
        Set(ByVal value As Boolean)
            _HasHeaders = value
        End Set
    End Property

    Public Property Delimiter() As Char
        Get
            Return _Delimiter
        End Get
        Set(ByVal value As Char)
            _Delimiter = value
        End Set
    End Property

    Public Property DiskPath() As String

        Get
            Return _DiskPath
        End Get

        Set(ByVal value As String)
            _DiskPath = value
        End Set
    End Property

    Public ReadOnly Property FileExtension() As String
        Get
            Return IO.Path.GetExtension(Me.Name).ToLower
        End Get
    End Property

    Public ReadOnly Property DataProvider() As API.DataObject
        Get
            If IsNothing(_DataProvider) Then _
                _DataProvider = API.DataObjectManager.SuitableProvider(Me.FileExtension)

            If IsNothing(_DataProvider) Then _
                Throw New Exception("Files of type " & Me.FileExtension & " are not supported")

            If Not _DataProvider.Initialised Then _
                _DataProvider.Init(Me.HasHeaders, Me.Delimiter, Me.DiskPath)

            Return _DataProvider
        End Get
    End Property


    Public Sub New()
        _Name = String.Empty
        _DiskPath = String.Empty
    End Sub

    Public Sub New(ByVal connectionString As String)
        Me.New()
        Me.ConnectionString = connectionString
    End Sub

    Public Sub New(ByVal hasHeaders As Boolean, ByVal delimiter As Char)
        _HasHeaders = hasHeaders
        _Delimiter = delimiter
    End Sub

    Public Sub New(ByVal hasHeaders As Boolean, ByVal delimiter As Char, ByVal diskPath As String, ByVal originalName As String)
        _HasHeaders = hasHeaders
        _Delimiter = delimiter
        _DiskPath = diskPath
        _Name = originalName
    End Sub

    Public Sub New(ByVal loadFromId As Integer, ByVal connectionString As String, ByVal HasHeaders As Boolean, ByVal Delimiter As Char, ByVal dummy As Boolean)
        Me.ConnectionString = connectionString
        Me.Load(loadFromId)
        _HasHeaders = HasHeaders
        _Delimiter = Delimiter
    End Sub

    Public Sub New(ByVal loadFromId As Integer)
        Me.Load(loadFromId)
    End Sub

    Public Sub New(ByVal loadFromRow As DataRow)
        Me.Load(loadFromRow)
    End Sub

    Private Sub Load(ByVal fromId As Integer)
        Dim rawData As DataSet = SqlHelper.ExecuteDataset(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_DataFile_GetDetail", New SqlClient.SqlParameter("@@Id", fromId))

        If IsNothing(rawData) OrElse IsNothing(rawData.Tables) OrElse rawData.Tables(0).Rows.Count.Equals(0) Then _
            Throw New Exception("DataFile with Id " & fromId & " was not found")

        Me.Load(rawData.Tables(0).Rows(0))

        rawData.Dispose()

    End Sub

    Private Sub Load(ByVal fromRow As DataRow)
        _Id = fromRow.Item("Id")
        _Created = fromRow.Item("Created")
        _CreatedBy = fromRow.Item("CreatedBy")
        _Updated = fromRow.Item("Updated")
        _UpdatedBy = fromRow.Item("UpdatedBy")
        _Name = fromRow.Item("Name")
        _DiskPath = fromRow.Item("DiskPath")
    End Sub

    Public Sub Purge()
        If IO.File.Exists(DiskPath) Then
            If Not _DataProvider Is Nothing Then 'MOD 16/3/2009 - _DataProvider may already equal Nothing
                _DataProvider.Dispose()
                _DataProvider = Nothing
            End If
            IO.File.Delete(DiskPath)
            Me.DiskPath = String.Empty
        End If
    End Sub

    Public Sub Save()
        Dim params(5) As SqlClient.SqlParameter

        params(0) = New SqlClient.SqlParameter("@@Id", Me.Id)

        If Me.Id.Equals(0) Then _
            params(1) = New SqlClient.SqlParameter("@@CreatedBy", Me.UserId)

        params(2) = New SqlClient.SqlParameter("@@UpdatedBy", Me.UserId)
        params(3) = New SqlClient.SqlParameter("@@Name", Me.Name)
        params(4) = New SqlClient.SqlParameter("@@DiskPath", Me.DiskPath)

        Dim returnId As Integer = SqlHelper.ExecuteScalar(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_SaveDataFile", params)

        If Not Me.Id.Equals(returnId) Then _
            _Id = returnId
    End Sub

    Public Function Copy() As DataSource
        Dim fileName As String = Guid.NewGuid.ToString & "__DataImport.csv"
        'fileName = Web.HttpContext.Current.Server.MapPath("../DataImport/" & fileName)
        fileName = crmRepositoryWeb.Classes.clsHelper.getSetting("webFileSystemMain") & fileName

        IO.File.Copy(Me.DiskPath, fileName)

        Dim copiedSource As New DataSource(HasHeaders, Delimiter, fileName, Me.Name)
        copiedSource.Save()

        Return copiedSource
    End Function

    'Public Function GetDataObject() As API.DataObject
    '    Dim myProvider As API.DataObject = API.DataObjectManager.SuitableProvider(Me.FileExtension)

    '    If IsNothing(myProvider) Then _
    '        Throw New Exception("Files of type " & Me.FileExtension & " are not supported")

    '    'init if necessary
    '    If Not myProvider.Initialised Then _
    '        myProvider.Init(Me.DiskPath)

    '    Return myProvider
    'End Function

    Public Sub Dispose() Implements IDisposable.Dispose
        If Not IsNothing(_DataProvider) Then _
            _DataProvider.Dispose()
        '_DataProvider = Nothing
    End Sub


End Class
