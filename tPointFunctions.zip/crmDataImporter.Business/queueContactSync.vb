Imports System.Net
Imports System.IO
Imports Microsoft.ApplicationBlocks.Data.SqlHelper
Public Class queueContactSync
    Private _dxiURL As String
    Private _logFile As String
    Private _conn As String
    Private _tempFileArea As String
    Private _err As String
    Private _batchSize As Long

    Public Event msg(ByVal msg As String)

    Public ReadOnly Property errorMessage() As String
        Get
            Return _err
        End Get
    End Property

    Sub New(ByVal conn As String, _
            ByVal logFile As String, _
            ByVal tempFileArea As String, _
            ByVal batchSize As Long)
        _logFile = logFile
        _conn = conn
        _tempFileArea = tempFileArea
        Dim cr As New tPointCM4.clsDXI.credentials(0, _logFile, _conn)
        _dxiURL = cr.dxiDbApiURL & "?username=" & cr.dxiAPILogin & "&password=" & cr.dxiAPIPassword
        _batchSize = batchSize
        RaiseEvent msg("New")
        
    End Sub

    Private Function updateCampaign(ByVal camName As String, ByVal camId As Long) As Long
        Try
            'RaiseEvent msg("updateCampaign: " & camName & " " & camId)
            Dim fn As String = Guid.NewGuid.ToString
            Dim f As Integer = FreeFile()
            fn = _tempFileArea & fn & ".xml"
            FileOpen(f, fn, OpenMode.Output)
            Print(f, "<?xml version=""1.0"" encoding=""utf-8"" ?><campaign><description>" & camId & " " & camName & "</description><state>1</state></campaign>")
            FileClose()
            Dim retVal As String = postFile(fn, _dxiURL & "&method=campaigns&action=import&format=xml")
            'Dim stream As System.IO.StringReader = New System.IO.StringReader(retVal)
            Dim x As New System.Xml.XmlDocument
            x.LoadXml(retVal)

            'Stream.Close()
            Try
                Kill(fn)
            Catch ex As Exception
            End Try
            Return Val(x.GetElementsByTagName("key_id").Item(0).InnerText)
        Catch ex As Exception
                Throw New Exception("updateCampaign: " & ex.Message)
            End Try
    End Function

    Private Function updateQueue(ByVal queueName As String, _
                                    ByVal queueId As Long, _
                                    ByVal queueCLI As String, _
                                    ByVal dxiCampaignId As Long) As Long
        Try
            Dim fn As String = Guid.NewGuid.ToString
            Dim f As Integer = FreeFile()
            fn = _tempFileArea & fn & ".xml"
            FileOpen(f, fn, OpenMode.Output)
            Print(f, "<?xml version=""1.0"" encoding=""utf-8"" ?>" & _
                    "<queue><type>outbound</type><numbers></numbers>" & _
                    "<description>" & queueId & " " & queueName & "</description>" & _
                    "<callerid>" & queueCLI & "</callerid>" & _
                    "<campaignid>" & dxiCampaignId & "</campaignid>" & _
                    "<monitor>1</monitor><amd>1</amd><level>100</level></queue>")
            FileClose(f)
            Dim retVal As String = postFile(fn, _
                        _dxiURL & "&method=queues&action=import&format=xml")
            'Dim stream As System.IO.StringReader = New System.IO.StringReader(retVal)
            Dim x As New System.Xml.XmlDocument
            x.LoadXml(retVal)
            Try
                Kill(fn)
            Catch ex As Exception

            End Try
            Return Val(x.GetElementsByTagName("key_id").Item(0).InnerText)

        Catch ex As Exception
            Throw New Exception("updateQueue: " & ex.Message)
        End Try
    End Function

    Private Sub syncCampaigns()
        '// make sure all campaigns and queues in worktable have dxi id's
        Dim rdr As SqlClient.SqlDataReader
        Try
            '// list campaign headers that need to have a dxi id
            rdr = ExecuteReader(_conn, CommandType.StoredProcedure, "dxiLoader_listNonDXICampaigns")
            Dim temp As Long
            Do While rdr.Read
                temp = 0
                Try
                    '// upload to dxi and get dxi id
                    temp = updateCampaign(rdr("campaignName"), rdr("tpCampaignId"))
                    Dim param(2) As SqlClient.SqlParameter
                    param(1) = New SqlClient.SqlParameter("@tpCamId", rdr("tpCampaignId"))
                    param(2) = New SqlClient.SqlParameter("@dxiCamId", temp)
                    '// update tpoint db with dxi id
                    ExecuteNonQuery(_conn, CommandType.StoredProcedure, "dxiLoader_updateCampaignId", param)
                Catch ex As Exception

                End Try
            Loop
            rdr.Close()
            rdr = ExecuteReader(_conn, CommandType.StoredProcedure, "dxiLoader_listNonDXIQueues")
            Do While rdr.Read
                temp = 0
                Try
                    '// upload to dxi and get dxi id
                    temp = updateQueue(rdr("tpQname"), rdr("tpQID"), rdr("qcli"), rdr("dxiCampaignId"))
                    Dim param(2) As SqlClient.SqlParameter
                    param(1) = New SqlClient.SqlParameter("@tpqid", rdr("tpQID"))
                    param(2) = New SqlClient.SqlParameter("@dxiqid", temp)
                    '// update tpoint db with dxi id
                    ExecuteNonQuery(_conn, CommandType.StoredProcedure, "dxiLoader_updateQueueId", param)
                Catch ex As Exception

                End Try
            Loop
        Catch ex As Exception
        Finally
            If rdr IsNot Nothing Then rdr.Close()
        End Try
    End Sub

    Private Function createContactFile(ByVal tpQid As Long, ByVal contactLogFileName As String, ByVal doneHeader As Boolean) As String
        Dim conRDR As SqlClient.SqlDataReader
        Try
            Dim doneHeaderLocal As Boolean
            '// create xml file for records
            Dim foundRecords As Boolean = False
            Dim conParam(2) As SqlClient.SqlParameter
            conParam(1) = New SqlClient.SqlParameter("@tpqid", tpQid)
            conParam(2) = New SqlClient.SqlParameter("@batchSize", _batchSize)
            conRDR = ExecuteReader(_conn, CommandType.StoredProcedure, "dxiLoader_listQueueContacts", conParam)
            Dim f As Integer = FreeFile()
            Dim fn As String = _tempFileArea & "dxiLoaderContactFile_" & Guid.NewGuid.ToString & ".xml"
            FileOpen(f, fn, OpenMode.Append)

            Dim f2 As Integer = FreeFile()
            FileOpen(f2, _tempFileArea & contactLogFileName, OpenMode.Append)

            Print(f, "<easycall>" & vbCrLf)
            Do While conRDR.Read
                foundRecords = True
                Print(f, "<record>" & vbCrLf)
                For i As Integer = 0 To conRDR.FieldCount - 1
                    Dim ln As String = "<" & conRDR.GetName(i) & ">" & _
                                        conRDR(i).ToString & _
                                        "</" & conRDR.GetName(i) & ">"
                    Print(f, ln & vbCrLf)
                Next
                Print(f, "</record>" & vbCrLf)

                Dim ln2 As String = ""
                If Not doneHeader And Not doneHeaderLocal Then
                    For i As Integer = 0 To conRDR.FieldCount - 1
                        ln2 = ln2 & conRDR.GetName(i) & ","
                    Next
                    ln2 = Left(ln2, Len(ln2) - 1)
                    Print(f2, ln2 & vbCrLf)
                    doneHeaderLocal = True
                End If
                ln2 = ""
                For i As Integer = 0 To conRDR.FieldCount - 1
                    ln2 = ln2 & conRDR(i).ToString & ","
                Next
                ln2 = Left(ln2, Len(ln2) - 1)
                Print(f2, ln2 & vbCrLf)
            Loop
            Print(f, "</easycall>")
            FileClose(f)
            FileClose(f2)
            If foundRecords Then
                Return fn
            Else
                Try : Kill(fn) : Catch ex1 As Exception : End Try
                Return ""
            End If
        Catch ex As Exception
            writeLog("createContactFile", "Error: " & ex.Message, _logFile)
            Throw New Exception("createContactFile: " & "Error: " & ex.Message)
        Finally
            If conRDR IsNot Nothing Then conRDR.Close()
        End Try
    End Function


    Public Sub syncMain()
        Dim conRDR As SqlClient.SqlDataReader
        Dim rdr As SqlClient.SqlDataReader
        Try
            RaiseEvent msg("conn = " & _conn)
            RaiseEvent msg("logFile = " & _logFile)
            RaiseEvent msg("tempFileArea = " & _tempFileArea)
            RaiseEvent msg("dxiURL = " & _dxiURL)
            writeLog("syncMain", "Start. Connection=" & _conn, _logFile)
            Dim temp As Long = ExecuteNonQuery(_conn, CommandType.StoredProcedure, "dxiLoader_createWorkTable")
            If temp > 0 Then
                writeLog("syncMain", temp & " rows to process", _logFile)
                '// make sure all campaigns and queues in worktable have dxi id's
                syncCampaigns()
                '// list all queues with data to load
                rdr = ExecuteReader(_conn, CommandType.StoredProcedure, "dxiLoader_listValidWorktableRecords")
                Do While rdr.Read
                    '// create contact records in temp table
                    Dim param(1) As SqlClient.SqlParameter
                    param(1) = New SqlClient.SqlParameter("@id", rdr("id"))
                    temp = ExecuteNonQuery(_conn, CommandType.StoredProcedure, "dxiLoader_createContacts", param)
                    If temp > 0 Then
                        writeLog("syncMain", "Found contacts ....", _logFile)
                        '// update queue record with status of importing to dxi
                        '(@tpqid int, @badRows int, 
                        ReDim param(4)
                        param(1) = New SqlClient.SqlParameter("@nRows", 0)
                        param(2) = New SqlClient.SqlParameter("@badRows", 0)
                        param(3) = New SqlClient.SqlParameter("@tpqid", rdr("tpqid"))
                        param(4) = New SqlClient.SqlParameter("@status", 5)
                        ExecuteNonQuery(_conn, CommandType.StoredProcedure, "dxiLoader_updateQueueStats", param)

                        '// delete all existing data in dxi queue
                        Dim tempFN As String = _tempFileArea & Guid.NewGuid.ToString & ".xml"
                        Dim ff As Integer = FreeFile()
                        FileOpen(ff, tempFN, OpenMode.Append)
                        Print(ff, "<easycall><record><qid>" & rdr("dxiCampaignId") & "</qid><urn>all</urn></record></easycall>")
                        Dim delResults As String = postFile(tempFN, _dxiURL & "&method=records&action=delete&format=xml&verbose=1")
                        writeLog("syncMain", "Deleted Queue Data, Results = " & delResults, _logFile)
                        Try : Kill(tempFN) : Catch ex As Exception : End Try

                        '//set stats values to 0
                        ReDim param(6)
                        param(1) = New SqlClient.SqlParameter("@dxiqid", rdr("dxiCampaignId"))
                        param(2) = New SqlClient.SqlParameter("@attNum10", 0)
                        param(3) = New SqlClient.SqlParameter("@attNum11", 0)
                        param(4) = New SqlClient.SqlParameter("@attNum12", 0)
                        param(5) = New SqlClient.SqlParameter("@attNum13", 0)
                        param(6) = New SqlClient.SqlParameter("@attNum14", 0)
                        ExecuteNonQuery(_conn, CommandType.StoredProcedure, "cm4_updateDiallerDXIStats_byDXIQID", param)

                        '// this file contains all of the data posted
                        Dim contactLogFileName As String = "dxiLoaderContactLogFile_" & Guid.NewGuid.ToString & ".csv"

                        '// this file contains a subset (determined by _batchsize) to be posted to dxi
                        Dim fileName As String = createContactFile(rdr("tpqid"), contactLogFileName, False)

                        Dim nrows As Long = 0
                        Dim badRows As Long = 0

                        Do While fileName <> ""
                            '// start posting data to dxi
                            Dim results As String = postFile(fileName, _dxiURL & "&method=records&action=delete&format=xml")
                            results = postFile(fileName, _dxiURL & "&method=records&action=import&format=xml&verbose=1")
                            Dim stream As New StringReader(results)
                            Dim ds As New DataSet
                            ds.ReadXml(stream)
                            nrows = nrows + Val(ds.Tables("status").Rows(0)("nrows"))
                            badRows = badRows + Val(ds.Tables("status").Rows(0)("bad_rows"))
                            '// update each work table row to contain the import status from dxi
                            For Each row As DataRow In ds.Tables("import").Rows
                                Dim conParam(3) As SqlClient.SqlParameter
                                conParam(1) = New SqlClient.SqlParameter("@stat", row("errcode"))
                                conParam(2) = New SqlClient.SqlParameter("@urn", row("urn"))
                                conParam(3) = New SqlClient.SqlParameter("@tpQID", rdr("tpqid"))
                                ExecuteNonQuery(_conn, CommandType.StoredProcedure, "dxi_loaderWorkTable_contacts_updateStatus", conParam)
                            Next
                            Try : Kill(fileName) : Catch ex As Exception : End Try
                            fileName = createContactFile(rdr("tpqid"), contactLogFileName, True)
                        Loop

                        '// attach the records posted to the queue for audit purposes
                        attachReport(rdr("tpqid"), contactLogFileName, "Records Posted " & Now.ToShortDateString & " " & Now.ToShortTimeString)

                        Try : Kill(fileName) : Catch ex As Exception : End Try
                        '// update queue record with status of import to dxi
                        writeLog("syncMain", "Contacts uploaded", _logFile)
                        ReDim param(3)
                        param(1) = New SqlClient.SqlParameter("@nRows", nrows)
                        param(2) = New SqlClient.SqlParameter("@badRows", badRows)
                        param(3) = New SqlClient.SqlParameter("@tpqid", rdr("tpqid"))
                        ExecuteNonQuery(_conn, CommandType.StoredProcedure, "dxiLoader_updateQueueStats", param)

                        writeLog("syncMain", "Queue Stats Updated", _logFile)

                        '// attach any bad records as file to queue
                        ReDim param(1)
                        param(1) = New SqlClient.SqlParameter("@tpqid", rdr("tpqid"))
                        conRDR = ExecuteReader(_conn, CommandType.StoredProcedure, "dxiLoader_listInvalidRecords", param)

                        Dim f As Integer = FreeFile()
                        Dim fn As String = "dxiLoader_FailedRecords_" & Guid.NewGuid.ToString & ".csv"
                        Dim badRecords As Boolean = False
                        FileOpen(f, _tempFileArea & fn, OpenMode.Append)
                        Dim doneHDR As Boolean = False
                        Do While conRDR.Read
                            badRecords = True
                            Dim ln As String = ""
                            If Not doneHDR Then
                                For i As Integer = 0 To conRDR.FieldCount - 1
                                    ln = ln & conRDR.GetName(i) & ","
                                Next
                                ln = Left(ln, Len(ln) - 1)
                                Print(f, ln & vbCrLf)
                                doneHDR = True
                                ln = ""
                            End If
                            For i As Integer = 0 To conRDR.FieldCount - 1
                                ln = ln & conRDR(i).tostring & ","
                            Next
                            ln = Left(ln, Len(ln) - 1)
                            Print(f, ln & vbCrLf)
                        Loop
                        FileClose()
                        If badRecords Then
                            writeLog("syncMain", "Attaching log of bad numbers", _logFile)
                            attachReport(rdr("tpqid"), fn, "Bad Records " & Now.ToShortDateString & " " & Now.ToShortTimeString)
                        Else
                            writeLog("syncMain", "No Bad Records", _logFile)
                            Try
                                Kill(fn)
                            Catch ex As Exception

                            End Try
                        End If
                    Else
                        '// no rows to send to dxi, set status = 7 so as not to be re-tried on next iteration
                        '// user will have to refresh/regenrate queue to include this queue in next iteration
                        ReDim param(4)
                        param(1) = New SqlClient.SqlParameter("@nRows", 0)
                        param(2) = New SqlClient.SqlParameter("@badRows", 0)
                        param(3) = New SqlClient.SqlParameter("@tpqid", rdr("tpqid"))
                        param(4) = New SqlClient.SqlParameter("@status", 7)
                        ExecuteNonQuery(_conn, CommandType.StoredProcedure, "dxiLoader_updateQueueStats", param)

                    End If
                    '// clear the contacts from wrk table
                    ReDim param(1)
                    param(1) = New SqlClient.SqlParameter("@tpqid", rdr("tpqid"))
                    ExecuteNonQuery(_conn, CommandType.StoredProcedure, "dxiLoader_deleteInvalidRecords", param)
                Loop
            Else
                writeLog("syncMain", "No rows to process", _logFile)
            End If
            writeLog("syncMain", "End. Connection=" & _conn, _logFile)
        Catch ex As Exception
            writeLog("syncMain", "Error: " & ex.Message, _logFile)
        Finally
            If rdr IsNot Nothing Then rdr.Close()
            If conRDR IsNot Nothing Then conRDR.Close()
        End Try
    End Sub

    Private Sub attachReport(ByVal tpQID As Long, _
                                ByVal FileName As String, _
                                ByVal name As String)
        Try
            Dim colParam() As SqlClient.SqlParameter
            ReDim colParam(15)
            colParam(1) = New SqlClient.SqlParameter("@id", 0)
            colParam(1).Direction = ParameterDirection.InputOutput
            colParam(2) = New SqlClient.SqlParameter("@userid", "0")
            colParam(3) = New SqlClient.SqlParameter("@name", name)
            colParam(4) = New SqlClient.SqlParameter("@parentId", tpQID)
            colParam(5) = New SqlClient.SqlParameter("@url", "")
            colParam(6) = New SqlClient.SqlParameter("@originalFileName", FileName)
            colParam(7) = New SqlClient.SqlParameter("@actualFileName", FileName)
            colParam(8) = New SqlClient.SqlParameter("@extension", "CSV")
            colParam(9) = New SqlClient.SqlParameter("@picWidth", "0")
            colParam(10) = New SqlClient.SqlParameter("@picHeight", "0")
            colParam(11) = New SqlClient.SqlParameter("@attachmentType", "CSV File")
            colParam(12) = New SqlClient.SqlParameter("@notes", "")
            colParam(13) = New SqlClient.SqlParameter("@parentTbl", "u_campaignHDR")
            colParam(14) = New SqlClient.SqlParameter("@filesize", "0")
            colParam(15) = New SqlClient.SqlParameter("@mimeType", "text/plain")

            ExecuteNonQuery(_conn, CommandType.StoredProcedure, "rm_attachment_insert", colParam)
        Catch ex As Exception
            writeLog("attachErrorReport", "Error: " & ex.Message, _logFile)
        End Try
    End Sub

    Private Function postFile(ByVal uploadfile As String, _
                                ByVal url As String) As String
        Try
            Dim fileFormName As String = "easycall"
            Dim contenttype As String = "application/octet-stream"

            Dim uri As Uri = New Uri(url)

            Dim boundary As String = "----------" + DateTime.Now.Ticks.ToString("x")
            Dim webrequest As HttpWebRequest = HttpWebRequest.Create(uri)
            webrequest.ServicePoint.Expect100Continue = False
            webrequest.ContentType = "multipart/form-data; boundary=""" & boundary & """"
            webrequest.Method = "POST"

            Dim sb As System.text.StringBuilder = New System.Text.StringBuilder
            sb.Append("--")
            sb.Append(boundary)
            sb.Append(vbCrLf)
            sb.Append("Content-Disposition: form-data; name=""")
            sb.Append(fileFormName)
            sb.Append("""; filename=""")
            sb.Append(System.IO.Path.GetFileName(uploadfile) & """")
            sb.Append(vbCrLf)
            sb.Append("Content-Type: ")
            sb.Append(contenttype)
            sb.Append(vbCrLf)
            sb.Append(vbCrLf)

            Dim postHeader As String = sb.ToString()
            Dim postHeaderBytes As Byte() = System.Text.Encoding.UTF8.GetBytes(postHeader)

            Dim boundaryBytes As Byte() = System.Text.Encoding.ASCII.GetBytes(vbCrLf & "--" & boundary & vbCrLf & vbCrLf)

            Dim fileStream As System.IO.FileStream = New System.IO.FileStream(uploadfile, System.IO.FileMode.Open, System.IO.FileAccess.Read)
            Dim length As Long = postHeaderBytes.Length + fileStream.Length + boundaryBytes.Length
            webrequest.ContentLength = length

            Dim requestStream As System.IO.Stream = webrequest.GetRequestStream()

            requestStream.Write(postHeaderBytes, 0, postHeaderBytes.Length)
            Dim l As Integer = fileStream.Length
            If l < 4096 Then l = 4096
            Dim buffer(l) As Byte

            Dim bytesRead As Integer = 0
            bytesRead = fileStream.Read(buffer, 0, buffer.Length)
            While bytesRead > 0
                requestStream.Write(buffer, 0, bytesRead)
                bytesRead = fileStream.Read(buffer, 0, buffer.Length)
            End While
            requestStream.Write(boundaryBytes, 0, boundaryBytes.Length)
            Dim responce As WebResponse = webrequest.GetResponse()
            Dim s As System.IO.Stream = responce.GetResponseStream()
            Dim sr As System.IO.StreamReader = New System.IO.StreamReader(s)
            Dim resp As String = sr.ReadToEnd()
            sr.Close()
            requestStream.Close()
            fileStream.Close()
            responce.Close()
            Return resp

        Catch ex As Exception
            writeLog("postFile", "Error: " & ex.Message, _logFile)
            Return String.Empty
        End Try
    End Function

    Public Sub updateQueueStats()
        Dim rdr As SqlClient.SqlDataReader
        Try
            writeLog("updateQueueStats", "Start", _logFile)
            'rdr = ExecuteReader(_conn, CommandType.StoredProcedure, "dxiLoader_listAllPredictiveQueues")
            'Do While rdr.Read
            'Dim http As HttpWebRequest = DirectCast(WebRequest.Create(_dxiURL & "&action=export&method=stats&queuid=" & rdr("diallercampaignid") & "&format=xml"), HttpWebRequest)
            Dim http As HttpWebRequest = DirectCast(WebRequest.Create(_dxiURL & "&action=export&method=stats&format=xml"), HttpWebRequest)
            Dim httpds As New DataSet
            httpds.ReadXml(http.GetResponse().GetResponseStream())
            For Each row As DataRow In httpds.Tables("stats").Rows
                writeLog("updateQueueStats", "Update Queue: " & row("qid") & ". Available=" & row("available"), _logFile)
                Dim param(6) As SqlClient.SqlParameter
                param(1) = New SqlClient.SqlParameter("@dxiqid", row("qid"))
                param(2) = New SqlClient.SqlParameter("@attNum10", row("level"))
                param(3) = New SqlClient.SqlParameter("@attNum11", row("live"))
                param(4) = New SqlClient.SqlParameter("@attNum12", row("disabled"))
                param(5) = New SqlClient.SqlParameter("@attNum13", row("undialed"))
                param(6) = New SqlClient.SqlParameter("@attNum14", row("available"))
                ExecuteNonQuery(_conn, CommandType.StoredProcedure, "cm4_updateDiallerDXIStats_byDXIQID", param)
            Next
            'Dim cm As New tPointCM4.clsDXI(_logFile)
            'cm.strConn = _conn
            'cm.updateQueueDXIStats(rdr("id"), _
            '                        httpds.Tables("stats").Rows(0)("level"), _
            '                        httpds.Tables("stats").Rows(0)("live"), _
            '                        httpds.Tables("stats").Rows(0)("disabled"), _
            '                        httpds.Tables("stats").Rows(0)("undialed"), _
            '                        httpds.Tables("stats").Rows(0)("available"))
            ''Loop
            writeLog("updateQueueStats", "End", _logFile)
        Catch ex As Exception
            writeLog("updateQueueStats", "Error: " & ex.Message, _logFile)
        Finally
            If rdr IsNot Nothing Then rdr.Close()
        End Try
    End Sub

    Private Sub writeLog(ByVal src As String, ByVal msg As String, _
                                ByVal logFileName As String, _
                                Optional ByVal blank As Boolean = False)
        Dim fn As Integer
        Try
            fn = FreeFile()
            FileOpen(fn, logFileName, OpenMode.Append, OpenAccess.Write)
            If Not blank Then
                Print(fn, Format(Now, "hh:mm:ss") & vbTab & src & vbTab & msg & vbCrLf)
            Else
                Print(fn, "--------------------------------------------------------------------------------" & vbCrLf)
            End If
        Catch ex As Exception

        Finally
            FileClose(fn)
        End Try
    End Sub

End Class
