Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' Provides collection storage for ForeignKey objects
''' </summary>
<Serializable()> _
Public Class ForeignKeyColumnCollection
    Inherits CollectionBase

    Private _ParentMappingId As Integer
    Private _ConnectionString As String

    ''' <summary>
    ''' The id of the parent mapping
    ''' </summary>
    Friend Property ParentMappingId() As Integer
        Get
            Return _ParentMappingId
        End Get
        Set(ByVal Value As Integer)
            _ParentMappingId = Value
        End Set
    End Property

    'INCOMPLETE
    Public Property ConnectionString() As String
        Get
            If IsNothing(_ConnectionString) OrElse _ConnectionString.Equals(String.Empty) Then _
                Return crmRepositoryWeb.Classes.clsHelper.strConn

            Return _ConnectionString
        End Get
        Set(ByVal Value As String)
            _ConnectionString = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns a foreign key object by collection index
    ''' </summary>
    Default Public Property Item(ByVal index As Integer) As crmDataImporter.Business.ForeignKeyColumn
        Get
            Return MyBase.List.Item(index)
        End Get
        Set(ByVal Value As crmDataImporter.Business.ForeignKeyColumn)
            MyBase.List.Item(index) = Value
        End Set
    End Property

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Loads a key collection for a parent mapping
    ''' </summary>
    Public Sub New(ByVal forParent As crmDataImporter.Business.DataMapping, ByVal connectionString As String)
        If Not IsNothing(connectionString) AndAlso Not connectionString.Equals(String.Empty) Then _
            Me.ConnectionString = connectionString
        Me.LoadFromDb(forParent)
    End Sub

    ''' <summary>
    ''' Checks to make sure only valid objects are added to the collection
    ''' </summary>
    Protected Overrides Sub OnValidate(ByVal value As Object)
        MyBase.OnValidate(value)

        If Not TypeOf value Is crmDataImporter.Business.ForeignKeyColumn Then _
            Throw New ArgumentException("Collection only accepts ForeignKeyColumn objects")
    End Sub

    ''' <summary>
    ''' Adds an object to the collection
    ''' </summary>
    Public Sub Add(ByVal item As crmDataImporter.Business.ForeignKeyColumn)
        MyBase.List.Add(item)
    End Sub

    ''' <summary>
    ''' Removes an object from the collection
    ''' </summary>
    Public Sub Remove(ByVal item As crmDataImporter.Business.ForeignKeyColumn)
        MyBase.List.Remove(item)
    End Sub

    ''' <summary>
    ''' Loads the collection with saved keys for a mapping
    ''' </summary>
    Public Sub LoadFromDb(ByVal parentMapping As crmDataImporter.Business.DataMapping)
        _ParentMappingId = parentMapping.Id

        Dim rawData As DataSet = SqlHelper.ExecuteDataset(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_ForeignKeyField_GetCollection", _
                                                                    New SqlClient.SqlParameter("@@MappingId", Me.ParentMappingId))

        If Not IsNothing(rawData) AndAlso Not IsNothing(rawData.Tables) AndAlso Not rawData.Tables(0).Rows.Count.Equals(0) Then

            For Each fieldRow As DataRow In rawData.Tables(0).Rows
                Me.Add(New crmDataImporter.Business.ForeignKeyColumn(fieldRow))
            Next

            rawData.Dispose()
        End If
    End Sub

    ''' <summary>
    ''' Returns a key for a component field id and source field
    ''' </summary>
    Public Function Find(ByVal componentField As Integer, ByVal sourceField As String) As crmDataImporter.Business.ForeignKeyColumn
        For Each myFk As crmDataImporter.Business.ForeignKeyColumn In Me
            If myFk.ComponentFieldId.Equals(componentField) AndAlso myFk.SourceField = sourceField Then _
                Return myFk
        Next

        Return Nothing
    End Function

    ''' <summary>
    ''' Saves the kwys in the collection to the database
    ''' </summary>
    Public Sub Save()
        'drop saved fields first, unfortunately making the created/by fields fairly meaningless
        SqlHelper.ExecuteNonQuery(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_DeleteForeignKeyFields", _
                                                                    New SqlClient.SqlParameter("@@MappingId", Me.ParentMappingId))

        For Each myFk As crmDataImporter.Business.ForeignKeyColumn In Me
            myFk.Save(Me.ParentMappingId)
        Next
    End Sub

End Class
