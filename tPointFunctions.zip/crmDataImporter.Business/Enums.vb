
Namespace Enums

    ''' <summary>
    ''' Error options
    ''' </summary>
    Public Enum ErrorOption
        SkipErrors = 0
        RollbackOnError = 1
    End Enum

    ''' <summary>
    ''' Duplication options
    ''' </summary>
    Public Enum DuplicationOption
        SkipNew = 0
        Update = 1
        AlwaysAdd = 2
    End Enum

    ''' <summary>
    ''' Dialler export options
    ''' </summary>
    Public Enum DiallerTypes
        None = 0
        DXI = 1
        Broadcast = 2
        tPoint = 3
    End Enum

    ''' <summary>
    ''' Steps of the wizard
    ''' </summary>
    Public Enum WizardStep
        SourceDestination = 1
        Mapping = 2
        Options = 3
        Finish = 4
        FinishWithRun = 5
    End Enum

    'INCOMPLETE
    Public Enum JobStatus
        Pending = 1
        Cancelled = 2
        Queued = 3
        InPogress = 4
        CompletedOk = 5
        CompletedInError = 6
        SendingToDialler = 7
        RunningSP = 8
    End Enum

    'INCOMPLETE
    Public Enum EventId
        GeneralInformation = 10
        GeneralError = 20
        ThreadStart = 30
        ThreadEnd = 40
        DBPoll = 50
        ProcessQueue = 60
        JobQueued = 70
    End Enum

    'INCOMPLETE
    Public Enum DuplicateLevel
        None = 0
        [Single] = 1
        Multiple = 2
    End Enum

    'INCOMPLETE
    Public Enum CreationMode
        Create = 1
        Update = 2
        Skip = 3
    End Enum

End Namespace
