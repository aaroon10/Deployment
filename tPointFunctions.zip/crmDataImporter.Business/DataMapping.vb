Imports crmRepositoryWeb.Classes
Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' Defines source and destination points for data
''' </summary>
<Serializable()>
Public Class DataMapping
    Implements crmDataImporter.Business.IDatabaseObject

#Region " Fields "

    Private _Created, _Updated As Date
    Private _Id, _CreatedBy, _UpdatedBy, _ComponentId, _ParentImportId As Integer
    Private _MappedFields As crmDataImporter.Business.MappedFieldCollection
    Private _ForeignKeys As crmDataImporter.Business.ForeignKeyColumnCollection
    Private _StaticFields As crmDataImporter.Business.StaticFieldCollection
    Private _ConnectionString As String
    Private _ComponentsInObject As DataSet

#End Region

#Region " Properties "

    Private ReadOnly Property UserId() As Integer
        Get
            Return clsCookieHelper.CurrentEmployeeId
        End Get
    End Property

    'INCOMPLETE
    Public Property ConnectionString() As String
        Get
            If IsNothing(_ConnectionString) OrElse _ConnectionString.Equals(String.Empty) Then _
                Return crmRepositoryWeb.Classes.clsHelper.strConn

            Return _ConnectionString
        End Get
        Set(ByVal Value As String)
            _ConnectionString = Value
        End Set
    End Property

    ''' <summary>
    ''' Unique identifier for the mapping
    ''' </summary>
    Public Property Id() As Integer Implements IDatabaseObject.Id
        Get
            Return _Id
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Id = Value
        End Set
    End Property

    ''' <summary>
    ''' Not implemented
    ''' </summary>
    <Xml.Serialization.XmlIgnore()>
    Public Property Name() As String Implements IDatabaseObject.Name
        Get
            Throw New NotImplementedException
        End Get
        Set(ByVal Value As String)
            Throw New NotImplementedException
        End Set
    End Property

    ''' <summary>
    ''' The date that the mapping was created
    ''' </summary>
    Public Property Created() As Date Implements IDatabaseObject.Created
        Get
            Return _Created
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Created = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the user who created the mapping
    ''' </summary>
    Public Property CreatedBy() As Integer Implements IDatabaseObject.CreatedBy
        Get
            Return _CreatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _CreatedBy = Value
        End Set
    End Property

    ''' <summary>
    ''' The data that the mapping was updated
    ''' </summary>
    Public Property Updated() As Date Implements IDatabaseObject.Updated
        Get
            Return _Updated
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Updated = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the user who updated the mapping
    ''' </summary>
    Public Property UpdatedBy() As Integer Implements IDatabaseObject.UpdatedBy
        Get
            Return _UpdatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _UpdatedBy = Value
        End Set
    End Property


    ''' <summary>
    ''' The id of the destination business component
    ''' </summary>
    Public Property ComponentId() As Integer
        Get
            Return _ComponentId
        End Get
        Set(ByVal Value As Integer)
            _ComponentId = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns a code object for the destination business component
    ''' </summary>
    <Xml.Serialization.XmlIgnore()>
    Public ReadOnly Property Component() As crmRepository.clsComponent
        Get
            If Me.ComponentId.Equals(0) Then _
                Throw New InvalidOperationException("Invalid component id")

            Return New crmRepository.clsComponent(crmRepositoryWeb.Classes.clsHelper.strConn, Me.UserId, Me.ComponentId)
        End Get
    End Property

    ''' <summary>
    ''' The id of the parent DataImport
    ''' </summary>
    Friend Property ParentImportId() As Integer
        Get
            Return _ParentImportId
        End Get
        Set(ByVal Value As Integer)
            _ParentImportId = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns a new Job of the parent DataImport
    ''' </summary>
    Public ReadOnly Property ParentImport() As crmDataImporter.Business.DataImport
        Get
            Return New crmDataImporter.Business.DataImport(_ParentImportId)
        End Get
    End Property

    ''' <summary>
    ''' Holds a collection of the mapped fields
    ''' </summary>
    Public ReadOnly Property MappedFields() As crmDataImporter.Business.MappedFieldCollection
        Get
            If IsNothing(_MappedFields) Then _
                _MappedFields = New crmDataImporter.Business.MappedFieldCollection(Me)

            Return _MappedFields
        End Get
    End Property

    ''' <summary>
    ''' Holds a collection of static fields
    ''' </summary>
    Public ReadOnly Property StaticFields() As crmDataImporter.Business.StaticFieldCollection
        Get
            If IsNothing(_StaticFields) Then _
                _StaticFields = New crmDataImporter.Business.StaticFieldCollection(Me)

            Return _StaticFields
        End Get
    End Property

    ''' <summary>
    ''' Holds a collection of foreign keys
    ''' </summary>
    Public ReadOnly Property ForeignKeys() As crmDataImporter.Business.ForeignKeyColumnCollection
        Get
            If IsNothing(_ForeignKeys) Then _
                _ForeignKeys = New crmDataImporter.Business.ForeignKeyColumnCollection(Me, Me.ConnectionString)

            Return _ForeignKeys
        End Get
    End Property

#End Region

#Region " Methods "

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Load a mapping from a DataRow
    ''' </summary>
    Public Sub New(ByVal loadFromRow As DataRow, ByVal connectionString As String)
        Me.Load(loadFromRow, connectionString)
    End Sub

    ''' <summary>
    ''' Create a new mapping for a component id
    ''' </summary>
    Public Sub New(ByVal forComponent As Integer)
        _ComponentId = forComponent
    End Sub

    ''' <summary>
    ''' Loads a mapping from a DataRow
    ''' </summary>
    Public Sub Load(ByVal fromRow As DataRow, ByVal connectionString As String)
        _Id = fromRow.Item("Id")
        _Created = fromRow.Item("Created")
        _CreatedBy = fromRow.Item("CreatedBy")
        _Updated = fromRow.Item("Updated")
        _UpdatedBy = fromRow.Item("UpdatedBy")
        _ComponentId = fromRow.Item("BusCompId")
        _ParentImportId = fromRow.Item("ImportId")

        Me.ConnectionString = connectionString
    End Sub

    ''' <summary>
    ''' Saves the mapping to the database
    ''' </summary>
    Public Sub Save()
        'save mapping
        Dim params(4) As SqlClient.SqlParameter

        params(0) = New SqlClient.SqlParameter("@@Id", Me.Id)

        If Me.Id.Equals(0) Then _
            params(1) = New SqlClient.SqlParameter("@@CreatedBy", Me.UserId)

        params(2) = New SqlClient.SqlParameter("@@UpdatedBy", Me.UserId)
        params(3) = New SqlClient.SqlParameter("@@BusCompId", Me.ComponentId)
        params(4) = New SqlClient.SqlParameter("@@ImportId", Me.ParentImportId)

        Dim returnId As Integer = SqlHelper.ExecuteScalar(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_SaveMapping", params)

        If Not Me.Id.Equals(returnId) Then _
            _Id = returnId

        'save mappedfields
        MappedFields.ParentMappingId = Me.Id
        MappedFields.Save()

        'save staticfields
        StaticFields.ParentMappingId = Me.Id
        StaticFields.Save()

        'save foreignkeys
        ForeignKeys.ParentMappingId = Me.Id
        ForeignKeys.Save()
    End Sub

    Public Function ContainsMappingInfo() As Boolean
        For Each myField As crmDataImporter.Business.MappedField In Me.MappedFields
            If Not myField.ComponentFieldId.Equals(0) AndAlso Not (IsNothing(myField.SourceField) OrElse myField.SourceField.Equals(String.Empty)) Then _
                Return True
        Next
        For Each myField As crmDataImporter.Business.MappedField In Me.StaticFields
            If Not myField.ComponentFieldId.Equals(0) AndAlso Not (IsNothing(myField.StaticValue) OrElse myField.StaticValue.Equals(String.Empty)) Then _
                Return True
        Next
        For Each myField As crmDataImporter.Business.ForeignKeyColumn In Me.ForeignKeys
            If Not myField.ComponentFieldId.Equals(0) AndAlso Not (IsNothing(myField.SourceField) OrElse myField.SourceField.Equals(String.Empty)) Then _
                Return True
        Next
    End Function

    Public Function BelongsToObject() As Boolean
        If IsNothing(_ComponentsInObject) Then _
            _ComponentsInObject = Me.ParentImport.DestinationObject.listBusCompSimple

        For Each myRow As DataRow In _ComponentsInObject.Tables(0).Rows
            If myRow.Item("id") = Me.ComponentId Then _
                Return True
        Next

        Return False
    End Function

    'INCOMPLETE
    Public Sub Delete()
        'should only be called when there are no fields left
        'If Me.ContainsMappingInfo Then _
        '    Throw New Exception("Cannot delete a mapping that contains mapped/static/foreign-key fields")


        'we really need to delete these from the db too...
        Me.MappedFields.Clear()
        Me.StaticFields.Clear()
        Me.ForeignKeys.Clear()

        SqlHelper.ExecuteNonQuery(Me.ConnectionString, CommandType.Text, "delete from g_DataImport_Mapping where Id = " & Me.Id)
    End Sub

#End Region

End Class
