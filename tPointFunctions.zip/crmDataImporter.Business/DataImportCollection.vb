Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' Provides collection storage for DataImport objects
''' </summary>
<Serializable()> _
Public Class DataImportCollection
    Inherits CollectionBase

    ''' <summary>
    ''' Returns a DataImport item by collection index
    ''' </summary>
    Default Public Property Item(ByVal index As Integer) As crmDataImporter.Business.DataImport
        Get
            Return MyBase.List.Item(index)
        End Get
        Set(ByVal Value As crmDataImporter.Business.DataImport)
            MyBase.List.Item(index) = Value
        End Set
    End Property

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Checks to make sure only valid objects are added to the collection
    ''' </summary>
    Protected Overrides Sub OnValidate(ByVal value As Object)
        MyBase.OnValidate(value)

        If Not TypeOf value Is crmDataImporter.Business.DataImport Then _
            Throw New ArgumentException("Collection only accepts DataImport objects")
    End Sub

    ''' <summary>
    ''' Adds an object to the collection
    ''' </summary>
    Public Sub Add(ByVal item As crmDataImporter.Business.DataImport)
        MyBase.List.Add(item)
    End Sub

    ''' <summary>
    ''' Removes an object from the collection
    ''' </summary>
    Public Sub Remove(ByVal item As crmDataImporter.Business.DataImport)
        MyBase.List.Remove(item)
    End Sub

    ''' <summary>
    ''' Loads the collection with saved data imports
    ''' </summary>
    Public Sub LoadFromDb()
        Dim rawData As DataSet = SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_GetCollection")

        If Not IsNothing(rawData) AndAlso Not IsNothing(rawData.Tables) AndAlso Not rawData.Tables(0).Rows.Count.Equals(0) Then

            For Each importRow As DataRow In rawData.Tables(0).Rows
                Me.Add(New crmDataImporter.Business.DataImport(importRow))
            Next

            rawData.Dispose()
        End If
    End Sub

    Public Sub LoadFromDbSortedByName()
        Dim rawData As DataSet = SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_GetCollectionSortedByName")

        If Not IsNothing(rawData) AndAlso Not IsNothing(rawData.Tables) AndAlso Not rawData.Tables(0).Rows.Count.Equals(0) Then

            For Each importRow As DataRow In rawData.Tables(0).Rows
                Me.Add(New crmDataImporter.Business.DataImport(importRow))
            Next

            rawData.Dispose()
        End If
    End Sub

    Public Function LoadExportReportsFromDbSortedByName() As DataTable

        Dim rawData As DataSet = SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataExport_GetExportCollectionSortedByName")

        If (Not rawData Is Nothing) Then
            Return rawData.Tables(0)
        Else
            Return Nothing
        End If

        'If Not IsNothing(rawData) AndAlso Not IsNothing(rawData.Tables) AndAlso Not rawData.Tables(0).Rows.Count.Equals(0) Then

        '    For Each importRow As DataRow In rawData.Tables(0).Rows
        '        Me.Add(New crmDataImporter.Business.DataImport(importRow))
        '    Next

        '    rawData.Dispose()
        'End If
    End Function



End Class
