Imports Microsoft.ApplicationBlocks.Data
Imports System.Text.RegularExpressions
Imports crmRepositoryWeb.Classes

<Serializable()> _
Public Class Job
    Implements IDatabaseObject

#Region " Fields "

    Private _Id, _CreatedBy, _UpdatedBy, _ParentImportId, _TotalLines, _CompletedLines, _ProcessedLines, _ReportId, _SPId, _EmailTemplateId, _FTPSiteId, _EmailRecordId, _NoDataEmailTemplateId As Integer
    Private _CreatedRecords, _UpdatedRecords, _SkippedRecords, _DiallerExportProgress, _ScheduledFileTemplate As Integer 'Mark - 4/10/2012 - Added _ScheduledFileTemplate
    Private _DiskFile As DataSource
    Private _Created, _Updated, _ScheduledStart, _ScheduledEnd As Date 'Mark - 4/10/2012 - Added _ScheduledEnd
    Private _ImportErrors As ImportErrorCollection
    Private _Status As Enums.JobStatus
    Private _ConnectionString, _CustomSPDB As String
    Private _TablesWrittenTo As ArrayList
    Private _ScheduledFrequency As String 'Mark - 26/9/2012 - Added scheduling 
    Private _HasHeaders, _IncludeHeadings, _EmailIfNoData, _FTPIfNoData As Boolean        'Mark - 26/9/2012 - Added Header and Separator options
    Private _Delimiter, _ExportDelimiter, _FileName, _FileSuffix, _EmailRecipient, _FileType, _PostProcessSP As String

    <Xml.Serialization.XmlIgnore()> _
    Private _SerializedImport As String
    <Xml.Serialization.XmlIgnore()> _
    Private _ParentImport As DataImport

    Public Event ImportFinished(ByVal sender As Object)

#End Region

#Region " Properties "

    Private ReadOnly Property UserId() As Integer
        Get
            If IsNothing(Web.HttpContext.Current) Then _
                Return Me.UpdatedBy

            Return clsCookieHelper.CurrentEmployeeId
        End Get
    End Property


    ''' <summary>
    ''' Unique identifier for the Job
    ''' </summary>
    Public Property Id() As Integer Implements IDatabaseObject.Id
        Get
            Return _Id
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Id = Value
        End Set
    End Property

    ''' <summary>
    ''' Not implemented
    ''' </summary>
    <Xml.Serialization.XmlIgnore()> _
    Public Property Name() As String Implements IDatabaseObject.Name
        Get
            Throw New NotImplementedException
        End Get
        Set(ByVal Value As String)
            Throw New NotImplementedException
        End Set
    End Property

    ''' <summary>
    ''' The date that the Job was created
    ''' </summary>
    Public Property Created() As Date Implements IDatabaseObject.Created
        Get
            Return _Created
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Created = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the user who created the Job
    ''' </summary>
    Public Property CreatedBy() As Integer Implements IDatabaseObject.CreatedBy
        Get
            Return _CreatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _CreatedBy = Value
        End Set
    End Property

    ''' <summary>
    ''' The date that the Job was updated
    ''' </summary>
    Public Property Updated() As Date Implements IDatabaseObject.Updated
        Get
            Return _Updated
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Updated = Value
        End Set
    End Property

    ''' <summary>
    ''' The user id of the person who updated the Job
    ''' </summary>
    Public Property UpdatedBy() As Integer Implements IDatabaseObject.UpdatedBy
        Get
            Return _UpdatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _UpdatedBy = Value
        End Set
    End Property


    Public ReadOnly Property TotalLines() As Integer
        Get
            If _TotalLines.Equals(0) Then
                'Dim myDataObject As API.DataObject = Me.DiskFile.GetDataObject
                '_TotalLines = myDataObject.Length
                'myDataObject.Dispose()

                _TotalLines = Me.DiskFile.DataProvider.Length
            End If

            Return _TotalLines
        End Get
    End Property

    Public ReadOnly Property CompletedLines() As Integer
        Get
            Return _CompletedLines
        End Get
    End Property

    Public ReadOnly Property ProcessedLines() As Integer
        Get
            Return _ProcessedLines
        End Get
    End Property

    Public ReadOnly Property CreatedRecords() As Integer
        Get
            Return _CreatedRecords
        End Get
    End Property

    Public ReadOnly Property UpdatedRecords() As Integer
        Get
            Return _UpdatedRecords
        End Get
    End Property

    Public ReadOnly Property SkippedRecords() As Integer
        Get
            Return _SkippedRecords
        End Get
    End Property

    'INCOMPLETE
    Public Property ConnectionString() As String
        Get
            If IsNothing(_ConnectionString) OrElse _ConnectionString.Equals(String.Empty) Then _
                Return crmRepositoryWeb.Classes.clsHelper.strConn
            Return _ConnectionString
        End Get
        Set(ByVal Value As String)
            _ConnectionString = Value
        End Set
    End Property

    'INCOMPLETE
    Public ReadOnly Property ImportErrors() As ImportErrorCollection
        Get
            If IsNothing(_ImportErrors) Then _
                _ImportErrors = New crmDataImporter.Business.ImportErrorCollection(Me)

            Return _ImportErrors
        End Get
    End Property

    'INCOMPLETE
    Public Property ParentImportId() As Integer
        Get
            Return _ParentImportId
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _ParentImportId = Value
        End Set
    End Property

    'INCOMPLETE
    <Xml.Serialization.XmlIgnore()> _
    Public ReadOnly Property ParentImport() As DataImport
        Get
            If IsNothing(_SerializedImport) OrElse _SerializedImport.Equals(String.Empty) Then _
                Throw New Exception("Could not find serialized parent import - ensure job has a ParentImportId and save before calling ParentImport")

            If IsNothing(_ParentImport) Then
                Dim myDoc As New Xml.XmlDocument
                myDoc.LoadXml(_SerializedImport)
                _ParentImport = DirectCast(Serializing.Deserialize(myDoc, GetType(DataImport)), DataImport)
                _ParentImport.ConnectionString = Me.ConnectionString
            End If

            Return _ParentImport
        End Get
    End Property

    'INCOMPLETE
    Public Property DiskFile() As DataSource
        Get
            If IsNothing(_DiskFile) Then _
                _DiskFile = New DataSource(Me.ConnectionString)
            Return _DiskFile
        End Get
        Set(ByVal value As DataSource)
            _DiskFile = value
        End Set
    End Property

    'INCOMPLETE
    Public Property Status() As Enums.JobStatus
        Get
            Return _Status
        End Get
        Set(ByVal value As Enums.JobStatus)
            _Status = value
        End Set
    End Property

    'INCOMPLETE
    Public Property ScheduledStart() As Date
        Get
            Return _ScheduledStart
        End Get
        Set(ByVal Value As Date)
            _ScheduledStart = Value
        End Set
    End Property

    Public Property ScheduledEnd() As Date
        Get
            Return _ScheduledEnd
        End Get
        Set(ByVal Value As Date)
            _ScheduledEnd = Value
        End Set
    End Property

    'INCOMPLETE
    Public Property DiallerExportProgress() As Integer
        Get
            Return _DiallerExportProgress
        End Get
        Set(ByVal value As Integer)
            _DiallerExportProgress = value
        End Set
    End Property

    Public Property ScheduledFrequency() As String
        Get
            Return _ScheduledFrequency
        End Get
        Set(ByVal Value As String)
            _ScheduledFrequency = Value
        End Set
    End Property

    Public Property ScheduledFileTemplate() As Integer
        Get
            Return _ScheduledFileTemplate
        End Get
        Set(ByVal Value As Integer)
            _ScheduledFileTemplate = Value
        End Set
    End Property

    Public Property ReportId() As Integer
        Get
            Return _ReportId
        End Get
        Set(ByVal Value As Integer)
            _ReportId = Value
        End Set
    End Property

    Public Property SPId() As Integer
        Get
            Return _SPId
        End Get
        Set(ByVal Value As Integer)
            _SPId = Value
        End Set
    End Property

    Public Property HasHeaders() As Boolean
        Get
            Return _HasHeaders
        End Get
        Set(ByVal Value As Boolean)
            _HasHeaders = Value
        End Set
    End Property

    Public Property Delimiter() As String
        Get
            Return _Delimiter
        End Get
        Set(ByVal Value As String)
            _Delimiter = Value
        End Set
    End Property

    Public Property ExportDelimiter() As String
        Get
            Return _ExportDelimiter
        End Get
        Set(ByVal Value As String)
            _ExportDelimiter = Value
        End Set
    End Property

    Public Property FileName() As String
        Get
            Return _FileName
        End Get
        Set(ByVal Value As String)
            _FileName = Value
        End Set
    End Property

    Public Property FileSuffix() As String
        Get
            Return _FileSuffix
        End Get
        Set(ByVal Value As String)
            _FileSuffix = Value
        End Set
    End Property

    Public Property FileType() As String
        Get
            Return _FileType
        End Get
        Set(ByVal Value As String)
            _FileType = Value
        End Set
    End Property

    Public Property IncludeHeadings() As Boolean
        Get
            Return _IncludeHeadings
        End Get
        Set(ByVal Value As Boolean)
            _IncludeHeadings = Value
        End Set
    End Property

    Public Property EmailRecipient() As String
        Get
            Return _EmailRecipient
        End Get
        Set(ByVal Value As String)
            _EmailRecipient = Value
        End Set
    End Property

    Public Property EmailTemplateId() As Integer
        Get
            Return _EmailTemplateId
        End Get
        Set(ByVal Value As Integer)
            _EmailTemplateId = Value
        End Set
    End Property

    Public Property FTPSiteId() As Integer
        Get
            Return _FTPSiteId
        End Get
        Set(ByVal Value As Integer)
            _FTPSiteId = Value
        End Set
    End Property

    Public Property EmailRecordId() As Integer
        Get
            Return _EmailRecordId
        End Get
        Set(ByVal Value As Integer)
            _EmailRecordId = Value
        End Set
    End Property

    Public Property EmailIfNoData() As Boolean
        Get
            Return _EmailIfNoData
        End Get
        Set(ByVal Value As Boolean)
            _EmailIfNoData = Value
        End Set
    End Property

    Public Property NoDataEmailTemplateId() As Integer
        Get
            Return _NoDataEmailTemplateId
        End Get
        Set(ByVal Value As Integer)
            _NoDataEmailTemplateId = Value
        End Set
    End Property

    Public Property FTPIfNoData() As Boolean
        Get
            Return _FTPIfNoData
        End Get
        Set(ByVal Value As Boolean)
            _FTPIfNoData = Value
        End Set
    End Property

    Public Property PostProcessSP() As String
        Get
            Return _PostProcessSP
        End Get
        Set(ByVal Value As String)
            _PostProcessSP = Value
        End Set
    End Property

    Public Property CustomSPDB() As String
        Get
            Return _CustomSPDB
        End Get
        Set(ByVal Value As String)
            _CustomSPDB = Value
        End Set
    End Property

#End Region

#Region " Methods "

    Public Sub New()
        _Status = Enums.JobStatus.Pending
    End Sub

    ''' <summary>
    ''' Load an Job from a DataRow
    ''' </summary>
    Public Sub New(ByVal loadFromRow As DataRow)
        Me.New()
        Me.Load(loadFromRow)
    End Sub

    'INCOMPLETE
    ''' <summary>
    ''' Create a new Job for the specified parent data import
    ''' </summary>
    Public Sub New(ByVal importId As Integer)
        Me.New()
        _ParentImportId = importId
    End Sub

    ''' <summary>
    ''' Load an Job from a DataRow
    ''' </summary>
    Public Sub Load(ByVal fromRow As DataRow)
        _Id = fromRow.Item("Id")
        _Created = fromRow.Item("Created")
        _CreatedBy = fromRow.Item("CreatedBy")
        _Updated = fromRow.Item("Updated")
        _CreatedBy = fromRow.Item("CreatedBy")
        _ParentImportId = fromRow.Item("HeaderId")
        _Status = fromRow.Item("Status")
        _SerializedImport = fromRow.Item("SerializedImport")

        _TotalLines = fromRow.Item("TotalLines")
        _CompletedLines = fromRow.Item("Completedlines")
        _DiallerExportProgress = fromRow.Item("DiallerExportProgress")
        If IsDBNull(fromRow.Item("HasHeaders")) Then
            _HasHeaders = 1
        Else
            _HasHeaders = fromRow.Item("HasHeaders")
        End If
        If IsDBNull(fromRow.Item("Delimiter")) Then
            _Delimiter = ","
        Else
            _Delimiter = fromRow.Item("Delimiter")
        End If

        If Not IsDBNull(fromRow.Item("ScheduledStart")) Then
            _ScheduledStart = fromRow.Item("ScheduledStart")
        End If

        If IsDBNull(fromRow.Item("PostProcessSP")) Then
            _PostProcessSP = ""
        Else
            _PostProcessSP = fromRow.Item("PostProcessSP")
        End If

        If Not IsDBNull(fromRow.Item("DiskFileId")) AndAlso Convert.ToInt32(fromRow.Item("DiskFileId")) > 0 Then _
            _DiskFile = New DataSource(Convert.ToInt32(fromRow.Item("DiskFileId")), Me.ConnectionString, _HasHeaders, _Delimiter, True)
    End Sub

    'INCOMPLETE
    Public Sub Save()
        Me.Save(Me.ParentImportId)
    End Sub

    ''' <summary>
    ''' Save the Job to the database
    ''' </summary>
    Public Sub Save(ByVal parentImportId As Integer)
        'make sure the diskfile is saved because we need the id later
        If Not Me.DiskFile.DiskPath.Equals(String.Empty) Then _
             Me.DiskFile.Save()



        Dim params(13) As SqlClient.SqlParameter

        params(0) = New SqlClient.SqlParameter("@@Id", Me.Id)

        If Me.Id.Equals(0) Then _
            params(1) = New SqlClient.SqlParameter("@@CreatedBy", Me.UserId)

        params(2) = New SqlClient.SqlParameter("@@UpdatedBy", Me.UserId)
        params(3) = New SqlClient.SqlParameter("@@HeaderId", parentImportId)
        params(4) = New SqlClient.SqlParameter("@@DiskFileId", Me.DiskFile.Id)
        params(5) = New SqlClient.SqlParameter("@@Status", Me.Status)
        params(8) = New SqlClient.SqlParameter("@@DiallerExportProgress", Me.DiallerExportProgress)

        If IsNothing(_SerializedImport) OrElse _SerializedImport.Equals(String.Empty) Then
            Dim myDoc As Xml.XmlDocument = Serializing.Serialize(New DataImport(Me.ParentImportId, Me.ConnectionString))
            _SerializedImport = myDoc.OuterXml
            params(6) = New SqlClient.SqlParameter("@@SerializedImport", _SerializedImport)
        End If

        If Not _ScheduledStart.Equals(Date.MinValue) Then
            params(7) = New SqlClient.SqlParameter("@@ScheduledStart", _ScheduledStart)
            params(7).DbType = DbType.DateTime
            'params(9) = New SqlClient.SqlParameter("@@ScheduledEnd", _ScheduledEnd)
            'params(10) = New SqlClient.SqlParameter("@@ScheduledFrequency", _ScheduledFrequency)
            'params(11) = New SqlClient.SqlParameter("@@ScheduledFileTemplate", _ScheduledFileTemplate)
        End If

        params(12) = New SqlClient.SqlParameter("@@HasHeaders", _HasHeaders)
        params(13) = New SqlClient.SqlParameter("@@Delimiter", _Delimiter)

        Dim returnId As Integer = SqlHelper.ExecuteScalar(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_SaveJobv2", params)

        If Not Me.Id.Equals(returnId) Then _
            _Id = returnId
    End Sub


    ''' <summary>
    ''' Save the Job to the database
    ''' </summary>
    Public Sub SaveExport()

        Dim params(16) As SqlClient.SqlParameter
        params(0) = New SqlClient.SqlParameter("@CreatedBy", Me.UserId)
        params(1) = New SqlClient.SqlParameter("@ReportId", Me.ReportId)
        params(2) = New SqlClient.SqlParameter("@QueryId", 0)
        params(3) = New SqlClient.SqlParameter("@SPId", Me.SPId)
        params(4) = New SqlClient.SqlParameter("@FileName", Me.FileName)
        params(5) = New SqlClient.SqlParameter("@IncludeColumnHeadings", Me.IncludeHeadings)
        params(6) = New SqlClient.SqlParameter("@EmailRecipient", Me.EmailRecipient)
        params(7) = New SqlClient.SqlParameter("@EmailTemplateId", Me.EmailTemplateId)
        params(8) = New SqlClient.SqlParameter("@FTPSiteId", Me.FTPSiteId)
        params(9) = New SqlClient.SqlParameter("@EmailRecordId", Me.EmailRecordId)
        params(10) = New SqlClient.SqlParameter("@FileType", Me.FileType)
        params(11) = New SqlClient.SqlParameter("@Delimiter", Me.ExportDelimiter)
        params(12) = New SqlClient.SqlParameter("@FileNameSuffix", Me.FileSuffix)
        params(13) = New SqlClient.SqlParameter("@EmailIfNoData", Me.EmailIfNoData)
        params(14) = New SqlClient.SqlParameter("@NoDataEmailTemplateId", Me.NoDataEmailTemplateId)
        params(15) = New SqlClient.SqlParameter("@FTPIfNoData", Me.FTPIfNoData)

        Dim returnId As Integer = SqlHelper.ExecuteScalar(Me.ConnectionString, CommandType.StoredProcedure, "g_DataExport_SaveJob", params)

        If Not Me.Id.Equals(returnId) Then _
            _Id = returnId
    End Sub

    ''' <summary>
    ''' Save the Job to the database
    ''' </summary>
    Public Sub SaveDownloadDates(jobId As Integer, isExport As Boolean)

        Dim params(2) As SqlClient.SqlParameter
        params(0) = New SqlClient.SqlParameter("@JobId", jobId)
        params(1) = New SqlClient.SqlParameter("@Export", isExport)
        SqlHelper.ExecuteNonQuery(Me.ConnectionString, CommandType.StoredProcedure, "[g_DataImportExport_SaveDownloadDates]", params)

    End Sub

    Private Sub UpdateProgress()
        If Me.Id.Equals(0) Then _
            Throw New Exception("Cannot update progress for an unsaved job")

        Dim params(7) As SqlClient.SqlParameter

        params(0) = New SqlClient.SqlParameter("@@Id", Me.Id)
        params(1) = New SqlClient.SqlParameter("@@TotalLines", Me.TotalLines)
        params(2) = New SqlClient.SqlParameter("@@CompletedLines", Me.CompletedLines)
        params(3) = New SqlClient.SqlParameter("@@ProcessedLines", Me.ProcessedLines)
        params(5) = New SqlClient.SqlParameter("@@CreatedRecords", Me.CreatedRecords)
        params(6) = New SqlClient.SqlParameter("@@UpdatedRecords", Me.UpdatedRecords)
        params(7) = New SqlClient.SqlParameter("@@SkippedRecords", Me.SkippedRecords)

        'serialize the table write log and send to the db so we know what tables to rollback in the future
        If Not IsNothing(_TablesWrittenTo) AndAlso Not _TablesWrittenTo.Count = 0 Then _
            params(4) = New SqlClient.SqlParameter("@@TablesWrittenTo", Serializing.Serialize(_TablesWrittenTo.ToArray(GetType(String))).OuterXml)

        SqlHelper.ExecuteNonQuery(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_UpdateProgress", params)
    End Sub

    Private Sub SetStarted()
        If Me.Id.Equals(0) Then _
            Throw New Exception("Cannot set start time for an unsaved job")
        SqlHelper.ExecuteNonQuery(Me.ConnectionString, CommandType.Text, "update g_DataImport_Job set StartTime = getdate() where Id = " & Me.Id)
    End Sub

    'INCOMPLETE
    Public Sub ImportData()
        Dim currentLine, primaryRecordId, primaryComponentId As Integer
        Dim priComponent, secComponent As crmRepository.clsComponent
        Dim foundRecords, parentRecords As DataSet

        Dim lastLine As Integer = -1

        Console.WriteLine("Start ImportData...")

        priComponent = Nothing
        foundRecords = Nothing
        parentRecords = Nothing

        'first off update the db record to indicate when we started the job
        Me.SetStarted()

        Try
            If IsNothing(Me.DiskFile.DataProvider) Then _
                LogError(0, "An unknown error occured while initialising the DataObject provider")
        Catch ex As Exception
            LogError(0, ex.Message)
        End Try

        Console.WriteLine("DiskFile location..." & Me.DiskFile.DiskPath)

        If ImportErrors.Count = 0 Then
            'loop through e y line in the data file
            While Me.DiskFile.DataProvider.Read
                Try
                    'Console.WriteLine("...DiskFile read")

                    currentLine = Me.DiskFile.DataProvider.CurrentRecordIndex

                    primaryComponentId = Me.ParentImport.DestinationObject.getPrimaryBusCompId

                    If priComponent Is Nothing Then 'MOD 16/3/2009 - Perf improvement - instantiate componenet once only

                        Dim lsCutDownBC As String = ""
                        Dim appSettings As crmFoundation.clsApplication = Nothing
                        If IsNothing(appSettings) Then
                            appSettings = New crmFoundation.clsApplication
                            appSettings.strConn = Me.ConnectionString
                            lsCutDownBC = appSettings.getAppSetting("ImporterCutDownBC")
                        End If
                        If UCase(lsCutDownBC) = "TRUE" Then
                            priComponent = New crmRepository.clsComponent(Me.ConnectionString, Me.CreatedBy, primaryComponentId, , False) 'MOD - 31/08/2017 - Cut down bc
                            priComponent.addField("Id")
                            priComponent.addField("Record Type")
                        Else
                            priComponent = New crmRepository.clsComponent(Me.ConnectionString, Me.CreatedBy, primaryComponentId)
                        End If
                    Else
                        priComponent.recordId = 0
                    End If

                    'priComponent = New crmRepository.clsComponent(Me.ConnectionString, Me.CreatedBy, primaryComponentId, "", False) 'MOD 16/3/2009
                    primaryRecordId = 0

                    For Each myMapping As DataMapping In Me.ParentImport.DataMappings
                        If myMapping.ComponentId = primaryComponentId Then
                            'process primary component
                            'priComponent = New crmRepository.clsComponent(Me.ConnectionString, Me.CreatedBy, primaryComponentId) 'possibly move to outside loop, effect on setFld?
                            foundRecords = Me.FindMatches(priComponent, myMapping, Me.DiskFile.DataProvider)

                            If lastLine <> currentLine Then
                                primaryRecordId = Me.ImportIntoComponent(priComponent, foundRecords, myMapping, Me.DiskFile.DataProvider, priComponent)
                            End If
                        Else
                            'process secondary components
                            foundRecords = Nothing
                            secComponent = New crmRepository.clsComponent(Me.ConnectionString, Me.CreatedBy, myMapping.ComponentId)

                            'do we have/want a valid parentRecordId to pass to our secondary component record?
                            If primaryRecordId.Equals(0) Then
                                If Not IsNothing(myMapping.ForeignKeys) AndAlso myMapping.ForeignKeys.Count > 0 Then
                                    'if we cant find a record then throw an exception
                                    parentRecords = Me.FindMatchesFk(priComponent, myMapping, Me.DiskFile.DataProvider)

                                    Select Case Me.DupeLevel(parentRecords)
                                        Case Enums.DuplicateLevel.Multiple
                                            Throw New Exception("Multiple possible parent records found")
                                        Case Enums.DuplicateLevel.None
                                            Throw New Exception("Foreign keys specified but no parent record found")
                                        Case Enums.DuplicateLevel.Single
                                            If IsNothing(parentRecords.Tables(0).Columns("Id")) Then _
                                                Throw New Exception("No 'Id' column found in primary component")
                                            primaryRecordId = parentRecords.Tables(0).Rows(0).Item("Id")
                                    End Select
                                End If
                                'still here without a parentRecordId? no bother
                            End If
                            foundRecords = Me.FindMatches(secComponent, myMapping, Me.DiskFile.DataProvider, primaryRecordId)
                            If lastLine <> currentLine Then Me.ImportIntoComponent(secComponent, foundRecords, myMapping, Me.DiskFile.DataProvider, priComponent, primaryRecordId)
                        End If
                    Next

                    If lastLine <> currentLine Then
                        _CompletedLines += 1
                    End If

                Catch ex As Exception
                    LogError(currentLine + 2, ex.Message) 'we add two because line 1 in the data file is a header and the currentLine var is actually an index
                    If Me.ParentImport.ErrorOption = Enums.ErrorOption.RollbackOnError Then
                        Try
                            Me.Rollback()
                        Catch ex2 As Exception
                            'most likely cause is an old-style data import with the same id
                            LogError(0, ex2.Message)
                        End Try

                        _ProcessedLines = Me.TotalLines
                        Exit While
                    End If
                Finally
                    'MOD 16/3/2009 - Perf improvement - reduce the number of time we update progress
                    If lastLine <> currentLine Then
                        If Not _ProcessedLines = Me.TotalLines Then
                            _ProcessedLines += 1
                            Me.UpdateProgress()
                            lastLine = currentLine
                        End If
                    End If

                    ''If lastLine <> currentLine Then
                    ''    If _ProcessedLines < Me.TotalLines And Me.TotalLines > 9 Then
                    ''        'If Not _ProcessedLines = Me.TotalLines Then        'MOD 20/2/2010 - This was causing the importer to crash if less than 10 lines were loaded
                    ''        If (_ProcessedLines Mod CInt(Me.TotalLines / 10)) = 0 Then
                    ''            _ProcessedLines += 1
                    ''            Me.UpdateProgress()
                    ''            lastLine = currentLine
                    ''        End If
                    ''    Else
                    ''        If Not _ProcessedLines = Me.TotalLines Then
                    ''            _ProcessedLines += 1
                    ''            Me.UpdateProgress()
                    ''            lastLine = currentLine
                    ''        End If
                    ''    End If
                    ''End If

                    'tidy up
                    If Not IsNothing(foundRecords) Then _
                        foundRecords.Dispose()
                    If Not IsNothing(parentRecords) Then _
                        parentRecords.Dispose()
                End Try

            End While
        End If

        'MOD - 18/02/2013 - ExecPostProcessSP - Moved to before the send to dialler (just in case some massaging of the contact needs to take place).
        If Me.ImportErrors.Count.Equals(0) Then
            Try
                Me.Status = Enums.JobStatus.RunningSP
                Me.Save()

                If PostProcessSP <> String.Empty Then
                    ExecPostProcessSP()
                End If
            Catch ex As Exception
                LogError(0, ex.Message)
            End Try
        End If

        'we may need to export the newly imported data to a hosted dialler
        If Not IsNothing(Me.ParentImport.DiallerProvider) Then
            Me.Status = Enums.JobStatus.SendingToDialler
            Me.Save()

            If Me.ImportErrors.Count.Equals(0) Then
                With Me.ParentImport.DiallerProvider
                    'handle events and start thread
                    AddHandler .OperationProgressChanged, AddressOf DiallerExportProgressChanged
                    AddHandler .OperationCompleted, AddressOf DiallerExportCompleted

                    Dim exportThread As New Threading.Thread(AddressOf .PerformOperation)
                    exportThread.Start(Me)

                End With
            Else
                Me.LogError(0, "Dialler export not performed due to errors with data import")
                EndOfImport()
            End If
        Else
            'go straight to the end of the process
            EndOfImport()
        End If

    End Sub

    Private Sub DiallerExportProgressChanged(ByVal toValue As Integer)
        'update dialler export progress
        Me.DiallerExportProgress = toValue
        Me.Save()
    End Sub

    Private Sub DiallerExportCompleted(ByVal errors As List(Of Exception))
        If Not IsNothing(errors) Then
            For Each myEx As Exception In errors
                LogError(0, myEx.Message)
            Next
        End If

        EndOfImport()
    End Sub

    Private Sub EndOfImport()
        Me.DiskFile.Dispose()
        If Not IsNothing(_ParentImport) Then _
            _ParentImport.Dispose()

        If ImportErrors.Count = 0 Then
            Me.Status = Enums.JobStatus.CompletedOk
        Else
            Me.Status = Enums.JobStatus.CompletedInError
        End If

        Me.Save()

        RaiseEvent ImportFinished(Me)
    End Sub

    Private Function ImportIntoComponent(ByRef component As crmRepository.clsComponent, _
                                            ByRef existingData As DataSet, _
                                            ByRef mapping As DataMapping, _
                                            ByRef myDataObject As API.DataObject, _
                                            ByRef primaryComponent As crmRepository.clsComponent, _
                                            Optional ByVal parentRecordId As Integer = 0) As Integer
        Dim dupeLevel As Enums.DuplicateLevel = Me.DupeLevel(existingData)
        Dim creationMode As Enums.CreationMode = Enums.CreationMode.Skip
        Dim recordId As Integer

        'first check the duplication option
        Select Case Me.ParentImport.DupeOption
            Case Enums.DuplicationOption.AlwaysAdd
                creationMode = Enums.CreationMode.Create
            Case Enums.DuplicationOption.SkipNew
                'no update or create if there's a dupe
                If dupeLevel = Enums.DuplicateLevel.None Then _
                    creationMode = Enums.CreationMode.Create
            Case Enums.DuplicationOption.Update
                'update duplicate if one exists
                If dupeLevel = Enums.DuplicateLevel.Multiple Then _
                    Throw New Exception("Unable to import row into component '" & component.name & "' due to multiple pre-existing duplicates")

                creationMode = Enums.CreationMode.Create
                If dupeLevel = Enums.DuplicateLevel.Single Then _
                    creationMode = Enums.CreationMode.Update
        End Select

        'now do some work based on our creationMode
        Select Case creationMode
            Case Enums.CreationMode.Skip
                _SkippedRecords += 1
                Return 0
            Case Enums.CreationMode.Create
                'create a new record, return id
                Try
                    If (IsNothing(mapping.MappedFields) OrElse mapping.MappedFields.Count = 0) And (IsNothing(mapping.StaticFields) OrElse mapping.StaticFields.Count = 0) Then _
                        Throw New Exception("No fields mapped")

                    component.newRecord()

                    Me.ModifyRecord(component, mapping, myDataObject, primaryComponent, 0, parentRecordId)

                    component.ImportId = Me.Id
                    component.updateRecord()

                    'we should have a recordid now - if not, something probably went wrong
                    If component.recordId = 0 Then _
                        Throw New Exception(component.errMsg)

                    Me.LogTableWrite(component.table)
                    recordId = component.recordId

                    _CreatedRecords += 1
                Catch ex As Exception
                    Throw New Exception("Unable to create record in component '" & component.name & "': " & ex.Message)
                End Try
            Case Enums.CreationMode.Update
                'update existing record found in existingData, return id
                Try
                    If IsNothing(existingData.Tables(0).Columns("Id")) Then _
                        Throw New Exception("No 'Id' column found in component")

                    recordId = existingData.Tables(0).Rows(0).Item("Id")
                    component.newRecord()
                    component.recordId = recordId
                    component.setSQL()
                    component.getRecord()

                    Me.ModifyRecord(component, mapping, myDataObject, primaryComponent, recordId)

                    component.updateRecord()

                    'trapping for silent error
                    If Not IsNothing(component.errMsg) AndAlso Not component.errMsg.Equals(String.Empty) Then _
                        Throw New Exception(component.errMsg)

                    _UpdatedRecords += 1
                Catch ex As Exception
                    Throw New Exception("Unable to update record in component '" & component.name & "' with Id " & recordId & ": " & ex.Message)
                End Try
        End Select

        Me.EnsureCampaignContact(component, recordId)

        Return recordId
    End Function

    Private Sub ModifyRecord(ByRef component As crmRepository.clsComponent,
                                ByRef mapping As DataMapping,
                                ByRef myDataObject As API.DataObject,
                                ByRef primaryComponent As crmRepository.clsComponent,
                                ByVal recordId As Integer,
                                Optional ByVal parentRecordId As Integer = 0)
        Dim myVal As String
        Dim myMatches As MatchCollection
        Dim appSettings As crmFoundation.clsApplication = Nothing
        Dim lsSourceField As String

        'first we need to tidy up any default values
        For Each compField As crmRepository.clsComponentField In component.fields
            If Not IsNothing(compField.defaultVal) AndAlso Not Convert.ToString(compField.defaultVal).Equals(String.Empty) Then _
                compField.value = Me.StringReplace(compField.value, "[userid]", Me.CreatedBy)
        Next

        'fields that come directly from the csv

        For Each myField As MappedField In mapping.MappedFields

            lsSourceField = String.Empty
            If _HasHeaders = True Then
                lsSourceField = myDataObject.Item(myField.SourceField)
            Else
                If myField.ColPosition > 0 Then
                    lsSourceField = myDataObject.Item(myField.ColPosition - 1)
                End If
            End If

            If (lsSourceField <> String.Empty) And ((myField.UpdateFlag = True) Or recordId = 0) Then 'MOD - 31/7/2017 (30/01/2018 - Added exclsudion for new records i.e. where recordId = 0)

                If myField.TransformTemplate <> String.Empty Then  'MOD - 31/7/2017
                    lsSourceField = myField.TransformTemplate.Replace("[column]", lsSourceField)
                    component.fields(myField.ComponentFieldId).type = "TRANSFORM"
                End If

                If component.fields(myField.ComponentFieldId).name.ToUpper = "ID" Then 'MOD - 5/7/2013 - 
                    component.fields(myField.ComponentFieldId).changed = False
                Else
                    Me.CheckFieldValidity(component.fields(myField.ComponentFieldId), lsSourceField)
                    component.setFld(myField.ComponentFieldId, lsSourceField)
                End If
            End If

        Next

        'static fields
        For Each myField As MappedField In mapping.StaticFields
            myVal = myField.StaticValue

            'simple replacements first
            myVal = Me.StringReplace(myVal, "[UserId]", Me.CreatedBy)
            myVal = Me.StringReplace(myVal, "[TheDate]", DateTime.Now)
            myVal = Me.StringReplace(myVal, "[JobId]", Me.Id) 'Added job Id expression - useful for SPs that need to get hold of updated data.

            'more complicated replacements are handled by regular expressions

            '[Source].[csv col name]
            If myVal.ToLower.IndexOf("[source]") > -1 Then
                myMatches = Regex.Matches(myVal, "\[Source\]\.\[(.+)\]", RegexOptions.IgnoreCase)
                For Each myMatch As Match In myMatches
                    myVal = Me.StringReplace(myVal, myMatch.Groups(0).Value, myDataObject.Item(myMatch.Groups(1).Value))
                Next
            End If

            '[Application].[value name]
            If myVal.ToLower.IndexOf("[application]") > -1 Then
                myMatches = Regex.Matches(myVal, "\[Application\]\.\[(.+)\]", RegexOptions.IgnoreCase)
                For Each myMatch As Match In myMatches
                    If IsNothing(appSettings) Then
                        appSettings = New crmFoundation.clsApplication
                        appSettings.strConn = Me.ConnectionString
                    End If
                    myVal = Me.StringReplace(myVal, myMatch.Groups(0).Value, appSettings.getAppSetting(myMatch.Groups(1).Value))
                Next
            End If

            '[Primary].[name of field in pri comp]
            If myVal.ToLower.IndexOf("[primary]") > -1 Then
                myMatches = Regex.Matches(myVal, "\[Primary\]\.\[(.+)\]", RegexOptions.IgnoreCase)
                For Each myMatch As Match In myMatches
                    If IsNothing(primaryComponent.fields(myMatch.Groups(1).Value)) Then _
                        Throw New Exception("Field '" & myMatch.Groups(1).Value & "' not found in primary component")
                    myVal = Me.StringReplace(myVal, myMatch.Groups(0).Value, primaryComponent.getFld(myMatch.Groups(1).Value))
                Next
            End If

            Me.CheckFieldValidity(component.fields(myField.ComponentFieldId), myVal)
            component.setFld(myField.ComponentFieldId, myVal)
        Next

        'should we link this record to a parent record?
        If parentRecordId > 0 Then _
            Me.SetParentRecordId(component, parentRecordId)
    End Sub

    Private Sub SetParentRecordId(ByRef component As crmRepository.clsComponent, ByVal parentRecordId As Integer)
        Dim linkField As String = crmRepository.clsShared.BusObjGetLinkTargetDetail(Me.ParentImport.DestinationObjectId, component.id, Me.ConnectionString)

        If IsNothing(linkField) OrElse linkField.Equals(String.Empty) Then _
            Throw New Exception("Parent record link field not defined")

        'loop over component fields looking for one that matches the col name we've just found...
        For Each myField As crmRepository.clsComponentField In component.fields
            If myField.colName = linkField Then
                linkField = myField.name
                Exit For
            End If
        Next

        If IsNothing(component.fields(linkField)) Then _
            Throw New Exception("Parent record link field '" & linkField & "' not found")

        component.setFld(linkField, parentRecordId.ToString)
    End Sub

    Private Function StringReplace(ByVal original As String, ByVal pattern As String, ByVal replacement As String) As String
        If IsNothing(original) OrElse original.Equals(String.Empty) Then _
            Return String.Empty

        Dim originalLower As String = original.ToLower
        Dim patStart As Integer = originalLower.IndexOf(pattern.ToLower)

        If patStart > -1 Then
            original = original.Remove(patStart, pattern.Length)
            original = original.Insert(patStart, replacement)
        End If

        Return original
    End Function

    Private Sub LogTableWrite(ByVal tableName As String)
        If IsNothing(_TablesWrittenTo) Then _
            _TablesWrittenTo = New ArrayList
        If Not _TablesWrittenTo.Contains(tableName) Then _
            _TablesWrittenTo.Add(tableName)
    End Sub

    Private Sub CheckFieldValidity(ByRef componentField As crmRepository.clsComponentField, ByVal givenData As String)
        Dim textTypes As String = " PHONE PASSWORD TEXT URL CALLTO LONGTEXT "

        'if the field is 0 in size then we ignore this check
        If componentField.length = 0 Then _
            Exit Sub

        'if it's a readonly field we need to throw an exception
        If componentField.isReadonly Then _
            Throw New Exception("The field '" & componentField.name & "' is readonly.")

        'if it's a string field we need to check the length
        If Not IsNothing(givenData) AndAlso (textTypes.IndexOf(componentField.type) > 0 And givenData.Length > componentField.length) Then _
            Throw New Exception("Data would be truncated. The field '" & componentField.name & _
                                    "' has a length of " & componentField.length & " characters and the given data [" & _
                                    Microsoft.Security.Application.AntiXSSLibrary.HtmlEncode(givenData) & _
                                    "] has a length of " & givenData.Length & " characters.")
    End Sub

    Private Sub EnsureCampaignContact(ByRef component As crmRepository.clsComponent, ByVal recordId As Integer)
        If Not Me.ParentImport.CampaignId.Equals(0) AndAlso component.table.ToLower = "u_contact" Then
            Dim fieldName As String = Nothing

            'first we need to find out which component field holds the recordtype
            For Each myField As crmRepository.clsComponentField In component.fields
                If myField.colName.ToLower = "recordtype" Then
                    fieldName = myField.name
                    Exit For
                End If
            Next

            'no recordtype = no good
            If IsNothing(fieldName) OrElse fieldName.Equals(String.Empty) Then _
                Throw New Exception("Unable to determine record type field so could not ensure existence of campaign contact record")

            'only interested in campaign contact records for record type 5
            If Convert.ToString(component.getFld(fieldName)) = 5.ToString Then
                Dim linkId As Integer = SqlHelper.ExecuteScalar(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_EnsureCampaignContact", _
                                                                    New SqlClient.SqlParameter() { _
                                                                        New SqlClient.SqlParameter("@@ImportId", Me.Id), _
                                                                        New SqlClient.SqlParameter("@@ContactId", recordId), _
                                                                        New SqlClient.SqlParameter("@@CampaignId", Me.ParentImport.CampaignId)})

                'no link record but no exception? should never happen but...
                If linkId.Equals(0) Then _
                    Throw New Exception("An unknown error occured while ensuring the existence of a campaign contact record")
            End If
        End If

        Me.LogTableWrite("u_campaignContact")
    End Sub

    Private Function FindMatches(ByRef component As crmRepository.clsComponent, ByVal mapping As DataMapping, ByRef myDataObject As API.DataObject, Optional ByVal parentRecordId As Integer = 0)
        If mapping.MappedFields.PrimaryKeys.Length > 0 Then
            'does a record exist already exist?
            component.newRecord()
            Dim searchVal As String = String.Empty

            For Each myField As MappedField In mapping.MappedFields 'MOD - 31/08/2017 .PrimaryKeys
                component.addField(myField.ComponentFieldId) 'MOD - 31/08/2017

                If myField.PrimaryKey Then

                    searchVal = myDataObject.Item(myField.SourceField)

                    If IsNothing(searchVal) Then
                        searchVal = "[tPoint].[null]"
                    ElseIf searchVal.Equals(String.Empty) Then
                        searchVal = "[tPoint].[emptyString]"
                    End If

                    searchVal = SqlSafe(searchVal)

                    If myField.TransformTemplate <> String.Empty Then
                        searchVal = myField.TransformTemplate.Replace("[column]", searchVal)
                        component.fields(myField.ComponentFieldId).type = "TRANSFORM"
                    End If

                    component.setFld(myField.ComponentFieldId, searchVal)
                End If

            Next

            'matches should belong to the parent if applicable
            If parentRecordId > 0 Then _
                Me.SetParentRecordId(component, parentRecordId)

            component.setSQL()
            Return component.findRecords
        End If

        Return Nothing
    End Function

    Private Function FindMatchesFk(ByRef component As crmRepository.clsComponent, ByVal mapping As DataMapping, ByRef myDataObject As API.DataObject)
        If mapping.ForeignKeys.Count > 0 Then
            'does a record exist already exist?
            component.newRecord()
            Dim searchVal As String = String.Empty

            For Each myField As ForeignKeyColumn In mapping.ForeignKeys
                searchVal = myDataObject.Item(myField.SourceField)

                If IsNothing(searchVal) Then
                    searchVal = "[tPoint].[null]"
                ElseIf searchVal.Equals(String.Empty) Then
                    searchVal = "[tPoint].[emptyString]"
                End If

                searchVal = SqlSafe(searchVal)
                component.setFld(myField.ComponentFieldId, searchVal)
            Next

            component.setSQL()
            Return component.findRecords
        End If

        Return Nothing
    End Function

    Private Function DupeLevel(ByRef records As DataSet) As Enums.DuplicateLevel
        If Not IsNothing(records) AndAlso Not IsNothing(records.Tables) AndAlso Not IsNothing(records.Tables(0)) AndAlso records.Tables(0).Rows.Count > 0 Then
            If records.Tables(0).Rows.Count > 1 Then
                Return Enums.DuplicateLevel.Multiple
            Else
                Return Enums.DuplicateLevel.Single
            End If
        Else
            Return Enums.DuplicateLevel.None
        End If
    End Function

    Private Function SqlSafe(ByVal value As String) As String
        Return value.Replace("'", "''")
    End Function

    Private Sub LoadRollbackData()
        'grab the xml that describes the tables that were written to during the import
        Dim rollbackXml As New Xml.XmlDocument
        Dim rawXml As String = String.Empty

        rawXml = SqlHelper.ExecuteScalar(Me.ConnectionString, _
                                            CommandType.StoredProcedure, _
                                            "g_DataImport_GetRollbackData", _
                                            New SqlClient.SqlParameter("@@JobId", Me.Id))

        If Not IsNothing(rawXml) AndAlso Not rawXml.Equals(String.Empty) Then
            rollbackXml.LoadXml(rawXml)

            _TablesWrittenTo = New ArrayList
            _TablesWrittenTo.AddRange(DirectCast(Serializing.Deserialize(rollbackXml, GetType(String())), String()))
        End If
    End Sub

    Public Sub Rollback()
        'this is a very risky operation!
        If Not Me.ParentImport.DupeOption = Enums.DuplicationOption.Update Then
            Try
                'do we even need to rollback?
                'first try loading saved table write info
                If IsNothing(_TablesWrittenTo) Then _
                    Me.LoadRollbackData()

                If IsNothing(_TablesWrittenTo) OrElse _TablesWrittenTo.Count = 0 Then _
                    Exit Try

                'first we need to ensure there are no previous data imports with the same id
                'it's not possible to accurately determine which records were created with the old import and with the new one
                Dim existingImport As Integer = SqlHelper.ExecuteScalar(Me.ConnectionString, CommandType.Text, "select id from g_dataImport where id = " & Me.Id)

                If Not existingImport.Equals(0) Then _
                    Throw New Exception("There is a legacy data import with the same Id as this job, unexpected data loss would occur.")

                'loop through each table we've written to and delete where the ImportId column matches this job's id
                For Each writtenTable As String In _TablesWrittenTo
                    SqlHelper.ExecuteNonQuery(Me.ConnectionString, CommandType.Text, "delete from " & writtenTable & " where importId = " & Me.Id)
                Next

            Catch ex As Exception
                Throw New Exception("Unable to rollback data: " & ex.Message)
            End Try

            'mark import as rolled back
            SqlHelper.ExecuteNonQuery(Me.ConnectionString, CommandType.Text, "update g_DataImport_Job set RollbackComplete = 1, RollbackDate = getdate(), RollbackUser = @userId where Id = " & Me.Id, New SqlClient.SqlParameter("@userId", Me.UserId))
        End If
    End Sub

    Public Sub LogError(ByVal lineNum As Integer, ByVal details As String)
        If Me.Id.Equals(0) Then _
            Throw New Exception("Unable to log error against job because job has not been saved")

        Dim myError As New ImportError(Me.Id)

        myError.ConnectionString = Me.ConnectionString
        myError.LineNum = lineNum
        myError.ErrorDetails = details
        myError.Save()

        Me.ImportErrors.Add(myError)
    End Sub

    Private Sub ExecPostProcessSP()
        Try
            SqlHelper.ExecuteNonQuery(Me.CustomSPDB, _
                                    CommandType.StoredProcedure, _
                                    Me.PostProcessSP, _
                                    New SqlClient.SqlParameter("@iiImportId", Me.Id))
            Me.Status = Enums.JobStatus.CompletedOk
        Catch ex As Exception
            LogError(0, "Unable to execute PostProcessSP: " & ex.Message)
            Me.Status = Enums.JobStatus.CompletedInError
        End Try

    End Sub


#End Region

End Class
