Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' Provides collection storage for ImportError objects
''' </summary>
<Serializable()> _
Public Class ImportErrorCollection
    Inherits CollectionBase

    Private _ConnectionString As String
    Private _ParentJobId As Integer

    Friend Property ConnectionString() As String
        Get
            If IsNothing(_ConnectionString) OrElse _ConnectionString.Equals(String.Empty) Then _
                Return crmRepositoryWeb.Classes.clsHelper.strConn

            Return _ConnectionString
        End Get
        Set(ByVal Value As String)
            _ConnectionString = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the parent Job
    ''' </summary>
    Friend Property ParentJobId() As Integer
        Get
            Return _ParentJobId
        End Get
        Set(ByVal Value As Integer)
            _ParentJobId = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns an ImportError object by collection index
    ''' </summary>
    Default Public Property Item(ByVal index As Integer) As crmDataImporter.Business.ImportError
        Get
            Return MyBase.List.Item(index)
        End Get
        Set(ByVal Value As crmDataImporter.Business.ImportError)
            MyBase.List.Item(index) = Value
        End Set
    End Property

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Loads an error collection for a parent Job
    ''' </summary>
    Public Sub New(ByVal forParent As crmDataImporter.Business.Job)
        Me.ConnectionString = forParent.ConnectionString
        Me.LoadFromDb(forParent)
    End Sub

    ''' <summary>
    ''' Checks to make sure only valid objects are added to the collection
    ''' </summary>
    Protected Overrides Sub OnValidate(ByVal value As Object)
        MyBase.OnValidate(value)

        If Not TypeOf value Is crmDataImporter.Business.ImportError Then _
            Throw New ArgumentException("Collection only accepts ImportError objects")
    End Sub

    ''' <summary>
    ''' Adds an object to the collection
    ''' </summary>
    Public Sub Add(ByVal item As crmDataImporter.Business.ImportError)
        If Not IsNothing(item) Then _
            MyBase.List.Add(item)
    End Sub

    ''' <summary>
    ''' Removes the specified item
    ''' </summary>
    Public Sub Remove(ByVal item As crmDataImporter.Business.ImportError)
        If Not IsNothing(item) Then _
            MyBase.List.Remove(item)
    End Sub

    ''' <summary>
    ''' Loads the collection with errors for a parent Job
    ''' </summary>
    Public Overridable Sub LoadFromDb(ByVal parentJob As crmDataImporter.Business.Job)
        _ParentJobId = parentJob.Id

        Dim rawData As DataSet = SqlHelper.ExecuteDataset(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_ImportError_GetCollection", _
                                                                    New SqlClient.SqlParameter("@@JobId", Me.ParentJobId))

        If Not IsNothing(rawData) AndAlso Not IsNothing(rawData.Tables) AndAlso Not rawData.Tables(0).Rows.Count.Equals(0) Then

            For Each errorRow As DataRow In rawData.Tables(0).Rows
                Me.Add(New crmDataImporter.Business.ImportError(errorRow, Me.ConnectionString))
            Next

            rawData.Dispose()
        End If
    End Sub

    ''' <summary>
    ''' Saves all the errors in the collection
    ''' </summary>
    Public Sub Save()
        For Each myError As crmDataImporter.Business.ImportError In Me
            myError.Save(Me.ParentJobId)
        Next
    End Sub

End Class
