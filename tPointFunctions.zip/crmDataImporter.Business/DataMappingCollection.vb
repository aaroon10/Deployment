Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' Provides collection storage for DataMapping objects
''' </summary>
<Serializable()> _
Public Class DataMappingCollection
    Inherits CollectionBase

    Private _ParentImportId As Integer
    Private _ConnectionString As String

    ''' <summary>
    ''' The id of the parent DataImport
    ''' </summary>
    Friend Property ParentImportId() As Integer
        Get
            Return _ParentImportId
        End Get
        Set(ByVal Value As Integer)
            _ParentImportId = Value
        End Set
    End Property

    'INCOMPLETE
    Public Property ConnectionString() As String
        Get
            If IsNothing(_ConnectionString) OrElse _ConnectionString.Equals(String.Empty) Then _
                Return crmRepositoryWeb.Classes.clsHelper.strConn

            Return _ConnectionString
        End Get
        Set(ByVal Value As String)
            _ConnectionString = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns a DataMapping object by collection index
    ''' </summary>
    Default Public Property Item(ByVal index As Integer) As crmDataImporter.Business.DataMapping
        Get
            Return MyBase.List.Item(index)
        End Get
        Set(ByVal Value As crmDataImporter.Business.DataMapping)
            MyBase.List.Item(index) = Value
        End Set
    End Property

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Loads a mapping collection for a parent import
    ''' </summary>
    Public Sub New(ByVal forParent As crmDataImporter.Business.DataImport)
        Me.ConnectionString = forParent.ConnectionString
        Me.LoadFromDb(forParent)
    End Sub

    ''' <summary>
    ''' Checks to make sure only valid objects are added to the collection
    ''' </summary>
    Protected Overrides Sub OnValidate(ByVal value As Object)
        MyBase.OnValidate(value)

        If Not TypeOf value Is crmDataImporter.Business.DataMapping Then _
            Throw New ArgumentException("Collection only accepts DataMapping objects")
    End Sub

    ''' <summary>
    ''' Adds an object to the collection
    ''' </summary>
    Public Sub Add(ByVal item As crmDataImporter.Business.DataMapping)
        MyBase.List.Add(item)
    End Sub

    ''' <summary>
    ''' Removes an object from the collection
    ''' </summary>
    Public Sub Remove(ByVal item As crmDataImporter.Business.DataMapping)
        MyBase.List.Remove(item)
    End Sub

    ''' <summary>
    ''' Loads the collection with saved mappings for an import
    ''' </summary>
    Public Sub LoadFromDb(ByVal parentImport As crmDataImporter.Business.DataImport)
        _ParentImportId = parentImport.Id

        Dim rawData As DataSet = SqlHelper.ExecuteDataset(Me.ConnectionString, CommandType.StoredProcedure, "g_DataImport_Mapping_GetCollection", _
                                                                    New SqlClient.SqlParameter("@@ImportId", Me.ParentImportId))

        If Not IsNothing(rawData) AndAlso Not IsNothing(rawData.Tables) AndAlso Not rawData.Tables(0).Rows.Count.Equals(0) Then

            For Each mappingRow As DataRow In rawData.Tables(0).Rows
                Me.Add(New crmDataImporter.Business.DataMapping(mappingRow, Me.ConnectionString))
            Next

            rawData.Dispose()
        End If
    End Sub

    ''' <summary>
    ''' Returns a mapping for a component id
    ''' </summary>
    Public Function Find(ByVal forComponentId As Integer) As crmDataImporter.Business.DataMapping
        For Each myMapping As crmDataImporter.Business.DataMapping In Me
            If myMapping.ComponentId.Equals(forComponentId) Then _
                Return myMapping
        Next
        Return Nothing
    End Function

    ''' <summary>
    ''' Saves the mappings in the collection to the database
    ''' </summary>
    Public Sub Save()
        'save everything first
        For Each myMap As crmDataImporter.Business.DataMapping In Me
            myMap.ParentImportId = Me.ParentImportId
            myMap.Save()
        Next

        Dim toRemove As New ArrayList

        'first mappings without any fields, they need to be deleted
        For Each myMap As crmDataImporter.Business.DataMapping In Me
            If Not myMap.BelongsToObject Or Not myMap.ContainsMappingInfo Then
                toRemove.Add(myMap)
                myMap.Delete() 'remove from db
            End If
        Next

        'remove from our local collection
        If toRemove.Count > 0 Then
            For Each myMap As crmDataImporter.Business.DataMapping In toRemove
                Me.Remove(mymap)
            Next
        End If
    End Sub

End Class
