Imports System.Xml
Imports System.Xml.Serialization

Public Class Serializing

    Public Shared Function Deserialize(ByVal storedXml As XmlDocument, ByVal destinationType As Type) As Object

        Dim s As New XmlSerializer(destinationType)
        Dim xmlString As String = storedXml.OuterXml.ToString()
        Dim buffer As Byte() = Text.ASCIIEncoding.UTF8.GetBytes(xmlString)
        Dim ms As New IO.MemoryStream(buffer)
        Dim reader As New XmlTextReader(ms)
        Dim o As Object

        Try
            o = s.Deserialize(reader)
            reader.Close()
            Return o
        Catch ex As Exception
            reader.Close()
            Throw ex
        End Try

    End Function

    Public Shared Function Serialize(ByVal sourceObject As Object) As XmlDocument

        Dim s As New XmlSerializer(sourceObject.GetType())

        Dim ms As New IO.MemoryStream()
        Dim writer As New XmlTextWriter(ms, New Text.UTF8Encoding())
        writer.Formatting = Formatting.Indented
        writer.IndentChar = " "
        writer.Indentation = 5

        Try
            s.Serialize(writer, sourceObject)
            Dim xmlOutput As New XmlDocument()
            Dim xmlString As String = Text.ASCIIEncoding.UTF8.GetString(ms.ToArray())
            xmlOutput.LoadXml(xmlString)
            Return xmlOutput
        Catch ex As Exception
            writer.Close()
            ms.Close()
            Throw ex
        End Try

    End Function

    Public Shared Function IsDeserializing() As Boolean
        Dim myStack As New Diagnostics.StackTrace

        For i As Integer = 0 To myStack.FrameCount - 1
            If myStack.GetFrame(i).GetMethod.Name = "Deserialize" Then _
                Return True
        Next

        Return False
    End Function

End Class

