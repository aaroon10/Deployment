Imports System.Data.OleDb

Namespace Providers

    Public Class ExcelDataObject
        Inherits crmDataImporter.Business.API.DataObject

        Private _filePath, _connectionString As String
        Private _excelConnection As OleDbConnection
        Private _excelReader As OleDbDataReader
        Private _length, _currentRecordIndex As Integer
        Private _columns, _sheets As String()
        Private _hasHeaders As Boolean
        Private _delimiter As Char

        Public Overrides ReadOnly Property Name() As String
            Get
                Return "ExcelDataObject"
            End Get
        End Property

        Public Overrides ReadOnly Property Description() As String
            Get
                Return "Interface for reading data from Excel spreadsheets for use with the tPoint Data Import system"
            End Get
        End Property

        Public Overrides ReadOnly Property SupportedFileExtensions() As String()
            Get
                Return New String() {".xls"}
            End Get
        End Property

        Public Overrides ReadOnly Property Columns() As String()
            Get
                If Not MyBase.Initialised Then _
                    Throw New Exception("Excel provider not initialised")

                If IsNothing(_columns) OrElse _columns.Length.Equals(0) Then
                    ReDim _columns(_excelReader.FieldCount - 1)

                    For i As Integer = 0 To _excelReader.FieldCount - 1
                        _columns(i) = _excelReader.GetName(i)
                    Next
                End If

                Return _columns
            End Get
        End Property

        Public Overrides ReadOnly Property CurrentRecordIndex() As Integer
            Get
                If Not MyBase.Initialised Then _
                    Throw New Exception("Excel provider not initialised")

                Return _currentRecordIndex
            End Get
        End Property

        Public Overrides ReadOnly Property Length() As Integer
            Get
                If Not _length.Equals(0) Then _
                    Return _length

                Dim countCommand As New OleDb.OleDbCommand("select count(*) from [" & Me.Sheets(0) & "]", _excelConnection)
                _length = countCommand.ExecuteScalar
                countCommand.Dispose()

                Return _length
            End Get
        End Property

        Default Public Overloads Overrides ReadOnly Property Item(ByVal index As Integer) As String
            Get
                If Not MyBase.Initialised Then _
                    Throw New Exception("Excel provider not initialised")

                If _currentRecordIndex < 0 Then _
                    Throw New Exception("No row data")

                Dim myVal As Object = _excelReader.Item(index)

                If IsDBNull(myVal) OrElse IsNothing(myVal) Then _
                    myVal = String.Empty

                Return Convert.ToString(myVal)
            End Get
        End Property

        Default Public Overloads Overrides ReadOnly Property Item(ByVal field As String) As String
            Get
                If Not MyBase.Initialised Then _
                    Throw New Exception("Excel provider not initialised")

                If _currentRecordIndex < 0 Then _
                    Throw New Exception("No row data")

                Dim myVal As Object = _excelReader.Item(field)

                If IsDBNull(myVal) OrElse IsNothing(myVal) Then _
                    myVal = String.Empty

                Return Convert.ToString(myVal)
            End Get
        End Property

        Private ReadOnly Property Sheets() As String()
            Get
                If IsNothing(_connectionString) OrElse _connectionString.Equals(String.Empty) Then _
                    Throw New Exception("Connection string not set")

                If IsNothing(_sheets) OrElse _sheets.Length.Equals(0) Then
                    Dim myConn As OleDbConnection = Nothing
                    Dim schemaTable As DataTable = Nothing

                    Try
                        myConn = New OleDbConnection(_connectionString)
                        myConn.Open()
                        schemaTable = myConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, Nothing)
                        myConn.Close()

                        ReDim _sheets(schemaTable.Rows.Count - 1)

                        For i As Integer = 0 To schemaTable.Rows.Count - 1
                            _sheets(i) = schemaTable.Rows(i).Item("TABLE_NAME")
                        Next
                    Catch
                        _sheets = Nothing
                    Finally
                        If Not IsNothing(myConn) Then _
                            myConn.Dispose()
                        If Not IsNothing(schemaTable) Then _
                            schemaTable.Dispose()
                    End Try
                End If

                Return _sheets
            End Get
        End Property


        Public Overrides Sub Init(ByVal hasHeaders As Boolean, ByVal delimiter As Char, ByVal filePath As String)
            _filePath = filePath
            _connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & _filePath & ";Extended Properties=Excel 5.0"
            _hasHeaders = hasHeaders
            '_delimiter = delimiter

            _excelConnection = New OleDbConnection(_connectionString)
            _excelConnection.Open()

            Dim myCommand As New OleDbCommand("select * from [" & Me.Sheets(0) & "]", _excelConnection)
            _excelReader = myCommand.ExecuteReader
            myCommand.Dispose()

            _currentRecordIndex = -1

            MyBase.Initialised = True
        End Sub

        Public Overloads Overrides Function Verify(ByVal hasHeaders As Boolean, ByVal checkForMappedColumns As DataMappingCollection) As Boolean
            If Not MyBase.Initialised Then _
                Throw New Exception("Excel provider not initialised")

            Dim currentLine As Integer
            Try
                'running through the file ensures every line is read (a basic check)
                While Me.Read
                    currentLine = Me.CurrentRecordIndex
                End While

                If Not IsNothing(checkForMappedColumns) Then
                    If hasHeaders Then
                        'if we're creating a job then check mapped fields appear in the spreadsheet
                        currentLine = 0

                        For Each myMapping As DataMapping In checkForMappedColumns
                            For Each myField As MappedField In myMapping.MappedFields
                                If Array.IndexOf(Me.Columns, myField.SourceField) < 0 Then _
                                    Throw New Exception("Expected column '" & myField.SourceField & "' not found in Excel worksheet")
                            Next
                            For Each myField As ForeignKeyColumn In myMapping.ForeignKeys
                                If Array.IndexOf(Me.Columns, myField.SourceField) < 0 Then _
                                    Throw New Exception("Expected column '" & myField.SourceField & "' not found in Excel worksheet (FK)")
                            Next
                        Next
                    Else
                        'If checkForMappedColumns.Item(0).MappedFields.Count <> _myCsv.FieldCount Then
                        'Throw New Exception("Column count mismatch. Source file count = " & Me._myCsv.FieldCount & "; Destination component count = " & checkForMappedColumns.Item(0).MappedFields.Count)
                        'End If
                    End If
                End If

                Return True
            Catch ex As Exception
                'return a useful error message
                Throw New Exception("Unable to verify the integrity of the Excel file. The problem occured around line " & currentLine & ": " & ex.Message)
            End Try
        End Function

        Public Overrides Function Read() As Boolean
            If Not MyBase.Initialised Then _
                Throw New Exception("Excel provider not initialised")

            If _excelReader.Read Then
                _currentRecordIndex += 1
                Return True
            End If

            Return False
        End Function

        Public Overrides Sub Dispose()
            If Not IsNothing(_excelReader) Then _
                _excelReader.Close()

            If Not IsNothing(_excelConnection) Then
                _excelConnection.Close()
                _excelConnection.Dispose()
            End If

            MyBase.Initialised = False
        End Sub

        Public Overrides Sub Reset()
            If Not MyBase.Initialised Then _
                Throw New Exception("Excel provider not initialised")

            Me.Dispose()
            Me.Init(_hasHeaders, _delimiter, _filePath)
        End Sub

    End Class

End Namespace