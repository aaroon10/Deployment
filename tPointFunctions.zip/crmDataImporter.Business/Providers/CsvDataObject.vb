Namespace Providers

    Public Class CsvDataObject
        Inherits crmDataImporter.Business.API.DataObject

        Private _filePath As String
        Private _myCsv As LumenWorks.Framework.IO.Csv.CsvReader
        Private _length As Integer
        Private _columns As String()
        Private _hasHeaders As Boolean
        Private _delimiter As Char

        Public Overrides ReadOnly Property Name() As String
            Get
                Return "CsvDataObject"
            End Get
        End Property

        Public Overrides ReadOnly Property Description() As String
            Get
                Return "Interface for reading data from CSV files for use with the tPoint Data Import system"
            End Get
        End Property

        Public Overrides ReadOnly Property SupportedFileExtensions() As String()
            Get
                Return New String() {".csv", ".txt"}
            End Get
        End Property

        Public Overrides ReadOnly Property Columns() As String()
            Get
                If Not MyBase.Initialised Then _
                    Throw New Exception("CSV provider not initialised")

                If IsNothing(_columns) OrElse _columns.Length.Equals(0) Then
                    ReDim _columns(_myCsv.GetFieldHeaders.Length - 1)
                    _myCsv.GetFieldHeaders.CopyTo(_columns, 0)
                End If

                Return _columns
            End Get
        End Property

        Public Overrides ReadOnly Property CurrentRecordIndex() As Integer
            Get
                If Not MyBase.Initialised Then _
                    Throw New Exception("CSV provider not initialised")

                Return _myCsv.CurrentRecordIndex
            End Get
        End Property

        Public Overrides ReadOnly Property Length() As Integer
            Get
                If Not _length.Equals(0) Then _
                    Return _length

                Me.Reset()

                Try
                    While Me.Read
                        _length += 1
                    End While
                Catch
                    _length = 0
                End Try

                Me.Reset()
                Return _length
            End Get
        End Property

        Default Public Overloads Overrides ReadOnly Property Item(ByVal index As Integer) As String
            Get
                If Not MyBase.Initialised Then _
                    Throw New Exception("CSV provider not initialised")

                Dim myVal As Object = _myCsv.Item(index)

                If IsDBNull(myVal) OrElse IsNothing(myVal) Then _
                    myVal = String.Empty

                Return Convert.ToString(myVal)
            End Get
        End Property

        Default Public Overloads Overrides ReadOnly Property Item(ByVal field As String) As String
            Get
                If Not MyBase.Initialised Then _
                    Throw New Exception("CSV provider not initialised")

                Dim myVal As Object = _myCsv.Item(field)

                If IsDBNull(myVal) OrElse IsNothing(myVal) Then _
                    myVal = String.Empty

                Return Convert.ToString(myVal)
            End Get
        End Property


        Public Overrides Sub Init(ByVal hasHeaders As Boolean, ByVal delimiter As Char, ByVal filePath As String)
            If IsNothing(filePath) OrElse filePath.Equals(String.Empty) Then _
                Throw New ArgumentNullException("filePath")

            _filePath = filePath
            _hasHeaders = hasHeaders
            _delimiter = delimiter


            _myCsv = New LumenWorks.Framework.IO.Csv.CsvReader(New IO.StreamReader(_filePath), _hasHeaders, _delimiter)
            _myCsv.DefaultParseErrorAction = LumenWorks.Framework.IO.Csv.ParseErrorAction.ThrowException
            _myCsv.MissingFieldAction = LumenWorks.Framework.IO.Csv.MissingFieldAction.ReplaceByNull
            _myCsv.SupportsMultiline = True

            MyBase.Initialised = True
        End Sub

        Public Overloads Overrides Function Verify(ByVal hasHeaders As Boolean, ByVal checkForMappedColumns As Business.DataMappingCollection) As Boolean
            If Not MyBase.Initialised Then _
                Throw New Exception("CSV provider not initialised")

            Dim currentLine As Integer
            Try
                'running through the csv ensures every line is read (a basic check)
                While Me.Read
                    currentLine = Me.CurrentRecordIndex
                End While

                If Not IsNothing(checkForMappedColumns) Then
                    If hasHeaders Then
                        'if we're creating a job then check mapped fields appear in the spreadsheet
                        currentLine = 0

                        For Each myMapping As DataMapping In checkForMappedColumns
                            For Each myField As MappedField In myMapping.MappedFields
                                If Array.IndexOf(Me.Columns, myField.SourceField) < 0 Then _
                                    Throw New Exception("Expected column '" & myField.SourceField & "' not found in CSV")
                            Next
                            For Each myField As ForeignKeyColumn In myMapping.ForeignKeys
                                If Array.IndexOf(Me.Columns, myField.SourceField) < 0 Then _
                                    Throw New Exception("Expected column '" & myField.SourceField & "' not found in CSV (FK)")
                            Next
                        Next
                    Else
                        Dim i, destColCount As Integer
                        For i = 0 To checkForMappedColumns.Count - 1
                            destColCount += checkForMappedColumns.Item(i).MappedFields.Count
                        Next
                        If destColCount <> _myCsv.FieldCount Then
                            Throw New Exception("Column count mismatch. Source file count = " & Me._myCsv.FieldCount & "; Destination component count = " & destColCount)
                        End If
                    End If
                End If

                Return True
            Catch ex As Exception
                'return a useful error message
                Throw New Exception("Unable to verify the integrity of the CSV file. The problem occured around line " & currentLine & ": " & ex.Message)
            End Try
        End Function

        Public Overrides Function Read() As Boolean
            If Not MyBase.Initialised Then _
                Throw New Exception("CSV provider not initialised")

            If Not _myCsv.EndOfStream AndAlso _myCsv.ReadNextRecord Then _
                Return True
        End Function

        Public Overrides Sub Dispose()
            If MyBase.Initialised Then _
                _myCsv.Dispose()
        End Sub

        Public Overrides Sub Reset()
            If Not MyBase.Initialised Then _
                Throw New Exception("CSV provider not initialised")

            Me.Init(_hasHeaders, _delimiter, _filePath)
        End Sub

    End Class

End Namespace