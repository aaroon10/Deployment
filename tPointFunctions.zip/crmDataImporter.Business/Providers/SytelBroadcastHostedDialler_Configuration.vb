Imports microsoft.ApplicationBlocks.Data

Namespace Providers

    Public Class SytelBroadcastHostedDialler_Configuration
        Inherits API.TemplatedWebControl
        Implements API.IDiallerConfigurationControl

        Protected ddlSytelBroadcastQueue As Web.UI.WebControls.DropDownList

        Private _provider As Business.Providers.SytelBroadcastHostedDialler
        Private _loadDefaults As Boolean

        Protected Overrides Sub AttachChildControls() Implements API.IDiallerConfigurationControl.AttachChildControls
            ddlSytelBroadcastQueue = Me.FindControl("ddlSytelBroadcastQueue")
        End Sub

        Private Sub SytelBroadcastHostedDialler_Configuration_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
            EnsureChildControls()
        End Sub

        Public Overrides ReadOnly Property SkinPath() As String Implements API.IDiallerConfigurationControl.SkinPath
            Get
                Dim mySkin As New API.CachedAssemblyResource(Me, "crmDataImporter.Business.SytelBroadcastHostedDialler_Configuration.ascx")
                Return mySkin.CachedFilename
            End Get
        End Property

        Public Property LoadDefaults() As Boolean Implements API.IDiallerConfigurationControl.LoadDefaults
            Get
                Return _loadDefaults
            End Get
            Set(ByVal value As Boolean)
                _loadDefaults = value
            End Set
        End Property

        Public Sub New(ByRef provider As Business.Providers.SytelBroadcastHostedDialler, ByVal loadDefaults As Boolean)
            _provider = provider
            _loadDefaults = loadDefaults
        End Sub

        Public Sub StoreData() Implements API.IDiallerConfigurationControl.StoreData
            If ddlSytelBroadcastQueue.SelectedIndex.Equals(0) Then _
                Throw New Exception("A Sytel Broadcast queue must be selected")

            _provider.QueueId = ddlSytelBroadcastQueue.SelectedItem.Value
        End Sub

        Private Sub SytelBroadcastHostedDialler_Configuration_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            'add handlers here if necessary

            If LoadDefaults Then
                Dim rawQueues As DataSet = SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, _
                                                                    CommandType.StoredProcedure, _
                                                                    "g_DataImport_SytelBroadcast_ListQueues", _
                                                                    New SqlClient.SqlParameter("@@forCampaign", _provider.CampaignId))

                If Not IsNothing(rawQueues.Tables) AndAlso Not rawQueues.Tables(0).Rows.Count.Equals(0) Then
                    ddlSytelBroadcastQueue.DataSource = rawQueues.Tables(0)
                    ddlSytelBroadcastQueue.DataValueField = "id"
                    ddlSytelBroadcastQueue.DataTextField = "name"
                    ddlSytelBroadcastQueue.DataBind()
                    rawQueues.Dispose()
                End If
                ddlSytelBroadcastQueue.Items.Insert(0, New Web.UI.WebControls.ListItem(String.Empty, 0))


                If Not IsNothing(ddlSytelBroadcastQueue.Items.FindByValue(_provider.QueueId)) Then _
                    ddlSytelBroadcastQueue.Items.FindByValue(_provider.QueueId).Selected = True
            End If
        End Sub

    End Class

End Namespace