Imports Microsoft.ApplicationBlocks.Data

Namespace Providers

    Public Class SytelBroadcastHostedDialler
        Inherits API.HostedDialler

        Private _OperationProgress As Integer
        Private _Errors As List(Of Exception)

        Public Overrides ReadOnly Property DiallerType() As Enums.DiallerTypes
            Get
                Return Enums.DiallerTypes.Broadcast
            End Get
        End Property

        Public Overrides ReadOnly Property ConfigurationControl(ByVal loadDefaults As Boolean) As API.IDiallerConfigurationControl
            Get
                Dim myControl As Web.UI.WebControls.WebControl = New Business.Providers.SytelBroadcastHostedDialler_Configuration(Me, loadDefaults)
                myControl.ID = "SytelBroadcastHostedDialler_Configuration"
                Return myControl
            End Get
        End Property

        Public Overrides Property BatchSize() As Integer
            Get
                Return 500
            End Get
            Set(ByVal value As Integer)
                Throw New NotImplementedException
            End Set
        End Property

        Public Overrides ReadOnly Property OperationProgress() As Integer
            Get
                Return _OperationProgress
            End Get
        End Property

        Public Property QueueId() As Integer
            Get
                Return MyBase.ReadBaseConfigValue(Of Integer)("QueueId")
            End Get
            Set(ByVal value As Integer)
                MyBase.WriteBaseConfigValue("QueueId", value)
            End Set
        End Property

        Public Overrides Sub Init(ByVal forCampaign As Integer, ByVal config As System.Xml.XmlDocument)
            MyBase.Config = config
            MyBase.CampaignId = forCampaign

            MyBase._config = Nothing
            If Not IsNothing(config) Then
                MyBase._config = New DataSet

                Dim myStream As New IO.StringReader(config.OuterXml)
                MyBase._config.ReadXml(New Xml.XmlTextReader(myStream))
                MyBase._config.AcceptChanges()
                myStream.Close()
            End If

            Me.EnsureConfig()

            MyBase.Initialised = True
        End Sub

        Public Overrides Sub UpdateConfig()
            'no work to do
        End Sub

        Public Overrides Sub Dispose()
        End Sub

        Friend Overrides Sub EnsureConfig()
            If IsNothing(MyBase._config) Then _
                MyBase._config = New DataSet("config")

            If IsNothing(MyBase._config.Tables("transferSettings")) Then _
                MyBase._config.Tables.Add(New DataTable("transferSettings"))

            With MyBase._config.Tables("transferSettings")
                If IsNothing(.Columns("QueueId")) Then _
                    .Columns.Add("QueueId", GetType(Integer))
            End With

            MyBase._config.AcceptChanges()

            If MyBase._config.Tables("transferSettings").Rows.Count = 0 Then _
                MyBase._config.Tables("transferSettings").Rows.Add(MyBase._config.Tables("transferSettings").NewRow)

            MyBase._config.AcceptChanges() 'just for good measure :)
        End Sub

        Private Sub StoreError(ex As Exception)
            If IsNothing(_Errors) Then _
                _Errors = New List(Of Exception)

            _Errors.Add(ex)
        End Sub

        Public Overrides Sub PerformOperation(ByVal forJob As Object)
            If Me.QueueId.Equals(0) Then _
                Throw New ArgumentException("QueueId must be set")
            If IsNothing(forJob) Then _
                Throw New ArgumentNullException("forJob")

            Dim colparam(3) As SqlClient.SqlParameter
            ' TODO: call sproc to insert into Pete's table with Me.QueueId and ImportId
            With DirectCast(forJob, Business.Job)

                colparam(1) = New SqlClient.SqlParameter("@dialler", "Sytel")
                colparam(2) = New SqlClient.SqlParameter("@datasetId", .Id)
                colparam(3) = New SqlClient.SqlParameter("@queueId", Me.QueueId)
                Try
                    SqlHelper.ExecuteNonQuery(.ConnectionString, _
                                            CommandType.StoredProcedure, _
                                            "g_DataImport_InsertBroadcastQueueEscalation", _
                                            colparam)
                Catch ex As Exception
                    StoreError(ex)
                End Try
            End With

            MyBase.OnOperationCompleted(_Errors)
        End Sub

    End Class

End Namespace