Namespace Providers

    Public Class DxiHostedDialler
        Inherits API.HostedDialler

        Private _OperationProgress, _TotalLines As Integer
        Private _Errors As List(Of Exception)
        Private _BatchesComplete As Integer

        Public Overrides ReadOnly Property DiallerType() As Enums.DiallerTypes
            Get
                Return Enums.DiallerTypes.DXI
            End Get
        End Property

        Public Overrides ReadOnly Property ConfigurationControl(ByVal loadDefaults As Boolean) As API.IDiallerConfigurationControl
            Get
                Dim myControl As Web.UI.WebControls.WebControl = New Business.Providers.DxiHostedDialler_Configuration(Me, loadDefaults)
                myControl.ID = "DxiHostedDialler_Configuration"
                Return myControl
            End Get
        End Property

        Public Overrides Property BatchSize() As Integer
            Get
                Return 500
            End Get
            Set(ByVal value As Integer)
                Throw New NotImplementedException
            End Set
        End Property

        Public Overrides ReadOnly Property OperationProgress() As Integer
            Get
                Return _OperationProgress
            End Get
        End Property

        Private ReadOnly Property TotalLines() As Integer
            Get
                Return _TotalLines
            End Get
        End Property

        Public Property QueueId() As Integer
            Get
                Return MyBase.ReadBaseConfigValue(Of Integer)("QueueId")
            End Get
            Set(ByVal value As Integer)
                MyBase.WriteBaseConfigValue("QueueId", value)
            End Set
        End Property

        Public Property ActionType() As crmDataImporter.Business.dxiAction
            Get
                Return MyBase.ReadBaseConfigValue(Of crmDataImporter.Business.dxiAction)("ActionType")
            End Get
            Set(ByVal value As crmDataImporter.Business.dxiAction)
                MyBase.WriteBaseConfigValue("ActionType", value)
            End Set
        End Property

        Public Overrides Sub Init(ByVal forCampaign As Integer, ByVal config As System.Xml.XmlDocument)
            MyBase.Config = config
            MyBase.CampaignId = forCampaign

            MyBase._config = Nothing
            If Not IsNothing(config) Then
                MyBase._config = New DataSet

                Dim myStream As New IO.StringReader(config.OuterXml)
                MyBase._config.ReadXml(New Xml.XmlTextReader(myStream))
                MyBase._config.AcceptChanges()
                myStream.Close()
            End If

            Me.EnsureConfig()

            MyBase.Initialised = True
        End Sub

        Public Overrides Sub UpdateConfig()
            'no work to do
        End Sub

        Public Overrides Sub Dispose()
        End Sub

        Friend Overrides Sub EnsureConfig()
            If IsNothing(MyBase._config) Then _
                MyBase._config = New DataSet("config")

            If IsNothing(MyBase._config.Tables("transferSettings")) Then _
                MyBase._config.Tables.Add(New DataTable("transferSettings"))

            With MyBase._config.Tables("transferSettings")
                If IsNothing(.Columns("QueueId")) Then _
                    .Columns.Add("QueueId", GetType(Integer))
                If IsNothing(.Columns("ActionType")) Then _
                    .Columns.Add("ActionType", GetType(Integer))
            End With

            MyBase._config.AcceptChanges()

            If MyBase._config.Tables("transferSettings").Rows.Count = 0 Then _
                MyBase._config.Tables("transferSettings").Rows.Add(MyBase._config.Tables("transferSettings").NewRow)

            MyBase._config.AcceptChanges() 'just for good measure :)
        End Sub

        Private Sub IncrementProgress(ByVal dxiValue As String)
            'some calculation using totallines and batchsize, we're not really interested in the string from dxi
            Dim newProgress As Integer

            _BatchesComplete += 1

            newProgress = (100 / (_TotalLines / Me.BatchSize)) * _BatchesComplete
            If Me.BatchSize > _TotalLines Then _
                newProgress = 100

            MyBase.OnOperationProgressChanged(newProgress)
        End Sub

        Private Sub StoreError(ByVal source As String, ByVal message As String)
            If IsNothing(_Errors) Then _
                _Errors = New List(Of Exception)

            _Errors.Add(New Exception(message & " (" & source & ")"))
        End Sub

        Public Overrides Sub PerformOperation(ByVal forJob As Object)
            If Me.QueueId.Equals(0) Then _
                Throw New ArgumentException("QueueId must be set")
            If IsNothing(forJob) Then _
                Throw New ArgumentNullException("forJob")

            Dim myDxiImporter As crmDataImporter.Business.contactRecords = Nothing

            With DirectCast(forJob, Business.Job)
                myDxiImporter = New crmDataImporter.Business.contactRecords(IO.Path.GetDirectoryName(.DiskFile.DiskPath), _
                                                                        .Id, _
                                                                        .ConnectionString, _
                                                                        Me.QueueId, _
                                                                        0, _
                                                                        Me.BatchSize, _
                                                                        Me.ActionType)
                _TotalLines = .TotalLines
            End With

            'capture event of a batch completing
            AddHandler myDxiImporter.batchCompleted, AddressOf IncrementProgress
            AddHandler myDxiImporter.errorEvent, AddressOf StoreError

            'fire off import, single threaded :(
            myDxiImporter.dxiImport()

            MyBase.OnOperationCompleted(_Errors)
        End Sub

    End Class

End Namespace