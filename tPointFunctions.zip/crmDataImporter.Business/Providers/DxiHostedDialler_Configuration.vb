Imports microsoft.ApplicationBlocks.Data

Namespace Providers

    Public Class DxiHostedDialler_Configuration
        Inherits API.TemplatedWebControl
        Implements API.IDiallerConfigurationControl

        Protected ddlDxiQueue As Web.UI.WebControls.DropDownList
        Protected ddlDxiAction As Web.UI.WebControls.DropDownList

        Private _provider As Business.Providers.DxiHostedDialler
        Private _loadDefaults As Boolean

        Protected Overrides Sub AttachChildControls() Implements API.IDiallerConfigurationControl.AttachChildControls
            ddlDxiQueue = Me.FindControl("ddlDxiQueue")
            ddlDxiAction = Me.FindControl("ddlDxiAction")
        End Sub

        Private Sub DxiHostedDialler_Configuration_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
            EnsureChildControls()
        End Sub

        Public Overrides ReadOnly Property SkinPath() As String Implements API.IDiallerConfigurationControl.SkinPath
            Get
                Dim mySkin As New API.CachedAssemblyResource(Me, "crmDataImporter.Business.DxiHostedDialler_Configuration.ascx")
                Return mySkin.CachedFilename
            End Get
        End Property

        Public Property LoadDefaults() As Boolean Implements API.IDiallerConfigurationControl.LoadDefaults
            Get
                Return _loadDefaults
            End Get
            Set(ByVal value As Boolean)
                _loadDefaults = value
            End Set
        End Property

        Public Sub New(ByRef provider As Business.Providers.DxiHostedDialler, ByVal loadDefaults As Boolean)
            _provider = provider
            _loadDefaults = loadDefaults
        End Sub

        Public Sub StoreData() Implements API.IDiallerConfigurationControl.StoreData
            If ddlDxiQueue.SelectedIndex.Equals(0) Then _
                Throw New Exception("A DXI queue must be selected")

            _provider.QueueId = ddlDxiQueue.SelectedItem.Value
            _provider.ActionType = ddlDxiAction.SelectedItem.Value
        End Sub

        Private Sub DxiHostedDialler_Configuration_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
            'add handlers here if necessary

            If LoadDefaults Then
                Dim rawQueues As DataSet = SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, _
                                                                    CommandType.StoredProcedure, _
                                                                    "g_DataImport_Dxi_ListQueues", _
                                                                    New SqlClient.SqlParameter("@@forCampaign", _provider.CampaignId))

                If Not IsNothing(rawQueues.Tables) AndAlso Not rawQueues.Tables(0).Rows.Count.Equals(0) Then
                    ddlDxiQueue.DataSource = rawQueues.Tables(0)
                    ddlDxiQueue.DataValueField = "id"
                    ddlDxiQueue.DataTextField = "name"
                    ddlDxiQueue.DataBind()
                    rawQueues.Dispose()
                End If
                ddlDxiQueue.Items.Insert(0, New Web.UI.WebControls.ListItem(String.Empty, 0))


                If Not IsNothing(ddlDxiQueue.Items.FindByValue(_provider.QueueId)) Then _
                    ddlDxiQueue.Items.FindByValue(_provider.QueueId).Selected = True
            End If
        End Sub

    End Class

End Namespace