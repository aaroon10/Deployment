Namespace API

    Public MustInherit Class DataObject
        Inherits System.Configuration.Provider.ProviderBase
        Implements IDisposable

        ''' <summary>
        ''' True when the provider has initialised
        ''' </summary>
        ''' <remarks>Should be set after successful completion of Init</remarks>
        Public Initialised As Boolean = False

        ''' <summary>
        ''' Allows for the provider to do whatever is necessary to set itself up
        ''' </summary>
        Public MustOverride Sub Init(ByVal hasHeaders As Boolean, ByVal delimiter As Char, ByVal filePath As String)

        Public MustOverride Overrides ReadOnly Property Name() As String
        Public MustOverride Overrides ReadOnly Property Description() As String

        ''' <summary>
        ''' Lowercase list of supported file extensions, including leading period
        ''' </summary>
        Public MustOverride ReadOnly Property SupportedFileExtensions() As String()

        Public Function Verify() As Boolean
            Return Me.Verify(Nothing, Nothing)
        End Function

        Public MustOverride Function Verify(ByVal hasHeaders As Boolean, ByVal checkForMappedColumns As Business.DataMappingCollection) As Boolean

        Public MustOverride Function Read() As Boolean

        Public MustOverride ReadOnly Property Columns() As String()

        Public MustOverride Sub Dispose() Implements IDisposable.Dispose

        Public MustOverride ReadOnly Property CurrentRecordIndex() As Integer

        Public MustOverride Sub Reset()

        Public MustOverride ReadOnly Property Length() As Integer

        Default Public MustOverride ReadOnly Property Item(ByVal index As Integer) As String
        Default Public MustOverride ReadOnly Property Item(ByVal field As String) As String

    End Class

End Namespace