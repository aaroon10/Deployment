Imports System.Configuration.Provider
Imports System.Configuration

Namespace API.ProviderModel

    Public Class SafeProviderCollection(Of ProviderType As ProviderBase)
        Inherits ProviderCollection

        Default Public Overloads ReadOnly Property Item(ByVal name As String) As ProviderType
            Get
                Return DirectCast(MyBase.Item(name), ProviderType)
            End Get
        End Property

    End Class

End Namespace