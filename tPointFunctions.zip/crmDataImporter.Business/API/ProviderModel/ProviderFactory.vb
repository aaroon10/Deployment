Imports System.Configuration.Provider
Imports System.Configuration
Imports Newtonsoft.Json

Namespace API.ProviderModel

    <Serializable()> _
    Public Class ProviderFactory(Of ProviderType As System.Configuration.Provider.ProviderBase)

        Private _provider As ProviderType
        Private _providers As New SafeProviderCollection(Of ProviderType)
        Private _targetProvider As Type
        Private _lock As New Object
        Private _initialised As Boolean
        Private _initialiseException As Exception

        Public ReadOnly Property Providers() As SafeProviderCollection(Of ProviderType)
            Get
                If Not _initialised Then _
                    Initialise()
                Return _providers
            End Get
        End Property

        Public ReadOnly Property Instance() As ProviderType
            Get
                If Not _initialised Then _
                    Initialise()
                Return _provider
            End Get
        End Property

        Private ReadOnly Property ConfigSectionName() As String
            Get
                Return GetType(ProviderType).ToString
            End Get
        End Property

        Public Sub New()
            _initialised = False
            _lock = New Object

        End Sub

        Public Sub New(ByVal TargetProvider As Type)
            Me.New()
            _initialised = False
            _lock = New Object

            _targetProvider = TargetProvider
        End Sub

        Private Sub Initialise()
            If _initialised Then
                If Not IsNothing(_initialiseException) Then _
                    Throw _initialiseException
            Else
                SyncLock _lock
                    Try
                        If _initialised Then
                            If Not IsNothing(_initialiseException) Then _
                                Throw _initialiseException
                            Exit Sub
                        End If

                        If IsNothing(_targetProvider) Then
                            InitialiseFromConfig()
                        Else
                            InitialiseSpecificProvider()
                        End If
                    Catch ex As Exception
                        _initialiseException = ex
                    End Try

                    _initialised = True

                    If Not IsNothing(_initialiseException) Then _
                        Throw _initialiseException
                End SyncLock
            End If
        End Sub

        Private Sub InitialiseFromConfig()
            Dim config As ProviderConfigurationSection = GetProviderConfigurationSection()

            If IsNothing(_initialiseException) Then
                'If String.IsNullOrEmpty(config.DefaultProvider) Then
                '    _initialiseException = New ProviderException("Default provider not specified.")
                'Else
                _providers = New SafeProviderCollection(Of ProviderType)

                ProviderModel.ProvidersHelper.InstantiateProviders(config.Providers, _providers, GetType(ProviderType))
                _providers.SetReadOnly()



                'If IsNothing(_providers(config.DefaultProvider)) Then
                '    _initialiseException = New ProviderException("Default provider not specified.")
                'Else
                '    _provider = _providers(config.DefaultProvider)
                'End If
                'End If
            End If
        End Sub

        Private Sub InitialiseSpecificProvider()
            If IsNothing(_initialiseException) Then
                Dim config As New System.Configuration.ProviderSettings(_targetProvider.Name, _targetProvider.AssemblyQualifiedName)
                _provider = ProvidersHelper.InstantiateProvider(config, _targetProvider)
            End If
        End Sub

        Private Function GetProviderConfigurationSection() As ProviderConfigurationSection
            If String.IsNullOrEmpty(ConfigSectionName) Then
                _initialiseException = New ProviderException("configSectionName cannot be null or empty")
                Return Nothing
            End If

            Dim config As ProviderConfigurationSection = ConfigurationManager.GetSection(ConfigSectionName)

            Dim config2 As New System.Configuration.ProviderSettings("CSV", "crmDataImporter.Business.Providers.CsvDataObject, crmDataImporter.Business")
            config.Providers.Add(config2)
            Dim config3 As New System.Configuration.ProviderSettings("Excel", "crmDataImporter.Business.Providers.ExcelDataObject, crmDataImporter.Business")
            config.Providers.Add(config3)

            If IsNothing(config) Then _
                _initialiseException = New ProviderException("Unable to load provider configuration settings.")

            Return config
        End Function

    End Class

End Namespace