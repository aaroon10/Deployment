Imports System.Configuration.Provider
Imports System.Configuration

Namespace API.ProviderModel

    Public Class ProviderConfigurationSection
        Inherits ConfigurationSection

        Private Shared ReadOnly _Providers As ConfigurationProperty = New ConfigurationProperty("Providers", GetType(ProviderSettingsCollection), Nothing, ConfigurationPropertyOptions.None)

        Public Sub New()
            MyBase.New()
        End Sub

        Default Protected Overloads Property Item(ByVal propertyName As String) As Object
            Get
                Try
                    Return MyBase.Item(propertyName)
                Catch ex As NullReferenceException
                    'If the property isn�t found we get a very unhelpful NullReferenceException in the base ConfigurationSection class, 
                    'so we catch this here and throw something more helpful
                    Throw New KeyNotFoundException("Could not find element matching key '" & propertyName & "'. Property names are case-sensitive.", ex)
                End Try
            End Get
            Set(ByVal value)
                MyBase.Item(propertyName) = value
            End Set
        End Property

        <ConfigurationProperty("Providers", DefaultValue:=Nothing)> _
        Public ReadOnly Property Providers() As ProviderSettingsCollection
            Get
                Return CType(Me.Item(_Providers), ProviderSettingsCollection)
            End Get
        End Property

    End Class

End Namespace