Imports System.Configuration.Provider
Imports System.Configuration
Imports System.Collections.Specialized

Namespace API.ProviderModel

    Public Class ProvidersHelper

        ''' <summary>
        ''' ripped using reflector
        ''' </summary>
        Public Shared Function InstantiateProvider(ByVal providerSettings As ProviderSettings, ByVal providerType As Type) As ProviderBase
            Dim base2 As ProviderBase = Nothing

            Try
                Dim str As String = Nothing

                If Not IsNothing(providerSettings.Type) Then _
                    str = providerSettings.Type.Trim

                If String.IsNullOrEmpty(str) Then _
                    Throw New ArgumentException("Provider type name is invalid")

                Dim c As Type = Type.GetType(str, True, True)
                If Not providerType.IsAssignableFrom(c) Then _
                    Throw New ArgumentException(String.Format("Provider must implement type {0}.", providerType.ToString()))

                base2 = DirectCast(Activator.CreateInstance(c), ProviderBase)

                Dim parameters As NameValueCollection = providerSettings.Parameters
                Dim config As New NameValueCollection(parameters.Count, StringComparer.Ordinal)

                For Each str2 As String In parameters
                    config.Item(str2) = parameters.Item(str2)
                Next

                base2.Initialize(providerSettings.Name, config)
            Catch exception As Exception
                If TypeOf exception Is ConfigurationException Then
                    Throw
                End If
                Throw New ConfigurationErrorsException(exception.Message, providerSettings.ElementInformation.Properties.Item("type").Source, providerSettings.ElementInformation.Properties.Item("type").LineNumber)
            End Try

            Return base2
        End Function

        ''' <summary>
        ''' ripped using reflector
        ''' </summary>
        Public Shared Sub InstantiateProviders(ByVal providerSettings As ProviderSettingsCollection, ByVal providers As ProviderCollection, ByVal providerType As Type)
            For Each settings As ProviderSettings In providerSettings
                providers.Add(ProviderModel.ProvidersHelper.InstantiateProvider(settings, providerType))
            Next
        End Sub

    End Class

End Namespace