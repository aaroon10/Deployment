Namespace API

    Public Class CachedAssemblyResource

        Private _cachedFilename As String

        Public ReadOnly Property CachedFilename() As String
            Get
                If String.IsNullOrEmpty(_cachedFilename) Then _
                    Throw New Exception("Resource not initialised")

                Return _cachedFilename
            End Get
        End Property

        Public Sub New(ByVal webControl As Web.UI.Control, ByVal resourceName As String)
            Me.New(webControl, resourceName, "~/cache/")
        End Sub

        Public Sub New(ByVal webControl As Web.UI.Control, ByVal resourceName As String, ByVal relativeCacheLocation As String)
            If IsNothing(webControl) Then _
                Throw New ArgumentNullException("webControl")
            If String.IsNullOrEmpty(resourceName) Then _
                Throw New ArgumentNullException("resourceName")
            If String.IsNullOrEmpty(relativeCacheLocation) Then _
                Throw New ArgumentNullException(relativeCacheLocation)

            'make sure the cache location is valid
            If Not relativeCacheLocation.StartsWith("~/") Then _
                Throw New Exception("Cache location must be app relative, e.g. ~/cache/")
            If Not relativeCacheLocation.EndsWith("/") Then _
                relativeCacheLocation &= "/"

            'compile a filename for the cache file
            Dim cacheName As String = relativeCacheLocation & resourceName & "_v" & webControl.GetType.Assembly.GetName.Version.ToString & IO.Path.GetExtension(resourceName)
            Dim fullCacheName As String = Web.HttpContext.Current.Server.MapPath(cacheName)

            If Not IO.File.Exists(fullCacheName) Then
                'read the resource from the assembly
                Dim resourceFile As IO.Stream = webControl.GetType.Assembly.GetManifestResourceStream(resourceName)

                If IsNothing(resourceFile) Then _
                    Throw New Exception("Resource '" & resourceName & "' was not found in assembly '" & webControl.GetType.Assembly.FullName & "')")

                'buffer the contents of the resource and write to the file
                Dim buffer(resourceFile.Length) As Byte
                Dim cacheFile As New IO.FileStream(fullCacheName, IO.FileMode.Create, IO.FileAccess.Write)

                resourceFile.Read(buffer, 0, resourceFile.Length)
                cacheFile.Write(buffer, 0, resourceFile.Length)

                cacheFile.Close()
                resourceFile.Close()
            End If

            'setup the filename property once we have a resource safely cached
            If IO.File.Exists(fullCacheName) Then _
                _cachedFilename = cacheName
        End Sub

    End Class

End Namespace