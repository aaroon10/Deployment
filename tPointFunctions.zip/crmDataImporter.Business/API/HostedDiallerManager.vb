Namespace API

    Public Class HostedDiallerManager

        Public Shared Function SuitableProvider(ByVal forDialler As Enums.DiallerTypes) As crmDataImporter.Business.API.HostedDialler
            Dim myProviders As crmDataImporter.Business.API.ProviderModel.SafeProviderCollection(Of crmDataImporter.Business.API.HostedDialler)
            Dim myFactory As New crmDataImporter.Business.API.ProviderModel.ProviderFactory(Of crmDataImporter.Business.API.HostedDialler)
            myProviders = myFactory.Providers

            For Each myProvider As crmDataImporter.Business.API.HostedDialler In myProviders
                If myProvider.DiallerType = forDialler Then _
                    Return myProvider
            Next

            Return Nothing
        End Function

    End Class

End Namespace