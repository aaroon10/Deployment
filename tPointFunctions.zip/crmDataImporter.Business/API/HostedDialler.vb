Namespace API

    Public MustInherit Class HostedDialler
        Inherits System.Configuration.Provider.ProviderBase
        Implements IDisposable

        Public Initialised As Boolean

        Friend _config As DataSet
        Public Config As Xml.XmlDocument
        Private _CampaignId As Integer

        Public Property CampaignId() As Integer
            Get
                Return _CampaignId
            End Get
            Set(ByVal value As Integer)
                _CampaignId = value
            End Set
        End Property

        Public MustOverride ReadOnly Property DiallerType() As Enums.DiallerTypes

        Public MustOverride ReadOnly Property ConfigurationControl(ByVal loadDefaults As Boolean) As API.IDiallerConfigurationControl

        Public MustOverride Sub Init(ByVal forCampaign As Integer, ByVal config As Xml.XmlDocument)

        Public MustOverride Sub UpdateConfig()
        Friend MustOverride Sub EnsureConfig()

        Friend Sub WriteBaseConfigValue(ByVal name As String, ByVal value As String)
            EnsureConfig()

            _config.Tables("transferSettings").Rows(0).Item(name) = value

            UpdateXmlConfig()
        End Sub

        Friend Function ReadBaseConfigValue(Of valueType)(ByVal name As String) As valueType
            'we're only using the xml doc for loading and saving of config data. internally we get config from the dataset
            EnsureConfig()

            Dim myVal As Object = _config.Tables("transferSettings").Rows(0).Item(name)

            If IsDBNull(myVal) Then _
                Return Nothing

            Return CType(myVal, valueType)
        End Function

        Private Sub UpdateXmlConfig()
            Dim myStream As New IO.MemoryStream
            Dim myWriter As New Xml.XmlTextWriter(myStream, Nothing)

            Config = New Xml.XmlDocument

            _config.WriteXml(myWriter, XmlWriteMode.WriteSchema)

            myWriter.Flush()
            myStream.Position = 0 'reader requires stream to be at the beginning

            Dim myreader As New IO.StreamReader(myStream)
            Dim mystring As String = myreader.ReadToEnd

            Config.LoadXml(mystring)
            myStream.Dispose()
        End Sub

        Public MustOverride Sub Dispose() Implements IDisposable.Dispose

        Public MustOverride Property BatchSize() As Integer

        Public MustOverride Sub PerformOperation(ByVal forJob As Object)

        Public MustOverride ReadOnly Property OperationProgress() As Integer

        Public Event OperationProgressChanged(ByVal toValue As Integer)
        Public Event OperationCompleted(ByVal errors As List(Of Exception))

        Protected Sub OnOperationProgressChanged(ByVal toValue As Integer)
            RaiseEvent OperationProgressChanged(toValue)
        End Sub
        Protected Sub OnOperationCompleted(ByVal errors As List(Of Exception))
            RaiseEvent OperationCompleted(errors)
        End Sub

    End Class

End Namespace