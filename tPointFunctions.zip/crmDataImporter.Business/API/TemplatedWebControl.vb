Namespace API

    <Web.UI.ParseChildren(True), Web.UI.PersistChildren(True)> _
    Public MustInherit Class TemplatedWebControl
        Inherits Web.UI.WebControls.WebControl
        Implements Web.UI.INamingContainer

        Private _skinTemplate As Web.UI.ITemplate

        Public Overrides ReadOnly Property Controls() As Web.UI.ControlCollection
            Get
                Me.EnsureChildControls()
                Return MyBase.Controls
            End Get
        End Property

        Public Overrides Sub DataBind()
            Me.EnsureChildControls()
            MyBase.DataBind()
        End Sub

        <ComponentModel.Browsable(False), Web.UI.PersistenceMode(Web.UI.PersistenceMode.InnerProperty)> _
        Public Property SkinTemplate() As Web.UI.ITemplate
            Get
                Return _skinTemplate
            End Get
            Set(ByVal Value As Web.UI.ITemplate)
                _skinTemplate = Value
                ChildControlsCreated = False
            End Set
        End Property

        Public MustOverride ReadOnly Property SkinPath() As String

        Protected MustOverride Sub AttachChildControls()

        Public Overrides Sub RenderBeginTag(ByVal writer As Web.UI.HtmlTextWriter)
        End Sub

        Public Overrides Sub RenderEndTag(ByVal writer As Web.UI.HtmlTextWriter)
        End Sub

        Public Overloads Function FindControl(ByVal id As String) As Web.UI.Control
            Dim myControl As Web.UI.Control = MyBase.FindControl(id)

            If IsNothing(myControl) And Me.Controls.Count = 1 Then _
                myControl = Me.Controls(0).FindControl(id)

            Return myControl
        End Function

        Protected Overrides Sub CreateChildControls()
            Me.Controls.Clear()

            Dim _skinLoaded As Boolean = False
            Dim skin As Web.UI.Control = Me.Page.LoadControl(Me.SkinPath)
            Me.Controls.Add(skin)
            _skinLoaded = True

            If Not _skinLoaded Then _
                Throw New Web.HttpException("Template not found for control '" & Me.GetType.Name & "'")

            Me.AttachChildControls()
        End Sub

    End Class

End Namespace