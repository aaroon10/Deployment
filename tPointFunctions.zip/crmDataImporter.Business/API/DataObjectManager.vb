Namespace API

    Public Class DataObjectManager

        Public Shared Function SuitableProvider(ByVal forExtension As String) As crmDataImporter.Business.API.DataObject
            Dim myProviders As crmDataImporter.Business.API.ProviderModel.SafeProviderCollection(Of crmDataImporter.Business.API.DataObject)
            Dim myFactory As New crmDataImporter.Business.API.ProviderModel.ProviderFactory(Of crmDataImporter.Business.API.DataObject)
            myProviders = myFactory.Providers

            For Each myProvider As crmDataImporter.Business.API.DataObject In myProviders
                If Array.IndexOf(myProvider.SupportedFileExtensions, forExtension) > -1 Then _
                    Return myProvider
            Next

            Return Nothing
        End Function

    End Class

End Namespace