Namespace API

    Public Interface IDiallerConfigurationControl

        ReadOnly Property SkinPath() As String
        Property LoadDefaults() As Boolean
        Sub AttachChildControls()
        Sub StoreData()

    End Interface

End Namespace