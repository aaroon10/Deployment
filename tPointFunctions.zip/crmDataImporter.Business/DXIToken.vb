﻿Imports System.Runtime.CompilerServices

Imports System.Net
Imports System.IO
Imports System.Xml


Module UnixTimeDateExtensions

    ''' <summary>
    ''' Converts a DateTime to a Unix timestamp
    ''' </summary>
    ''' <param name="value">The Datetime to convert. If Kind is unspecified, a Local time is assumed.</param>
    ''' <returns>A Double containing the Unix timestamp.</returns>
    <Extension()> _
    Public Function ToUnixTimestamp(value As DateTime) As Double

        ' Create Timespan by subtracting the value provided from the Unix Epoch
        Dim span As TimeSpan = (value.ToUniversalTime() - New DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc))

        ' return the total seconds (which is a UNIX timestamp)
        Return span.TotalSeconds

    End Function

    ''' <summary>
    ''' Convert a Unix timestamp to a Local DateTime
    ''' </summary>
    ''' <param name="unixTimestamp">A Double containing the Unix timestamp.</param>
    ''' <returns>A DateTime with it's Kind set to Local.</returns>
    <Extension()> _
    Public Function FromUnixTimestamp(unixTimestamp As Double) As DateTime

        ' Unix timestamp is seconds past epoch
        Return (New DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).AddSeconds(unixTimestamp).ToLocalTime()

    End Function

    ''' <summary>
    ''' Convert a Unix timestamp to a DateTime with a specified Kind
    ''' </summary>
    ''' <param name="unixTimeStamp">A Double containing the Unix timestamp.</param>
    ''' <param name="kind">The DateTimeKind for the returned DateTime. If set to Unspecified, the returned DateTime will be Local.</param>
    ''' <returns>A DateTime with the specified Kind.</returns>
    <Extension()> _
    Public Function FromUnixTimestamp(unixTimestamp As Double, kind As DateTimeKind) As DateTime

        Dim rtnVal As DateTime = unixTimestamp.FromUnixTimestamp()

        If kind = DateTimeKind.Utc Then
            Return rtnVal.ToUniversalTime()
        Else
            Return rtnVal
        End If

    End Function

End Module
Public Class DXIToken

    ''' <summary>
    ''' The full URL for the DXI token api, not including any parameters
    ''' </summary>
    Public Property TokenURL As String

    ''' <summary>
    ''' The username for obtaining a token for this DXI account
    ''' </summary>
    Public Property TokenUsername As String

    ''' <summary>
    ''' The password for obtaining a token for this DXI account
    ''' </summary>
    Public Property TokenPassword As String

    Private _token As String
    Private _tokenExpiry As DateTime
    Private Const _defaultUrl As String = "https://api.dxi-easycall.net/token.php"

    ''' <summary>
    ''' Creates a new instance of this class with the specified username and password
    ''' </summary>
    ''' <param name="username">The username for this DXI account</param>
    ''' <param name="password">The password for this DXI account</param>
    Public Sub New(username As String, password As String)
        Me.New(username, password, _defaultUrl)
    End Sub

    ''' <summary>
    ''' Creates a new instance of this class with the specified username, password and token base url
    ''' </summary>
    ''' <param name="username">The username for this DXI account</param>
    ''' <param name="password">The password for this DXI account</param>
    ''' <param name="tokenUrl">The base url (with no parameters) for the token api</param>
    Public Sub New(username As String, password As String, tokenUrl As String)
        Me.TokenUsername = username
        Me.TokenPassword = password
        Me.TokenURL = tokenUrl
    End Sub

    ''' <summary>
    ''' Creates a new instance of this class with the specified token
    ''' </summary>
    ''' <param name="token">The DXI token</param>
    ''' <param name="tokenexpiry">The expiry date of the DXI token</param>
    Public Sub New(token As String, tokenExpiry As Date)
        Me.New(token, tokenExpiry, _defaultUrl)
    End Sub

    ''' <summary>
    ''' Creates a new instance of this class with the specified token
    ''' </summary>
    ''' <param name="token">The DXI token</param>
    ''' <param name="tokenexpiry">The expiry date of the DXI token</param>
    ''' <param name="tokenUrl">The base url (with no parameters) for the token api</param>
    Public Sub New(token As String, tokenExpiry As Date, tokenUrl As String)
        Me.TokenURL = tokenUrl
        SetToken(token, tokenExpiry)
    End Sub

    ''' <summary>
    ''' The token for this DXI account.
    ''' </summary>
    Public ReadOnly Property Token() As String
        Get
            Return _token
        End Get
    End Property

    ''' <summary>
    ''' The expiry date of this token
    ''' </summary>
    Public ReadOnly Property TokenExpiry() As Date
        Get
            Return _tokenExpiry
        End Get
    End Property

    ''' <summary>
    ''' Set the token and expiry date
    ''' </summary>
    ''' <param name="token">The token for this DXI account</param>
    ''' <param name="tokenExpiry">The expiry date of this token</param>
    Public Sub SetToken(token As String, tokenExpiry As Date)
        _token = token
        _tokenExpiry = tokenExpiry
    End Sub

    ''' <summary>
    ''' Clears the Token information
    ''' </summary>
    Public Sub ClearToken()
        _token = ""
        _tokenExpiry = DateTime.MinValue
    End Sub

    ''' <summary>
    ''' Check if we have a valid Token
    ''' </summary>
    ''' <returns>True if we have a valid Token, otherwise False.</returns>
    Public Function IsValid() As Boolean
        If Me.Token <> "" AndAlso Me.TokenExpiry > DateTime.Now Then
            Return True
        Else
            Return False
        End If
    End Function

    ''' <summary>
    ''' Obtain a valid DXI Token
    ''' </summary>
    ''' <returns>A Token string if successful, else Nothing</returns>
    ''' <remarks>As well as returning a Token string, this function sets the Token and TokenExpiry properties</remarks>
    Public Function GetDxiToken() As String
        Return GetDxiToken("")
    End Function

    ''' <summary>
    ''' Obtain a valid DXI Token for a specific ip address
    ''' </summary>
    ''' <param name="ipaddress">The ip address to get a token for</param>
    ''' <returns>A Token string if successful, else Nothing</returns>
    ''' <remarks>As well as returning a Token string, this function sets the Token and TokenExpiry properties</remarks>
    Public Function GetDxiToken(ipaddress As String) As String

        Dim responseString As String = String.Empty
        Dim verboseError As Boolean = False

        Try

            If Me.Token <> "" Then
                If ValidateToken() Then
                    Return Me.Token
                End If
            End If

            ClearToken()

            Dim url As String = String.Format("{0}?action=get&username={1}&password={2}&format=xml", TokenURL, TokenUsername, TokenPassword)
            If ipaddress <> "" Then
                url &= "&address=" & ipaddress
            End If

            Dim webRQ As WebRequest = WebRequest.Create(url)

            Using strm As Stream = webRQ.GetResponse().GetResponseStream()

                If strm IsNot Nothing Then

                    Using reader As New StreamReader(strm)
                        responseString = reader.ReadToEnd()
                    End Using

                    Dim xmlDoc = New XmlDocument()
                    xmlDoc.LoadXml(responseString)

                    Dim xsuccess As XmlNode = xmlDoc.SelectSingleNode("/result/success")

                    If xsuccess IsNot Nothing Then

                        If xsuccess.InnerText = "1" Then

                            Dim xexpire As XmlNode = xmlDoc.SelectSingleNode("/result/expire")

                            If xexpire IsNot Nothing Then

                                Dim uts As Double

                                If Double.TryParse(xexpire.InnerText, uts) = False Then
                                    Throw New ArithmeticException(String.Format("An invalid token expiry timestamp was returned: {0}. " &
                                        "An error occured while trying to convert to a double datatype.", xexpire.InnerText))
                                End If

                                Dim xtoken As XmlNode = xmlDoc.SelectSingleNode("/result/token")

                                If xtoken IsNot Nothing Then
                                    SetToken(xtoken.InnerText, uts.FromUnixTimestamp())
                                    Return Me.Token
                                End If

                            End If

                        Else
                            Dim xerror As XmlNode = xmlDoc.SelectSingleNode("/result/error")

                            If xerror IsNot Nothing AndAlso xerror.InnerText <> "" Then
                                Throw New ApplicationException(xerror.InnerText)
                            End If

                            verboseError = True
                            Throw New ApplicationException("The token request was not successful.")
                        End If

                    Else
                        verboseError = True
                        Throw New ApplicationException("Unexpected XML returned. Can't find success element.")
                    End If

                End If

            End Using

        Catch ex As Exception
            If verboseError Then
                Throw New ApplicationException("Error obtaining Dxi token : " & ex.ToString() & Environment.NewLine & " xmldata=" & responseString, ex)
            Else
                Throw New ApplicationException("Error obtaining Dxi token : " & ex.Message(), ex)
            End If
        End Try

        Return Nothing

    End Function

    ''' <summary>
    ''' Validate the current token
    ''' </summary>
    ''' <returns>True if the current token is valid, otherwise False.</returns>
    Public Function ValidateToken() As Boolean
        Return ValidateToken(Me.Token)
    End Function

    ''' <summary>
    ''' Validate the supplied token
    ''' </summary>
    ''' <param name="token">The token to validate</param>
    ''' <returns>True if the supplied token is valid, otherwise False.</returns>
    Public Function ValidateToken(token As String) As Boolean
        Dim responseString As String = String.Empty

        Try

            Dim webRQ As WebRequest = WebRequest.Create(String.Format("{0}?action=validate&token={1}&format=xml", TokenURL, token))

            Using strm As Stream = webRQ.GetResponse().GetResponseStream()

                If strm IsNot Nothing Then

                    Using reader As New StreamReader(strm)
                        responseString = reader.ReadToEnd()
                    End Using

                    Dim xmlDoc = New XmlDocument()
                    xmlDoc.LoadXml(responseString)

                    Dim xsuccess As XmlNode = xmlDoc.SelectSingleNode("/result/success")

                    If xsuccess IsNot Nothing Then

                        If xsuccess.InnerText = "1" Then
                            Return True
                        Else
                            Return False
                        End If

                    Else
                        Throw New ApplicationException("Unexpected XML returned. Can't find success element.")
                    End If

                End If

            End Using

        Catch ex As Exception
            Throw New ApplicationException("Error validation Dxi token : " & ex.ToString() & Environment.NewLine & " xmldata=" & responseString, ex)
        End Try

        Return False
    End Function

End Class

