Imports Microsoft.ApplicationBlocks.Data

<Serializable()> _
Public Class JobCollection
    Inherits CollectionBase

    Private _ParentImportId As Integer

    ''' <summary>
    ''' The id of the parent import
    ''' </summary>
    Friend Property ParentImportId() As Integer
        Get
            Return _ParentImportId
        End Get
        Set(ByVal Value As Integer)
            _ParentImportId = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns an Job object by collection index
    ''' </summary>
    Default Public Property Item(ByVal index As Integer) As crmDataImporter.Business.Job
        Get
            Return MyBase.List.Item(index)
        End Get
        Set(ByVal Value As crmDataImporter.Business.Job)
            MyBase.List.Item(index) = Value
        End Set
    End Property

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Loads an Job collection for a parent import
    ''' </summary>
    Public Sub New(ByVal forParent As crmDataImporter.Business.DataImport)
        Me.LoadFromDb(forParent)
    End Sub

    ''' <summary>
    ''' Checks to make sure only valid objects are added to the collection
    ''' </summary>
    Protected Overrides Sub OnValidate(ByVal value As Object)
        MyBase.OnValidate(value)

        If Not TypeOf value Is crmDataImporter.Business.Job Then _
            Throw New ArgumentException("Collection only accepts Job objects")
    End Sub

    ''' <summary>
    ''' Adds an object to the collection
    ''' </summary>
    Public Sub Add(ByVal item As crmDataImporter.Business.Job)
        If Not IsNothing(item) Then _
            MyBase.List.Add(item)
    End Sub

    ''' <summary>
    ''' Removes the specified item
    ''' </summary>
    Public Sub Remove(ByVal item As crmDataImporter.Business.Job)
        If Not IsNothing(item) Then _
            MyBase.List.Remove(item)
    End Sub

    ''' <summary>
    ''' Loads the collection with Jobs for a parent import
    ''' </summary>
    Public Overridable Sub LoadFromDb(ByVal parentImport As crmDataImporter.Business.DataImport)
        _ParentImportId = parentImport.Id

        Dim rawData As DataSet = SqlHelper.ExecuteDataset(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_Job_GetCollection", _
                                                                    New SqlClient.SqlParameter("@@HeaderId", Me.ParentImportId))

        If Not IsNothing(rawData) AndAlso Not IsNothing(rawData.Tables) AndAlso Not rawData.Tables(0).Rows.Count.Equals(0) Then

            For Each jobRow As DataRow In rawData.Tables(0).Rows
                Me.Add(New crmDataImporter.Business.Job(jobRow))
            Next

            rawData.Dispose()
        End If
    End Sub

    ''' <summary>
    ''' Saves all the Jobs in the collection
    ''' </summary>
    Public Sub Save()
        For Each myJob As crmDataImporter.Business.Job In Me
            myJob.Save(Me.ParentImportId)
        Next
    End Sub

End Class
