Imports System.Net
Imports System.IO
Imports Microsoft.ApplicationBlocks.Data.SqlHelper


Public Enum dxiAction
    'update = 2
    insert = 0
    delete = 1
End Enum

Public Enum errorNum
    postfileError = 0

End Enum

Public Class contactRecords

    Private _tempFolder As String
    Private _importId As Long
    Private _strConn As String
    Private _batchRowCount As Long
    Private _credentials As tPointCM4.clsDXI.credentials
    Private _cmQueueId As Long
    Private _dxiQueueId As Long
    Private _Priority As Long
    Private _passCallback As Boolean
    Private _Action As String
    Private _Status As Integer
    Private _passCB_sametime As Integer

    Private colId As Collection
    Private rdr As SqlClient.SqlDataReader
    Private colparam() As SqlClient.SqlParameter

    Public Event batchCompleted(ByVal dxiRetVal As String)
    Public Event errorEvent(ByVal source As String, ByVal message As String)
    Public Event processComplete()

    'PJ Tokenised DXI Call WR:13164 09/05/2014+
    Private _strTokenUser As String
    Private _strTokenPW As String
    Private _token As DXIToken
    Private _strBaseDXIURL As String
    Private _strTokenURLPath As String
    Private _strDatabaseURLPath As String
    'PJ Tokenised DXI Call WR:13164 09/05/2014-

    Sub New(ByVal tempFolder As String, _
            ByVal importId As Long, _
            ByVal strConn As String, _
            ByVal queueID As Long, _
            ByVal priority As Long, _
            ByVal batchrowcount As Long, _
            ByVal action As dxiAction, _
            Optional ByVal Status As Integer = -1, _
            Optional ByVal passCallback As Boolean = False, _
            Optional ByVal passCB_sametime As Integer = 0)

        Try
            Select Case action
                Case dxiAction.delete
                    _Action = "delete"
                Case dxiAction.insert
                    _Action = "import"
                    'Case dxiAction.update
                    '    _Action = "update"
            End Select
            _tempFolder = Trim(tempFolder)
            If Right(_tempFolder, 1) <> "\" Then
                _tempFolder = _tempFolder & "\"
            End If

            _passCB_sametime = passCB_sametime
            _passCallback = passCallback
            _Status = Status
            _importId = importId
            _strConn = strConn
            _batchRowCount = IIf(batchrowcount = 0, 500, batchrowcount)
            _cmQueueId = queueID
            _Priority = priority
            Dim cred As New tPointCM4.clsDXI.credentials(0, "", _strConn)
            _credentials = cred
            Dim cm As New tPointCampaignMgr.main.clsCampaignHeader("")
            cm.Id = _cmQueueId
            cm.strConn = _strConn
            cm.getDetail()
            _dxiQueueId = cm.diallerCampaignId
        Catch ex As Exception
            RaiseEvent errorEvent("NEW", ex.Message)
        End Try
    End Sub

    Private Function getdataFile() As String
        Dim fn As Integer
        Try
            colId = New Collection
            Dim dataRead As Boolean = False
            Dim tmp As String = Me._tempFolder & Guid.NewGuid.ToString & ".xml"
            ReDim colparam(3)
            colparam(1) = New SqlClient.SqlParameter("@importId", _importId)
            colparam(2) = New SqlClient.SqlParameter("@rowCount", _batchRowCount)
            colparam(3) = New SqlClient.SqlParameter("@flag", IIf(_Action = "import", 0, 1))
            If _passCallback Then
                rdr = ExecuteReader(_strConn, CommandType.StoredProcedure, "dxi_getBatchwithcallback", colparam)
            Else
                rdr = ExecuteReader(_strConn, CommandType.StoredProcedure, "dxi_getBatch", colparam)
            End If
            fn = FreeFile()
            FileOpen(fn, tmp, OpenMode.Append, OpenAccess.Write)
            'Print(fn, "qid,urn,status,level,Agent_ID,ddi_1,ddi_2,ddi_3,callback,dataset_id,outcome")
            'Print(fn, vbCrLf)
            Print(fn, "<?xml version='1.0' encoding='utf-8' ?>")
            Print(fn, "<dxi>")
            Dim ln As String
            Do While rdr.Read
                dataRead = True
                colId.Add(rdr("id"))
                ln = "<record>"
                ln = ln & "<qid>" & _dxiQueueId & "</qid>"
                ln = ln & "<urn>" & rdr("id") & "</urn>"
                If Me._Action <> "delete" Then

                    ln = ln & "<status>" & _Status & "</status>"
                    ln = ln & "<level>" & _Priority & "</level>"
                    ln = ln & "<agentid>0</agentid>"
                    ln = ln & "<ddi_1>" & rdr("phone1") & "</ddi_1>"
                    ln = ln & "<ddi_2>" & rdr("phone2") & "</ddi_2>"
                    ln = ln & "<ddi_3>" & rdr("phone3") & "</ddi_3>"
                    If _passCallback Then
                        ln = ln & "<callback>" & rdr("callback") & "</callback>"
                    Else
                        ln = ln & "<callback></callback>"
                    End If
                    ln = ln & "<dataset_id>" & _importId & "</dataset_id>"
                    ln = ln & "<cb_sametime>" & _passCB_sametime & "</cb_sametime>"
                End If
                ln = ln & "</record>"
                Print(fn, ln)
                Print(fn, vbCrLf)
            Loop
            Print(fn, "</dxi>")
            FileClose(fn)
            If dataRead Then
                Return tmp
            Else
                Try
                    Kill(tmp)
                Catch ex As Exception
                End Try
                Return ""
            End If
        Catch ex As Exception
            RaiseEvent errorEvent("getDataFile", ex.Message)
            Try
                FileClose(fn)
            Catch innerex As Exception : End Try
            Return ""
        Finally
            Try
                rdr.Close()
            Catch ex As Exception : End Try
        End Try
    End Function

    Private Function postFile(ByVal uploadfile As String, ByVal url As String) As String
        Try
            Dim fileFormName As String = "easycall"
            Dim contenttype As String = "application/octet-stream"

            Dim uri As Uri = New Uri(url)

            Dim boundary As String = "----------" + DateTime.Now.Ticks.ToString("x")
            Dim webrequest As HttpWebRequest = HttpWebRequest.Create(uri)

            webrequest.ServicePoint.Expect100Continue = False
            webrequest.ContentType = "multipart/form-data; boundary=""" & boundary & """"
            webrequest.Method = "POST"

            Dim sb As System.text.StringBuilder = New System.Text.StringBuilder
            sb.Append("--")
            sb.Append(boundary)
            sb.Append(vbCrLf)
            sb.Append("Content-Disposition: form-data; name=""")
            sb.Append(fileFormName)
            sb.Append("""; filename=""")
            sb.Append(System.IO.Path.GetFileName(uploadfile) & """")
            sb.Append(vbCrLf)
            sb.Append("Content-Type: ")
            sb.Append(contenttype)
            sb.Append(vbCrLf)
            sb.Append(vbCrLf)

            Dim postHeader As String = sb.ToString()
            Dim postHeaderBytes As Byte() = System.Text.Encoding.UTF8.GetBytes(postHeader)

            Dim boundaryBytes As Byte() = System.Text.Encoding.ASCII.GetBytes(vbCrLf & "--" & boundary & vbCrLf & vbCrLf)

            Dim fileStream As System.IO.FileStream = New System.IO.FileStream(uploadfile, System.IO.FileMode.Open, System.IO.FileAccess.Read)
            Dim length As Long = postHeaderBytes.Length + fileStream.Length + boundaryBytes.Length
            webrequest.ContentLength = length

            Dim requestStream As System.IO.Stream = webrequest.GetRequestStream()

            requestStream.Write(postHeaderBytes, 0, postHeaderBytes.Length)
            Dim l As Integer = fileStream.Length
            If l < 4096 Then l = 4096
            Dim buffer(l) As Byte

            Dim bytesRead As Integer = 0
            bytesRead = fileStream.Read(buffer, 0, buffer.Length)
            While bytesRead > 0
                requestStream.Write(buffer, 0, bytesRead)
                bytesRead = fileStream.Read(buffer, 0, buffer.Length)
            End While
            requestStream.Write(boundaryBytes, 0, boundaryBytes.Length)
            Dim response As WebResponse = webrequest.GetResponse()
            Dim s As System.IO.Stream = response.GetResponseStream()
            Dim sr As System.IO.StreamReader = New System.IO.StreamReader(s)
            Dim resp As String = sr.ReadToEnd()
            sr.Close()
            s.Close()
            response.Close()
            requestStream.Close()
            fileStream.Close()
            Return resp

        Catch ex As Exception
            RaiseEvent errorEvent("postfile: URL=" & url & ", UploadFile=" & uploadfile, ex.Message)
            Return String.Empty
        End Try
    End Function

    Private Sub updateExportFlag()
        Try
            For Each i As Long In colId
                ReDim colparam(2)
                colparam(1) = New SqlClient.SqlParameter("@val", IIf(Me._Action = "delete", 0, 1))
                colparam(2) = New SqlClient.SqlParameter("@id", i)
                ExecuteNonQuery(Me._strConn, CommandType.StoredProcedure, "dxi_updateExportFlag", colparam)
            Next
        Catch ex As Exception

        End Try
    End Sub
    'PJ Tokenised DXI Call WR:13164 09/05/2014+
    Private Function CheckToken(Optional force As Boolean = False) As Boolean

        If _token Is Nothing Then
            If _strTokenUser = "" OrElse _strTokenPW = "" Then
                ' Username and Password are required
                Return False
            Else
                _token = New DXIToken(_strTokenUser, _strTokenPW)
                _token.TokenURL = _strBaseDXIURL & _strTokenURLPath
            End If
        End If

        If force OrElse _token.IsValid() = False Then
            Try
                ' Get a new token
                If _token.GetDxiToken() Is Nothing Then
                    ' Unable to obtain token
                    Return False
                Else
                    Return True
                End If
            Catch ex As Exception
                ' ex.Message
                If ex.Message.Contains("Authentication failure") Then _strTokenPW = ""
            End Try

            Return False
        Else
            ' Existing token is still valid
            Return True
        End If

    End Function
    'PJ Tokenised DXI Call WR:13164 09/05/2014-


    Public Function getApiURL() As Boolean
        '	get the DXi url from the database
        Try
            Dim sql As String = ""
            Dim objRDR1 As SqlClient.SqlDataReader        '	create datareader

            sql = "select name, val from u_diallerPreferences where name in ('dxiApiBaseUrl', 'dxiTokenUrlPath', 'dxiTokenLogin', 'dxiTokenPassword', 'dxiDatabaseUrlPath')"
            objRDR1 = Microsoft.ApplicationBlocks.Data.SqlHelper.ExecuteReader(_strConn, CommandType.Text, sql)            '	query db (convert to sp in future?)

            Do While objRDR1.Read() = True
                Select Case objRDR1("name")
                    Case "dxiApiBaseUrl"
                        _strBaseDXIURL = objRDR1("val")
                    Case "dxiTokenUrlPath"
                        _strTokenURLPath = objRDR1("val")
                    Case "dxiTokenLogin"
                        _strTokenUser = objRDR1("val")
                    Case "dxiTokenPassword"
                        _strTokenPW = objRDR1("val")
                    Case "dxiDatabaseUrlPath"
                        _strDatabaseURLPath = objRDR1("val")
                End Select
            Loop

            objRDR1.Close()
            getApiURL = True

        Catch ex As Exception
            getApiURL = False

            'logMessage = logMessage & " : DXi URL not found on database " & Sql
            'logMessage = logMessage & " : Error " & ex.Message
            ' EmailError(logMessage)
            Err.Raise(Err.Number, "DXi URL not found on database", ex.Message)
            'writeLog(Application.ProductName & ".getApiURL", logMessage, _logFile)
        Finally
            '	close the datareader
        End Try

    End Function


    Public Sub dxiImport()
        Try
            'PJ Tokenised DXI Call WR:13164 09/05/2014+
            Dim tmp As String = getdataFile()
            'Dim url As String = _credentials.dxiDbApiURL
            Dim url As String = String.Empty

            If getApiURL() Then
                If CheckToken() Then
                    url = _strBaseDXIURL & _strDatabaseURLPath & "?token=" & _token.Token & "&method=records&action=" & _Action & "&format=xml&delim=,"
                    'url = url & "?verbose=1&username=" & Me._credentials.dxiAPILogin & "&password=" & Me._credentials.dxiAPIPassword & "&method=records&action=" & _Action & "&format=xml&delim=,"

                    Do While tmp <> ""
                        Dim count As String = postFile(tmp, url)
                        Dim fn As Integer = FreeFile()
                        Dim stream As StringReader = New StringReader(count)
                        Dim s() As String = Split(count, vbCrLf)

                        If (count.Contains("error")) Then
                            RaiseEvent errorEvent("dxiImport", "Error posting to DXI: " + count)
                        End If

                        RaiseEvent batchCompleted(count)
                        updateExportFlag()
                        Try
                            Kill(tmp)
                        Catch ex As Exception
                        End Try
                        tmp = getdataFile()
                        count = ""
                    Loop

                    If Me._Action = "import" Then
                        ReDim colparam(3)
                        colparam(1) = New SqlClient.SqlParameter("@qid", _cmQueueId)
                        colparam(2) = New SqlClient.SqlParameter("@importId", Me._importId)
                        colparam(3) = New SqlClient.SqlParameter("@priority", Me._Priority)
                        ExecuteNonQuery(Me._strConn, CommandType.StoredProcedure, "cm_createQueueDataset", colparam)
                    End If
                    RaiseEvent processComplete()
                Else
                    RaiseEvent errorEvent("dxiImport", "Error getting Token for DXI")
                End If
            Else
                RaiseEvent errorEvent("dxiImport", "Error getting Dialler Info from Database")
            End If
            'PJ Tokenised DXI Call WR:13164 09/05/2014-

        Catch ex As Exception
            RaiseEvent errorEvent("dxiImport", ex.Message)
        End Try
    End Sub

End Class
