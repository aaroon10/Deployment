Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' Provides collection storage for MappedField objects
''' </summary>
<Serializable()> _
Public Class MappedFieldCollection
    Inherits CollectionBase

    Private _ParentMappingId As Integer

    ''' <summary>
    ''' The id of the parent mapping
    ''' </summary>
    Friend Property ParentMappingId() As Integer
        Get
            Return _ParentMappingId
        End Get
        Set(ByVal Value As Integer)
            _ParentMappingId = Value
        End Set
    End Property

    Public ReadOnly Property PrimaryKeys() As MappedField()
        Get
            Dim myFields As New ArrayList

            For Each myField As MappedField In Me
                If myField.PrimaryKey Then _
                    myFields.Add(myField)
            Next

            Return myFields.ToArray(GetType(MappedField))
        End Get
    End Property

    ''' <summary>
    ''' Returns a MappedField object by collection index
    ''' </summary>
    Default Public Property Item(ByVal index As Integer) As crmDataImporter.Business.MappedField
        Get
            Return MyBase.List.Item(index)
        End Get
        Set(ByVal Value As crmDataImporter.Business.MappedField)
            MyBase.List.Item(index) = Value
        End Set
    End Property

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Loads a field collection for a parent mapping
    ''' </summary>
    Public Sub New(ByVal forParent As crmDataImporter.Business.DataMapping)
        Me.LoadFromDb(forParent)
    End Sub

    ''' <summary>
    ''' Checks to make sure only valid objects are added to the collection
    ''' </summary>
    Protected Overrides Sub OnValidate(ByVal value As Object)
        MyBase.OnValidate(value)

        If Not TypeOf value Is crmDataImporter.Business.MappedField Then _
            Throw New ArgumentException("Collection only accepts MappedField objects")
    End Sub

    ''' <summary>
    ''' Adds an object to the collection
    ''' </summary>
    Public Sub Add(ByVal item As crmDataImporter.Business.MappedField)
        If Not IsNothing(item) Then _
            MyBase.List.Add(item)
    End Sub

    'INCOMPLETE
    Public Sub Insert(ByVal index As Integer, ByVal item As crmDataImporter.Business.MappedField)
        If Not IsNothing(item) Then _
            MyBase.List.Insert(index, item)
    End Sub

    ''' <summary>
    ''' Removes the specified item
    ''' </summary>
    Public Sub Remove(ByVal item As crmDataImporter.Business.MappedField)
        If Not IsNothing(item) Then _
            MyBase.List.Remove(item)
    End Sub

    ''' <summary>
    ''' Removes an item by name
    ''' </summary>
    Public Sub Remove(ByVal name As String)
        Me.Remove(Me.Find(name))
    End Sub

    ''' <summary>
    ''' Finds a field by source field name
    ''' </summary>
    Public Function Find(ByVal name As String) As crmDataImporter.Business.MappedField
        For Each myField As crmDataImporter.Business.MappedField In Me
            If myField.SourceField.Equals(name) Then _
                Return myField
        Next
        Return Nothing
    End Function

    ''' <summary>
    ''' Loads the collection with mapped fields for a parent mapping
    ''' </summary>
    Public Overridable Sub LoadFromDb(ByVal parentMapping As crmDataImporter.Business.DataMapping)
        _ParentMappingId = parentMapping.Id

        Dim rawData As DataSet = SqlHelper.ExecuteDataset(parentMapping.ConnectionString, CommandType.StoredProcedure, "g_DataImport_MappedField_GetCollectionv2", _
                                                                    New SqlClient.SqlParameter("@@MappingId", Me.ParentMappingId))

        If Not IsNothing(rawData) AndAlso Not IsNothing(rawData.Tables) AndAlso Not rawData.Tables(0).Rows.Count.Equals(0) Then

            For Each fieldRow As DataRow In rawData.Tables(0).Rows
                Me.Add(New crmDataImporter.Business.MappedField(fieldRow))
            Next

            rawData.Dispose()
        End If
    End Sub

    ''' <summary>
    ''' Returns true if there is a complete path in the collection (from data source to destination)
    ''' </summary>
    Public Overridable Function ContainsCompletePath() As Boolean
        For Each myField As crmDataImporter.Business.MappedField In Me
            If Not myField.ComponentFieldId.Equals(0) AndAlso Not (IsNothing(myField.SourceField) OrElse myField.SourceField.Equals(String.Empty)) Then _
                Return True
        Next
    End Function

    ''' <summary>
    ''' Returns true of the collection contains a field with the specified source field
    ''' </summary>
    Public Function Contains(ByVal name As String) As Boolean
        Return Not IsNothing(Me.Find(name))
    End Function

    ''' <summary>
    ''' Saves all the mapped fields in the database
    ''' </summary>
    Public Overridable Sub Save()
        'drop saved fields first, unfortunately making the created/by fields fairly meaningless
        SqlHelper.ExecuteNonQuery(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_DeleteMappedFields", _
                                                                    New SqlClient.SqlParameter("@@MappingId", Me.ParentMappingId))

        'save each stored field
        For Each myField As crmDataImporter.Business.MappedField In Me
            myField.Save(Me.ParentMappingId)
        Next
    End Sub

End Class
