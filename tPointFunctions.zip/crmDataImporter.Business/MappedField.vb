Imports crmRepositoryWeb.Classes
Imports Microsoft.ApplicationBlocks.Data

''' <summary>
''' Defines a mapped field
''' </summary>
<Serializable()> _
Public Class MappedField
    Implements crmDataImporter.Business.IDatabaseObject

#Region " Fields "

    Private _Id, _CreatedBy, _UpdatedBy, _ComponentFieldId, _TemplateId, _ColPosition As Integer
    Private _Created, _Updated As Date
    Private _SourceField, _TransformTemplate As String
    Private _PrimaryKey, _IsStaticField, _UpdateFlag As Boolean 'MOD - 31/7/2017

#End Region

#Region " Properties "

    Private ReadOnly Property UserId() As Integer
        Get
            Return clsCookieHelper.CurrentEmployeeId
        End Get
    End Property


    ''' <summary>
    ''' Unique identifier for the field
    ''' </summary>
    Public Property Id() As Integer Implements IDatabaseObject.Id
        Get
            Return _Id
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Id = Value
        End Set
    End Property

    ''' <summary>
    ''' Not implemented
    ''' </summary>
    <Xml.Serialization.XmlIgnore()> _
    Public Property Name() As String Implements IDatabaseObject.Name
        Get
            Throw New NotImplementedException
        End Get
        Set(ByVal Value As String)
            Throw New NotImplementedException
        End Set
    End Property

    ''' <summary>
    ''' The date that the field was created
    ''' </summary>
    Public Property Created() As Date Implements IDatabaseObject.Created
        Get
            Return _Created
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Created = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the user who created the field
    ''' </summary>
    Public Property CreatedBy() As Integer Implements IDatabaseObject.CreatedBy
        Get
            Return _CreatedBy
        End Get
        Set(ByVal Value As Integer)
            _CreatedBy = Value
        End Set
    End Property

    ''' <summary>
    ''' The date that the field was updated
    ''' </summary>
    Public Property Updated() As Date Implements IDatabaseObject.Updated
        Get
            Return _Updated
        End Get
        Set(ByVal Value As Date)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _Updated = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the user who updated the field
    ''' </summary>
    Public Property UpdatedBy() As Integer Implements IDatabaseObject.UpdatedBy
        Get
            Return _UpdatedBy
        End Get
        Set(ByVal Value As Integer)
            If Not Serializing.IsDeserializing Then _
                Throw New Exception("Property value can only be set while deserializing object")
            _UpdatedBy = Value
        End Set
    End Property

    ''' <summary>
    ''' The id of the destination component field
    ''' </summary>
    Public Property ComponentFieldId() As Integer
        Get
            Return _ComponentFieldId
        End Get
        Set(ByVal Value As Integer)
            _ComponentFieldId = Value
        End Set
    End Property

    ''' <summary>
    ''' The name of the source field or the static value
    ''' </summary>
    Public Property SourceField() As String
        Get
            Return _SourceField
        End Get
        Set(ByVal Value As String)
            _SourceField = Value
        End Set
    End Property

    ''' <summary>
    ''' Indicates whether or not this field is a primary key
    ''' </summary>
    Public Property PrimaryKey() As Boolean
        Get
            Return _PrimaryKey
        End Get
        Set(ByVal Value As Boolean)
            _PrimaryKey = Value
        End Set
    End Property

    ''' <summary>
    ''' Indicates whether or not this field is a static field
    ''' </summary>
    Public Property IsStaticField() As Boolean
        Get
            Return _IsStaticField
        End Get
        Set(ByVal Value As Boolean)
            _IsStaticField = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns the SoruceField property if this is a static field
    ''' </summary>
    Public Property StaticValue() As String
        Get
            If Me.IsStaticField Then _
                Return Me.SourceField

            Return Nothing
        End Get
        Set(ByVal Value As String)
            If Me.IsStaticField Then _
                _SourceField = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns the Transformation property 
    ''' </summary>
    Public Property TemplateId() As Integer
        Get
            Return _TemplateId
        End Get
        Set(ByVal Value As Integer)
            _TemplateId = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns the Transformation property 
    ''' </summary>
    Public Property ColPosition() As Integer
        Get
            Return _ColPosition
        End Get
        Set(ByVal Value As Integer)
            _ColPosition = Value
        End Set
    End Property

    ''' <summary>
    ''' Returns the Transformation property 
    ''' </summary>
    Public Property TransformTemplate() As String
        Get
            Return _TransformTemplate
        End Get
        Set(ByVal Value As String)
            _TransformTemplate = Value
        End Set
    End Property

    Public Property UpdateFlag() As Boolean
        Get
            Return _UpdateFlag
        End Get
        Set(ByVal Value As Boolean)
            _UpdateFlag = Value
        End Set
    End Property

#End Region

#Region " Methods "

    Public Sub New()
    End Sub

    ''' <summary>
    ''' Loads a field from a DataRow
    ''' </summary>
    Public Sub New(ByVal loadFromRow As DataRow)
        Me.Load(loadFromRow)
    End Sub

    ''' <summary>
    ''' Creates a new field with the supplied source field
    ''' </summary>
    Public Sub New(ByVal forSourceField As String)
        _SourceField = forSourceField
    End Sub

    ''' <summary>
    ''' Loads a field from a DataRow
    ''' </summary>
    Public Sub Load(ByVal fromRow As DataRow)
        _Id = fromRow.Item("Id")
        _Created = fromRow.Item("Created")
        _CreatedBy = fromRow.Item("CreatedBy")
        _Updated = fromRow.Item("Updated")
        _UpdatedBy = fromRow.Item("UpdatedBy")
        _ComponentFieldId = fromRow.Item("CompFieldId")
        _SourceField = fromRow.Item("SourceField")
        _PrimaryKey = fromRow.Item("PrimaryKey")
        _IsStaticField = fromRow.Item("IsStaticField")
        _TemplateId = Val(fromRow.Item("TemplateId") & "")
        _TransformTemplate = fromRow.Item("transformTemplate")
        _ColPosition = fromRow.Item("ColPosition")

        If (fromRow.Table?.Columns?.Contains("UpdateFlag")) Then
            _UpdateFlag = fromRow.Item("UpdateFlag")
        Else
            _UpdateFlag = True
        End If
    End Sub

    ''' <summary>
    ''' Saves the field to the database
    ''' </summary>
    Public Sub Save(ByVal forMapping As Integer)
        Dim params(10) As SqlClient.SqlParameter

        params(0) = New SqlClient.SqlParameter("@@Id", Me.Id)

        If Me.Id.Equals(0) Then _
            params(1) = New SqlClient.SqlParameter("@@CreatedBy", Me.UserId)

        params(2) = New SqlClient.SqlParameter("@@UpdatedBy", Me.UserId)
        params(3) = New SqlClient.SqlParameter("@@MappingId", forMapping)
        params(4) = New SqlClient.SqlParameter("@@CompFieldId", Me.ComponentFieldId)
        params(5) = New SqlClient.SqlParameter("@@SourceField", Me.SourceField)
        params(6) = New SqlClient.SqlParameter("@@PrimaryKey", Me.PrimaryKey)
        params(7) = New SqlClient.SqlParameter("@@IsStaticField", Me.IsStaticField)
        params(8) = New SqlClient.SqlParameter("@@TemplateId", Me.TemplateId)
        params(9) = New SqlClient.SqlParameter("@@ColPosition", Me.ColPosition)
        params(10) = New SqlClient.SqlParameter("@@UpdateFlag", Me.UpdateFlag)

        Dim returnId As Integer = SqlHelper.ExecuteScalar(crmRepositoryWeb.Classes.clsHelper.strConn, CommandType.StoredProcedure, "g_DataImport_SaveMappedFieldv3", params)

        If Not Me.Id.Equals(returnId) Then _
            _Id = returnId
    End Sub

#End Region

End Class
