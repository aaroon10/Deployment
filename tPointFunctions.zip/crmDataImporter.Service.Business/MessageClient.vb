Public Class MessageClient
    Inherits MarshalByRefObject
    Implements crmDataImporter.Service.Business.IMessageClient

    Public Event IncomingMessage(ByVal message As String, ByVal type As Diagnostics.EventLogEntryType)

    Public Sub New(ByVal server As crmDataImporter.Service.Business.MessageServer)
        server.AddClient(Me)
    End Sub

    Public Sub Alert(ByVal message As String, ByVal type As Diagnostics.EventLogEntryType) Implements crmDataImporter.Service.Business.IMessageClient.Alert
        RaiseEvent IncomingMessage(message, type)
    End Sub

End Class
