Imports Microsoft.ApplicationBlocks.Data
Imports System.Threading

<Serializable()> _
Public Class ImportFactory
    Inherits MarshalByRefObject
    Implements IDisposable

#Region " Fields "

    Private _watchTimer, _queueTimer As Timer
    Private _pollCount As Integer
    Private _JobQueue As List(Of ThreadedJob)

#End Region

#Region " Events "

    Private Event _Abort(ByVal ex As Exception)
    Public Event Abort(ByVal ex As Exception)
    Public Event LogWrite(ByVal message As String, ByVal type As System.Diagnostics.EventLogEntryType)

#End Region

#Region " Properties "

    Public ReadOnly Property DbPollInterval() As Integer
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("DbPollInterval")
        End Get
    End Property

    Public ReadOnly Property QueuePollInterval() As Integer
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("QueuePollInterval")
        End Get
    End Property

    Public Shared ReadOnly Property EventLogSource() As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("EventLogSource")
        End Get
    End Property

    Public ReadOnly Property MaxRunningJobs() As Integer
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("MaxRunningJobs")
        End Get
    End Property

    Public ReadOnly Property VerboseLogging() As Boolean
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("VerboseLogging")
        End Get
    End Property

    Public ReadOnly Property SupportEmailAddress() As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("SupportEmailAddress")
        End Get
    End Property

    Public ReadOnly Property EmailSubject() As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("EmailSubject")
        End Get
    End Property

    Public ReadOnly Property CustomerEmailTemplate() As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("CustomerEmailTemplate")
        End Get
    End Property

    Public ReadOnly Property SupportEmailTemplate() As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("SupportEmailTemplate")
        End Get
    End Property

    Public ReadOnly Property SmtpServer() As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("SmtpServer")
        End Get
    End Property

    Public ReadOnly Property SmtpPort() As Integer
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("SmtpPort")
        End Get
    End Property

    Public ReadOnly Property SmtpUsername() As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("SmtpUsername")
        End Get
    End Property

    Public ReadOnly Property SmtpPassword() As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings.Get("SmtpPassword")
        End Get
    End Property

    Public ReadOnly Property JobsRunning() As Integer
        Get
            Dim threadCount As Integer

            For Each myJob As ThreadedJob In _JobQueue
                If myJob.Status = crmDataImporter.Business.Enums.JobStatus.InPogress Then _
                    threadCount += 1
            Next

            Return threadCount
        End Get
    End Property

    Public ReadOnly Property JobsWaiting() As Integer
        Get
            Dim waitCount As Integer

            For Each myJob As ThreadedJob In _JobQueue
                If myJob.Status = crmDataImporter.Business.Enums.JobStatus.Queued Then _
                    waitCount += 1
            Next

            Return waitCount
        End Get
    End Property

    Public ReadOnly Property QueueLength() As Integer
        Get
            If IsNothing(_JobQueue) Then _
                Return 0
            Return _JobQueue.Count
        End Get
    End Property

    Public ReadOnly Property QueueItems() As List(Of ThreadedJob)
        Get
            Return New List(Of ThreadedJob)(_JobQueue)
        End Get
    End Property

    Public ReadOnly Property ServiceTime() As Date
        Get
            Return Date.Now
        End Get
    End Property

#End Region

#Region " Methods "

    Public Sub New()
        _JobQueue = New List(Of ThreadedJob)
    End Sub

    Public Sub StartWatcher()
#If DEBUG Then
        PollDBs(1)
#Else
        'start timer for polling dbs for new import Jobs
        Dim timerDelegate As TimerCallback = AddressOf PollDBs
        _watchTimer = New Timer(timerDelegate, Nothing, 0, Me.DbPollInterval)
#End If
    End Sub

    Public Sub StartQueue()
#If DEBUG Then
        ProcessQueue(1)
#Else
        'start timer for processing the queue
        Dim timerDelegate As TimerCallback = AddressOf ProcessQueue
        _queueTimer = New Timer(timerDelegate, Nothing, 0, Me.QueuePollInterval)
#End If
    End Sub

    Public Sub PollDBs(ByVal value As Object)
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine("Polling DBs...")
        Console.WriteLine("MasterListLocation..." & System.Configuration.ConfigurationManager.AppSettings.Item("MasterListLocation"))
        Console.ResetColor()
        'MOD 
        'Dim appSettings As crmFoundation.clsApplication = Nothing
        'Dim linkField As String = crmRepository.clsShared.BusObjGetLinkTargetDetail(1, 1, "")
        If VerboseLogging Then _
            WriteToLogs("Polling databases for pending jobs", EventLogEntryType.Information, crmDataImporter.Business.Enums.EventId.DBPoll)

        Dim importJob As ThreadedJob

        Try
            Dim jobs As DataSet = SqlHelper.ExecuteDataset(System.Configuration.ConfigurationManager.AppSettings.Item("MasterListLocation"), _
                                                                    CommandType.StoredProcedure, _
                                                                    "g_DataImport_GetJobsv2", _
                                                                    New SqlClient.SqlParameter("@@Status", crmDataImporter.Business.Enums.JobStatus.Pending))

            For Each myRow As DataRow In jobs.Tables(0).Rows
                Console.WriteLine("SourceDb..." & myRow.Item("SourceDb"))
                importJob = New ThreadedJob
                importJob.ConnectionString = myRow.Item("SourceDb")
                importJob.CustomSPDB = myRow.Item("customSPDB")
                importJob.Load(myRow)

                If Not _JobQueue.Contains(importJob) Then
                    importJob.Status = crmDataImporter.Business.Enums.JobStatus.Queued
                    importJob.Save()
                    AddHandler importJob.ImportFinished, AddressOf ThreadEnd

                    If VerboseLogging Then _
                        WriteToLogs("Job with Id " & importJob.Id & " (" & importJob.ConnectionString & ") added to queue", EventLogEntryType.Information, crmDataImporter.Business.Enums.EventId.JobQueued)
                    _JobQueue.Add(importJob)
                End If
            Next

            jobs.Dispose()
        Catch ex As Exception
            Console.WriteLine("Unable to poll DBs for new jobs: " & ex.Message, EventLogEntryType.Error, crmDataImporter.Business.Enums.EventId.GeneralError)
            WriteToLogs("Unable to poll DBs for new jobs: " & ex.Message, EventLogEntryType.Error, crmDataImporter.Business.Enums.EventId.GeneralError)
        End Try

    End Sub

    Private Sub PurgeCompletedJobsFromQueue()
        Dim completedIndicies As New ArrayList

        For Each myJob As ThreadedJob In _JobQueue
            If myJob.Status = crmDataImporter.Business.Enums.JobStatus.CompletedOk Or myJob.Status = crmDataImporter.Business.Enums.JobStatus.CompletedInError Then _
                completedIndicies.Add(myJob)
        Next
        For Each myJob As ThreadedJob In completedIndicies
            Try
                _JobQueue.Remove(myJob)
            Catch : End Try
        Next
    End Sub

    Public Sub ProcessQueue(ByVal value As Object)
        'loop over queued items
        Console.ForegroundColor = ConsoleColor.Green
        Console.WriteLine("Processing queue...")
        Console.ResetColor()

        If VerboseLogging Then _
            WriteToLogs("Processing queue items", EventLogEntryType.Information, crmDataImporter.Business.Enums.EventId.ProcessQueue)
        Try

            Me.PurgeCompletedJobsFromQueue()

            'how many Jobs are running?
            Console.WriteLine("There are " & Me.JobsWaiting & " jobs waiting to start, " & Me.JobsRunning & " threads are running")

            'should we attempt to start any threads?
            If Me.JobsRunning < Me.MaxRunningJobs And Me.JobsRunning < _JobQueue.Count Then
                For Each myJob As ThreadedJob In _JobQueue
                    If myJob.Status = crmDataImporter.Business.Enums.JobStatus.Queued And Me.JobsRunning < Me.MaxRunningJobs Then
                        Dim JobThread As New Thread(AddressOf myJob.ImportData)
                        JobThread.IsBackground = False 'in theory means service must wait for imports to finish before it can be stopped
                        JobThread.Name = "JobThread_" & Guid.NewGuid.ToString
                        JobThread.Start()

                        myJob.ThreadName = JobThread.Name
                        myJob.Status = crmDataImporter.Business.Enums.JobStatus.InPogress
                        myJob.Save() 'update status for client

                        If VerboseLogging Then _
                            WriteToLogs("Started import thread with name " & JobThread.Name, EventLogEntryType.Information, crmDataImporter.Business.Enums.EventId.ThreadStart)

                        Console.ForegroundColor = ConsoleColor.Yellow
                        Console.WriteLine("Started import job, thread name is " & myJob.ThreadName)
                        Console.ResetColor()
                    End If
                Next
            End If

        Catch ex As Exception
            Console.WriteLine("Unable to complete ProcessQueue: " & ex.Message, EventLogEntryType.Error, crmDataImporter.Business.Enums.EventId.GeneralError)
            WriteToLogs("Unable to complete ProcessQueue: " & ex.Message, EventLogEntryType.Error, crmDataImporter.Business.Enums.EventId.GeneralError)
        End Try
    End Sub

    Public Sub WriteToLogs(ByVal message As String, ByVal type As System.Diagnostics.EventLogEntryType, ByVal eventId As crmDataImporter.Business.Enums.EventId)
        WriteToEventLog(message, type, eventId)
        RaiseEvent LogWrite(message, type)
    End Sub

    Public Shared Sub WriteToEventLog(ByVal message As String, ByVal type As System.Diagnostics.EventLogEntryType, ByVal eventId As crmDataImporter.Business.Enums.EventId)
        'we have to try this because during install, the source gets created against App log. so checking if the source exists provides a false positive
        Try
            EventLog.CreateEventSource(ImportFactory.EventLogSource, "tPoint Data Import Logs")
        Catch ex As Exception

        End Try

        Dim appLog As New EventLog("tPoint Data Import Logs")
        appLog.Source = ImportFactory.EventLogSource

        Try
            appLog.WriteEntry(message, type, eventId)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub ImportFactory__Abort(ByVal ex As System.Exception) Handles Me._Abort
        'tidy up before we evac
        Me.Dispose()

        RaiseEvent Abort(ex)
    End Sub

    Private Sub ThreadEnd(ByVal sender As Object)
        If VerboseLogging Then _
            WriteToLogs("The thread with name " & Threading.Thread.CurrentThread.Name & " has terminated", EventLogEntryType.Information, crmDataImporter.Business.Enums.EventId.ThreadEnd)
        Console.ForegroundColor = ConsoleColor.Red
        Console.WriteLine("Thread has finished, thread name is: " & Threading.Thread.CurrentThread.Name)
        Console.ResetColor()

        Dim myJob As crmDataImporter.Business.Job = DirectCast(sender, crmDataImporter.Business.Job)

        Try
            'send email notification if enabled
            Dim mailDetails As DataSet = SqlHelper.ExecuteDataset(myJob.ConnectionString, CommandType.StoredProcedure, _
                                                        "g_DataImport_GetEmailNotificationDetails", New SqlClient.SqlParameter("@@JobId", myJob.Id))
            Dim toAddress As String = Me.SupportEmailAddress
            Dim fromAddress As String = Me.SupportEmailAddress
            Dim customerName As String = "Mr Unknown"
            Dim customerPhone As String = "Unknown"

            If Not IsNothing(mailDetails) AndAlso Not IsNothing(mailDetails.Tables) AndAlso Not IsNothing(mailDetails.Tables(0)) AndAlso mailDetails.Tables(0).Rows.Count = 1 Then
                If Not Convert.ToString(mailDetails.Tables(0).Rows(0).Item("email")) = String.Empty Then _
                    toAddress = mailDetails.Tables(0).Rows(0).Item("email")
                customerName = mailDetails.Tables(0).Rows(0).Item("forename") & " " & mailDetails.Tables(0).Rows(0).Item("name")
                customerPhone = mailDetails.Tables(0).Rows(0).Item("phone1")
            End If

            Dim myEmail As New Net.Mail.MailMessage(fromAddress, toAddress)

            Dim thisAssembly As Reflection.Assembly = Reflection.Assembly.GetAssembly(Me.GetType)
            Dim dllFolder As String = thisAssembly.Location.Replace(thisAssembly.ManifestModule.Name, String.Empty)

            myEmail.Subject = Me.EmailSubject.Replace("[job].[Id]", myJob.Id)
            myEmail.IsBodyHtml = False

            Dim mailPath As String = dllFolder

            If toAddress = Me.SupportEmailAddress Then
                mailPath &= Me.SupportEmailTemplate
            Else
                mailPath &= Me.CustomerEmailTemplate
            End If

            If Not IO.File.Exists(mailPath) Then _
                Throw New Exception("Could not find template at " & mailPath)

            Dim customerMail As IO.StreamReader = IO.File.OpenText(mailPath)

            myEmail.Body = customerMail.ReadToEnd
            customerMail.Close()

            myEmail.Body = myEmail.Body.Replace("[customer]", customerName)
            myEmail.Body = myEmail.Body.Replace("[job].[Id]", myJob.Id)
            myEmail.Body = myEmail.Body.Replace("[job].[packagename]", myJob.ParentImport.Name)
            myEmail.Body = myEmail.Body.Replace("[phone]", customerPhone)

            Dim instance As String = myJob.ConnectionString
            Dim st As String = "Initial Catalog="
            instance = instance.Substring(instance.IndexOf(st) + st.Length, instance.IndexOf(";", instance.IndexOf(st)) - (instance.IndexOf(st) + st.Length))

            myEmail.Body = myEmail.Body.Replace("[instance]", instance)

            If myJob.Status = crmDataImporter.Business.Enums.JobStatus.CompletedOk Then
                myEmail.Body = myEmail.Body.Replace("[job].[errorbool]", "No")
                myEmail.Body = myEmail.Body.Replace("[job].[outcome]", "successful")
            ElseIf myJob.Status = crmDataImporter.Business.Enums.JobStatus.CompletedInError Then
                myEmail.Body = myEmail.Body.Replace("[job].[errorbool]", "Yes")
                myEmail.Body = myEmail.Body.Replace("[job].[outcome]", "unsuccessful")
            End If

            Dim mailClient As New Net.Mail.SmtpClient(Me.SmtpServer, Me.SmtpPort)
            mailClient.Credentials = New Net.NetworkCredential(Me.SmtpUsername, Me.SmtpPassword)

            mailClient.Send(myEmail)
        Catch ex As Exception
            WriteToLogs("Unable to send email: " & ex.Message, EventLogEntryType.Error, crmDataImporter.Business.Enums.EventId.GeneralError)
        End Try
    End Sub

    Public Sub AddJobToQueue(ByVal value As crmDataImporter.Business.Job)
        If Not value.Status = crmDataImporter.Business.Enums.JobStatus.Pending Then _
            Throw New Exception("Only jobs that are pending can be added to the queue")

        AddHandler value.ImportFinished, AddressOf ThreadEnd
        value.Status = crmDataImporter.Business.Enums.JobStatus.Queued
        'value.Save()
        _JobQueue.Add(value)
    End Sub

#End Region

#Region " IDisposable Support "

    Private disposedValue As Boolean = False        ' To detect redundant calls

    ' IDisposable
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        If Not Me.disposedValue Then

            If Not IsNothing(_watchTimer) Then _
                    _watchTimer.Dispose()
            If Not IsNothing(_queueTimer) Then _
                _queueTimer.Dispose()

        End If
        Me.disposedValue = True
    End Sub

    ' This code added by Visual Basic to correctly implement the disposable pattern.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub

#End Region

End Class
