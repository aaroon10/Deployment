Public Interface IMessageClient

    Sub Alert(ByVal message As String, ByVal type As Diagnostics.EventLogEntryType)

End Interface
