Public Class MessageServer
    Inherits MarshalByRefObject
    Implements IMessageServer

    Private _Clients As New List(Of IMessageClient)
    Private _LatestAlert As String
    Private _LatestAlertType As Diagnostics.EventLogEntryType

    Public Sub AddClient(ByVal client As IMessageClient) Implements IMessageServer.AddClient
        _Clients.Add(client)
    End Sub

    Public Sub RemoveClient(ByVal client As IMessageClient) Implements IMessageServer.RemoveClient
        _Clients.Remove(client)
    End Sub

    Public Sub SendMessage(ByVal message As String, ByVal type As Diagnostics.EventLogEntryType)
        _LatestAlert = message
        _LatestAlertType = type
        Me.AlertClients()
    End Sub

    Private Sub AlertClients() Implements IMessageServer.AlertClients
        For Each myClient As IMessageClient In _Clients
            Try
                myClient.Alert(_LatestAlert, _LatestAlertType)
            Catch : End Try
        Next
    End Sub

End Class
