Public Interface IMessageServer

    Sub AddClient(ByVal client As IMessageClient)
    Sub RemoveClient(ByVal client As IMessageClient)
    Sub AlertClients()

End Interface
