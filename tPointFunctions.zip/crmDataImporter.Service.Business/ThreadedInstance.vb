<Serializable()> _
Public Class ThreadedJob
    Inherits crmDataImporter.Business.Job

    Private _ThreadName As String

    Public Property ThreadName() As String
        Get
            Return _ThreadName
        End Get
        Set(ByVal value As String)
            _ThreadName = value
        End Set
    End Property

End Class