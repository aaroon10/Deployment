﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ApplicationBlocks.Data;
using crmFoundation;
using crmRepository;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;

namespace Workflow
{
    class WorkflowBase
    {
        private const string pluginName = "tpoint_v1";
        private const string csInsert = "Insert Component";
        private const string csUpdate = "Update Component";
        private const string csEmail = "Send Email";
        private const string csSMS = "Send SMS";
        private const string csDocument = "Create Document";
        //WR  21729 PJ + 25/05/15 Change Workflow to add / remove contacts to DXI 
        private const string csAddToDialler = "Add to Dialer";
        private const string csRemoveFromDialler = "Remove from Dialer";
        //WR  21729 PJ - Change Workflow to add / remove contacts to DXI 
        private const int ciActionStatusUnprocessed = 0;
        private const int ciActionStatusComplete = 2;
        private const int ciActionStatusError = 3;
        private const int ciActionStatusInvalid = 4;
        private enum SupportedDocumentTypes
        {
            doc,
            pdf
        }
        public bool DoProcessEscalations(string isConn, string isName, TraceWriter log)
        {
            try
            {
                SqlHelper.ExecuteNonQuery(isConn, CommandType.StoredProcedure, "w_workflowMonitor");
                log.Info("doProcessEscalations - Executing w_workflowMonitor - Conn String - " + isConn);
            }
            catch (Exception ex)
            {
                log.Error("doProcessEscalations - Error: " + ex.Message);
            }
            finally
            {
                log.Info("doProcessEscalations - Completed");
                //new Helper_Heartbeat(ServiceContext, AppContext).WriteBeat();
            }

            return true;
        }

        public bool DoCheckFutureActions(string isConn, TraceWriter log)
        {
            var lobjDR = default(SqlDataReader);
            var colParam = new SqlParameter[] { };

            try
            {
                lobjDR = SqlHelper.ExecuteReader(isConn, CommandType.StoredProcedure, "w_workflowGetUnprocessedFutureActions", colParam);

                log.Info("doCheckFutureActions - Get unprocessed future actions..");

                while (lobjDR.Read())
                {
                    var liActionId = Convert.ToInt32(lobjDR["Id"].ToString());

                    colParam = new SqlParameter[1];
                    colParam[0] = new SqlParameter("@intActionId", liActionId);

                    var lobjDRInsertUpdateCols = SqlHelper.ExecuteReader(isConn, CommandType.StoredProcedure, "w_workflowIsFutureActionValid", colParam);

                    if (!lobjDRInsertUpdateCols.Read()) continue;

                    var lbValid = Convert.ToBoolean(lobjDRInsertUpdateCols["Valid"]);
                    int liActionStatusId;

                    if (lbValid)
                    {
                        liActionStatusId = ciActionStatusUnprocessed;
                        log.Info("doCheckFutureActions - Action is still valid!");
                    }
                    else
                    {
                        liActionStatusId = ciActionStatusInvalid;
                        log.Info("doCheckFutureActions - Action is no longer valid!");
                    }

                    colParam[0] = new SqlParameter("@intActionId", liActionId);
                    colParam[1] = new SqlParameter("@intStatusId", liActionStatusId);

                    SqlHelper.ExecuteNonQuery(isConn, CommandType.StoredProcedure, "w_workflowSetFutureActionStatus", colParam);

                    log.Info("doCheckFutureActions - Set insert/update action status to " + liActionStatusId +
                             " - liActionId  = " + liActionId + " - Conn String = " + isConn);
                }
                lobjDR.Close();
            }
            catch (Exception ex)
            {
                if (lobjDR != null) lobjDR.Close();
                log.Error("doCheckFutureActions - Error: " + ex.Message);
            }
            finally
            {
                log.Info("doCheckFutureActions - Completed");
            }
            return true;
        }

        public bool DoProcessActions(string isConn, string isName, TraceWriter log, int iiBatchCnt)
        {
            var lobjDR = default(SqlDataReader);
            var lobjDRInsertUpdateCols = default(SqlDataReader);
            var colParam = new SqlParameter[3];
            var lsSQLTable = string.Empty;
            var lsSQLCols = string.Empty;
            var lsSQLValues = string.Empty;
            var EmailTemplateId = 0;
            var DocumentTemplateId = 0;
            var DocumentTitlePrefix = string.Empty;
            var DocumentExtension = string.Empty;
            var DocumentAuthorisedForRelease = 0;
            var AttachmentParentId = 0;
            var AttachmentParentTable = string.Empty;
            var app = new clsApplication { strConn = isConn };
            var lsUpdatedBy = app.getAppSetting("WFUser");
            var lsRecordId = 0;
            var lsValue = string.Empty;

            // dw 10-3-13 Introduced safer parsing MOVED above original declare for //WR  21729 PJ + 25/05/15 Change Workflow to add / remove contacts to DXI 
            var liBusCompId = 0;
            var liCreatedBy = 0;
            var liUpdatedBy = 0;

            if (string.IsNullOrEmpty(lsUpdatedBy))
                lsUpdatedBy = "0";

            try
            {
                colParam = new SqlParameter[1];
                colParam[0] = new SqlParameter("@batchCnt", iiBatchCnt);
                lobjDR = SqlHelper.ExecuteReader(isConn, CommandType.StoredProcedure, "w_workflowGetUnprocessedActions", colParam);
                log.Info("doProcessActions - Get unprocessed actions..");

                while (lobjDR.Read())
                {
                    var liActionId = Convert.ToInt32(lobjDR["Id"].ToString());
                    var lsActionType = lobjDR["actionType"].ToString();
                    bool error = false;

                    colParam = new SqlParameter[1];
                    colParam[0] = new SqlParameter("@intActionId", liActionId);
                    lobjDRInsertUpdateCols = SqlHelper.ExecuteReader(isConn, CommandType.StoredProcedure, "w_workflowGetActionInsertUpdate", colParam);

                    log.Info("doProcessActions - Get cols");

                    while (lobjDRInsertUpdateCols.Read())
                    {
                        // lsRecordId = Convert.ToInt32(lobjDRInsertUpdateCols["recordId"]);

                        //    if (!string.IsNullOrEmpty(lobjDRInsertUpdateCols["attachmentParentId"].ToString())!=null)

                        // dw 10-3-13 Introduced safer parsing MOVED above original declare for //WR  21729 PJ + 25/05/15 Change Workflow to add / remove contacts to DXI (see above)
                        //var liBusCompId = 0;
                        //var liCreatedBy = 0;
                        //var liUpdatedBy = 0;

                        int.TryParse(lobjDRInsertUpdateCols["recordId"].ToString(), out lsRecordId);
                        int.TryParse(lobjDRInsertUpdateCols["attachmentParentId"].ToString(), out AttachmentParentId);
                        int.TryParse(lobjDRInsertUpdateCols["busCompId"].ToString(), out liBusCompId);
                        int.TryParse(lobjDRInsertUpdateCols["createdBy"].ToString(), out liCreatedBy);
                        int.TryParse(lobjDRInsertUpdateCols["updatedBy"].ToString(), out liUpdatedBy);


                        //   var liBusCompId = Convert.ToInt32(lobjDRInsertUpdateCols["busCompId"]);
                        //   var liCreatedBy = Convert.ToInt32(lobjDRInsertUpdateCols["createdBy"]);
                        //    var liUpdatedBy = Convert.ToInt32(lobjDRInsertUpdateCols["updatedBy"]);

                        //     var recordHelper = new Helper_Record(ServiceContext, AppContext, liBusCompId, lsRecordId);

                        // Do we have an email template id?
                        if ((lobjDRInsertUpdateCols["colname"].ToString().ToLower() == "attint05"))
                        {
                            // int.TryParse(recordHelper.GetFieldValue(lobjDRInsertUpdateCols["value"].ToString()),out EmailTemplateId); // restored original Code! 7-10-13
                            int.TryParse(lobjDRInsertUpdateCols["value"].ToString(), out EmailTemplateId);
                            log.Info("Action Id: " + liActionId + ". Setting email 'template id' to:" + EmailTemplateId);
                        }

                        // Do we have an document template id?
                        if ((lobjDRInsertUpdateCols["colname"].ToString().ToLower() == "attnum01"))
                        {
                            // int.TryParse(recordHelper.GetFieldValue(lobjDRInsertUpdateCols["colname"].ToString()), out DocumentTemplateId);// restored original Code! 7-10-13
                            //int.TryParse(lobjDRInsertUpdateCols["value"].ToString(), out DocumentTemplateId);//--- PJ Removed in favour of wrapping parseFieldValue (below) 

                            int.TryParse(ParseFieldValue(isConn, lobjDRInsertUpdateCols["value"].ToString(), lsRecordId, liBusCompId, liCreatedBy, liUpdatedBy, log), out DocumentTemplateId);
                            log.Info("Action Id: " + liActionId + ". Setting document 'template id' to:" +
                                      DocumentTemplateId);
                        }

                        // Is the document Authorised for Release?
                        if ((lobjDRInsertUpdateCols["colname"].ToString().ToLower() == "attnum02"))
                        {
                            //  int.TryParse(recordHelper.GetFieldValue(lobjDRInsertUpdateCols["value"].ToString()), out DocumentAuthorisedForRelease);// restored original Code! 7-10-13
                            int.TryParse(lobjDRInsertUpdateCols["value"].ToString(), out DocumentAuthorisedForRelease);

                            log.Info("Action Id: " + liActionId + ". Authorised for Release: " +
                                      DocumentAuthorisedForRelease);
                        }

                        //// Is the u_attachment ParentId defined?
                        //if ((lobjDRInsertUpdateCols["colname"].ToString().ToLower() == "attnum03"))
                        //{
                        //    // int.TryParse(recordHelper.GetFieldValue(lobjDRInsertUpdateCols["value"].ToString()),out DocumentAuthorisedForRelease);
                        //    int.TryParse(lobjDRInsertUpdateCols["value"].ToString(), out AttachmentParentId);

                        //    log.Debug("Action Id: " + liActionId + ". u_attachment Parent Id: " +
                        //              AttachmentParentId);
                        //}

                        // If we are creating a document try to get the Title Prefix and Extension.
                        if (lsActionType == csDocument)
                        {
                            if ((lobjDRInsertUpdateCols["colname"].ToString().ToLower() == "title"))
                            {
                                //  DocumentTitlePrefix = recordHelper.GetFieldValue(lobjDRInsertUpdateCols["value"].ToString());// restored original Code! 7-10-13
                                DocumentTitlePrefix = lobjDRInsertUpdateCols["value"].ToString();

                                log.Info("Action Id: " + liActionId + ". Setting document 'title prefix' to:" +
                                          DocumentTitlePrefix);
                            }

                            if ((lobjDRInsertUpdateCols["colname"].ToString().ToLower() == "atttxt50"))
                            {
                                // DocumentExtension = recordHelper.GetFieldValue(lobjDRInsertUpdateCols["value"].ToString());// restored original Code! 7-10-13
                                DocumentExtension = lobjDRInsertUpdateCols["value"].ToString();
                                log.Info("Action Id: " + liActionId + ". Setting document 'extension' prefix to:" +
                                          DocumentExtension);
                            }

                            if ((lobjDRInsertUpdateCols["colname"].ToString().ToLower() == "atttxt51"))
                            {
                                //  AttachmentParentTable = recordHelper.GetFieldValue(lobjDRInsertUpdateCols["value"].ToString());// restored original Code! 7-10-13
                                AttachmentParentTable = lobjDRInsertUpdateCols["value"].ToString();
                                log.Info("Action Id: " + liActionId + ". Setting document u_attachment Parent Table:" +
                                          DocumentExtension);
                            }
                        }

                        if (string.IsNullOrEmpty(lsSQLTable))
                            lsSQLTable = lobjDRInsertUpdateCols["tableName"].ToString();

                        switch (lsActionType)
                        {
                            case csUpdate:

                                lsValue = ParseFieldValue(isConn, lobjDRInsertUpdateCols["value"].ToString(),
                                    lsRecordId, liBusCompId, liCreatedBy,
                                    liUpdatedBy, log);

                                var lobjWorkOrder = new clsComponent(isConn, Convert.ToInt32(lsUpdatedBy), liBusCompId, "", false)
                                {
                                    recordId = lsRecordId
                                };
                                lobjWorkOrder.addField("id");
                                lobjWorkOrder.addField(lobjDRInsertUpdateCols["busCompFieldName"].ToString());
                                lobjWorkOrder.setSQL();
                                lobjWorkOrder.getRecord();

                                //setFld("updatedBy", lsUpdatedBy, lobjWorkOrder.fields);
                                lobjWorkOrder.fields.get_itemFromColumn(lobjDRInsertUpdateCols["colName"].ToString()).
                                    oldValue =
                                    lobjWorkOrder.fields.get_itemFromColumn(lobjDRInsertUpdateCols["colName"].ToString())
                                        .value;
                                SetFld(lobjDRInsertUpdateCols["colName"].ToString(), lsValue, lobjWorkOrder.fields, log);
                                lobjWorkOrder.auditChanges = true;
                                lobjWorkOrder.updateRecord();

                                break;


                            case csInsert:
                            case csEmail:
                            case csSMS:
                            case csAddToDialler: //WR  21729 PJ + 25/05/15 Change Workflow to add / remove contacts to DXI Added Cases for Add & remove Dialler
                            case csRemoveFromDialler:

                                lsSQLCols += lobjDRInsertUpdateCols["colName"] + ", ";

                                if ((lobjDRInsertUpdateCols["colName"].ToString().ToLower() == "notes" &
                                     EmailTemplateId > 0))
                                {
                                    //TODO
                                    //var templateHelper = new Helper_EmailTemplates(ServiceContext, AppContext,
                                    //    EmailTemplateId, lsRecordId);

                                    //lsValue = templateHelper.GetDerivedTemplateData();
                                }
                                else
                                {
                                    lsValue = ParseFieldValue(isConn, (string)lobjDRInsertUpdateCols["value"],
                                        lsRecordId, liBusCompId, liCreatedBy,
                                        liUpdatedBy, log);
                                }

                                if (lobjDRInsertUpdateCols["colType"].ToString().ToLower().Contains("char") |
                                    lobjDRInsertUpdateCols["colType"].ToString().ToLower().Contains("text") |
                                    lobjDRInsertUpdateCols["colType"].ToString().ToLower().Contains("date"))
                                {
                                    lsSQLValues += "'" + lsValue.Replace("'", "''") + "', ";
                                }
                                else
                                {
                                    lsSQLValues += lsValue + ", ";
                                }

                                break;
                        }
                    }

                    lobjDRInsertUpdateCols.Close();

                    switch (lsActionType)
                    {
                        case csUpdate:
                            log.Info("doProcessActions:Update action processed - ActionId " + liActionId +
                                     " - Conn String - " + isConn);
                            lsSQLTable = "";

                            break;

                        case csInsert:
                        case csEmail:
                        case csSMS:
                        case csAddToDialler:
                        case csRemoveFromDialler:

                            //WR  21729 PJ + 25/05/15 Change Workflow to add / remove contacts to DXI
                            //Dialler Block to add actioin some defaults, could do this in the table but probably better here
                            if (lsActionType == csAddToDialler || lsActionType == csRemoveFromDialler)
                            {
                                //Add Contact ID
                                lsSQLCols += "[ContactId], ";
                                lsSQLValues += ParseFieldValue(isConn, "[record].[Id]",
                                       lsRecordId, liBusCompId, liCreatedBy,
                                       liUpdatedBy, log) + ", ";

                                //add action
                                lsSQLCols += "action, ";
                                //Action = import
                                if (lsActionType == csAddToDialler)
                                { lsSQLValues += "'import', "; }
                                else
                                { lsSQLValues += "'delete', "; }
                            }
                            //WR  21729 PJ - 25/05/15 Change Workflow to add / remove contacts to DXI

                            if (!lsSQLCols.Contains("updatedBy"))
                            {
                                lsSQLCols += "updatedBy";
                                lsSQLValues += lsUpdatedBy;
                            }

                            colParam = new SqlParameter[1];

                            var lsSQLInsert = "INSERT INTO " + lsSQLTable + " (" + lsSQLCols + ") VALUES (" + lsSQLValues + ")";

                            colParam[0] = new SqlParameter("@stmt", lsSQLInsert);

                            SqlHelper.ExecuteNonQuery(isConn, CommandType.StoredProcedure, "sp_executesql", colParam);

                            log.Info("doProcessActions - Insert action processed - ActionId " + liActionId + " - Conn String - " + isConn);

                            lsSQLTable = "";
                            lsSQLCols = "";
                            lsSQLValues = "";

                            break;

                        case csDocument:

                            var authorized = DocumentAuthorisedForRelease > 0;

                            if (lsRecordId > 0)
                            {
                                var notes = "Created via Workflow Action ID: " + liActionId + " & Template ID:" + DocumentTemplateId;
                                var documentType = SupportedDocumentTypes.doc;

                                switch (DocumentExtension.ToLower().Trim())
                                {
                                    case "doc":
                                        documentType = SupportedDocumentTypes.doc;
                                        break;

                                    case "pdf":
                                        documentType = SupportedDocumentTypes.pdf;
                                        break;
                                }

                                log.Info("Starting Document Helper:");
                                log.Info("Template Id:" + DocumentTemplateId);
                                log.Info("Record Id:" + lsRecordId);
                                log.Info("Document Title Prefix:" + DocumentTitlePrefix);
                                log.Info("Document Type:" + documentType);
                                log.Info("Authorised for Release:" + authorized);
                                log.Info("u_attachment Parent Id:" + AttachmentParentId);
                                log.Info("u_attachment Parent Table:" + AttachmentParentTable);

                                try
                                {
                                    //new Helper_Document(ServiceContext, AppContext).CreateDocument
                                    //(DocumentTemplateId, lsRecordId, AttachmentParentId,
                                    //AttachmentParentTable, authorized, DocumentTitlePrefix,
                                    //documentType, notes);
                                }
                                catch (Exception ex)
                                {
                                    log.Error(ex.ToString());
                                    error = true;
                                }

                                // DT WR19860 - Tidy up after doing document, as u_document gets stuck as the table
                                lsSQLTable = "";
                                lsSQLCols = "";
                                lsSQLValues = "";
                            }

                            break;
                    }

                    colParam = new SqlParameter[2];

                    colParam[0] = new SqlParameter("@intActionId", liActionId);

                    if (error)
                    {
                        colParam[1] = new SqlParameter("@intStatusId", ciActionStatusError);
                        log.Info("doProcessActions - Setting insert/update action status to 'error' - liActionId = " + liActionId + " - Conn String = " + isConn);
                    }
                    else
                    {
                        colParam[1] = new SqlParameter("@intStatusId", ciActionStatusComplete);
                        log.Info("doProcessActions - Setting insert/update action status to 'processed' - liActionId = " + liActionId + " - Conn String = " + isConn);
                    }

                    
                    SqlHelper.ExecuteNonQuery(isConn, CommandType.StoredProcedure, "w_workflowSetActionStatus", colParam);

                    log.Info("doProcessActions -  action status inserted/updated - liActionId = " + liActionId + " - Conn String = " + isConn);
                }

                lobjDR.Close();
            }
            catch (Exception ex)
            {
                lobjDRInsertUpdateCols.Close();
                lobjDR.Close();

                log.Error("doProcessActions - Error: " + ex.Message);
            }
            finally
            {
                log.Info("doProcessActions - Completed");
                //new Helper_Heartbeat(ServiceContext, AppContext).WriteBeat();
            }

            return true;
        }

        private static string ParseFieldValue(string isConn, string isValue, int iiRecordId, int iiBusCompId, int iiCreatedBy, int iiUpdatedBy, TraceWriter log)
        {
            string functionReturnValue;
            string lsparseFieldValueResult = isValue;

            try
            {
                if (isValue.Contains("[record]"))
                {
                    var objBC = new clsComponent(isConn, 0, iiBusCompId) { recordId = iiRecordId };

                    objBC.getRecord();

                    foreach (clsComponentField objfld in objBC.fields)
                    {
                        if (objfld != null)
                        {
                            try
                            {
                                lsparseFieldValueResult =
                                    lsparseFieldValueResult.Replace("[record].[" + objfld.name + "]",
                                        objfld.value.ToString());
                            }
                            catch (Exception ex)
                            {
                                log.Info("Field" + objfld.name + "has no value!"); // Commented as logs 100's of bug all the time.
                            }
                        }
                    }
                }

                if (isValue.Contains("[application]"))
                {
                    var objApp = new clsApplication();
                    string lsStringToParse = lsparseFieldValueResult;

                    int liPos = lsStringToParse.IndexOf("[application].[", StringComparison.Ordinal);

                    if (liPos > 0)
                    {
                        lsStringToParse.Substring(liPos + 15);
                    }

                    string lsParsedName = lsStringToParse.Substring(1, lsStringToParse.IndexOf("]") - 1);

                    while (liPos > 0)
                    {
                        objApp.strConn = isConn;
                        string lsParsedValue = objApp.getAppSetting(lsParsedName);
                        lsparseFieldValueResult = lsparseFieldValueResult.Replace(
                            "[application].[" + lsParsedName + "]", lsParsedValue);
                        liPos = lsStringToParse.IndexOf("[application].[");
                        if (liPos > 0)
                        {
                            lsStringToParse = lsStringToParse.Substring(liPos + 15);
                        }

                        lsParsedName = lsStringToParse.Substring(1, lsStringToParse.IndexOf("]") - 1);
                    }
                }

                if (isValue.Contains("[createdby]"))
                {
                    var objBC = new clsComponent(isConn, 0, 0, "Admin - Employee") { recordId = iiCreatedBy };

                    objBC.getRecord();

                    foreach (clsComponentField objfld in objBC.fields)
                    {
                        lsparseFieldValueResult = lsparseFieldValueResult.Replace("[createdby].[" + objfld.name + "]",
                            objfld.value.ToString());
                    }
                }

                if (isValue.IndexOf("[updatedby]") > 0)
                {
                    var objBC = new clsComponent(isConn, 0, 0, "Admin - Employee") { recordId = iiUpdatedBy };

                    objBC.getRecord();

                    foreach (clsComponentField objfld in objBC.fields)
                    {
                        lsparseFieldValueResult = lsparseFieldValueResult.Replace("[updatedby].[" + objfld.name + "]",
                            objfld.value.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                log.Error("parseFieldValue - Error: " + ex.Message + " Value: " + isValue);
            }
            finally
            {
                functionReturnValue = lsparseFieldValueResult;
            }

            return functionReturnValue;
        }

        private static string GetFieldValue(string fieldName, int componentId, int recordId, string isSourceDb)
        {
            var objBC = new clsComponent(isSourceDb, 0, componentId) { recordId = recordId };
            objBC.getRecord();

            if (objBC.fields[fieldName].value != null)
            {
                if (objBC.fields[fieldName].value.ToString().Length > 0)
                {
                    return objBC.fields[fieldName].value.ToString();
                }
            }

            return string.Empty;
        }

        private static void SetFld(string name, object value, componentFieldCollection fields, TraceWriter log)
        {
            try
            {
                if ((fields.get_itemFromColumn(name.ToUpper())).oldValue == null)
                    fields.get_itemFromColumn(name.ToUpper()).oldValue =
                        fields.get_itemFromColumn(name.ToUpper()).value == value;

                fields.get_itemFromColumn(name.ToUpper()).value = value;
                fields.get_itemFromColumn(name.ToUpper()).changed = true;
            }
            catch (Exception ex)
            {
                log.Error("setFld - Error: Field: " + name + "Value: " + value + " - " + ex.Message);
            }
        }
    }
}
