using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using System.Configuration;

namespace Workflow
{
    public static class WorkflowBaseDev
    {
        [Disable]
        [FunctionName("WorkflowBaseDev")]
        public static void Run([TimerTrigger("*/10 * * * * *")]TimerInfo myTimer, TraceWriter log, ExecutionContext context) //Poll every 1 seconds
        {
            if (Boolean.Parse(ConfigurationManager.AppSettings[context.FunctionName + "On"]))
            {
                string lsSourceDB = ConfigurationManager.AppSettings[context.FunctionName + "Conn"];

                var lobjWorkflowBase = new Workflow.WorkflowBase();
                lobjWorkflowBase.DoProcessEscalations(lsSourceDB, context.FunctionName, log);
                //lobjWorkflowBase.DoCheckFutureActions(lsSourceDB, log);
                lobjWorkflowBase.DoProcessActions(lsSourceDB, context.FunctionName, log, int.Parse(ConfigurationManager.AppSettings[context.FunctionName + "BatchCount"]));
            }
        }
    }
}
