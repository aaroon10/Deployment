using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Microsoft.ApplicationBlocks.Data;
using crmFoundation;
using crmRepository;

namespace tPointFunctions
{
    public static class WorkflowAll
    {

        [Disable]
        [FunctionName("WorflowAll")]
        public static void Run([TimerTrigger("0 */1 * * * *")]TimerInfo myTimer, TraceWriter log)
        {
            try
            {
                //TraceWriter mlog = log;
                var lobjDR = default(SqlDataReader);
                //var colParam = new SqlParameter[3];
                string lsSourceDB = "", lsName = "";
                //string lsMasterListConn = ConfigurationManager.AppSettings["MasterlistConn"];
                var lsMasterListConn = "Server=tcp:tpointdev.database.windows.net,1433;Initial Catalog=tPointMasterlist;Persist Security Info=False;User ID=tpointdba;Password=#!sJtqpp!D6C5!7g;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

                lobjDR = SqlHelper.ExecuteReader(lsMasterListConn, CommandType.StoredProcedure, "[listDBsThatHave_Workflow]"); //, colParam);
                log.Info("Get list of instances to check.");

                while (lobjDR.Read())
                {
                    lsSourceDB = lobjDR["sourceDB"].ToString();
                    lsName = lobjDR["name"].ToString();

                    var lobjWorkflowBase = new Workflow.WorkflowBase();
                    lobjWorkflowBase.DoProcessEscalations(lsSourceDB, lsName, log);
                    //lobjWorkflowBase.DoCheckFutureActions(lsSourceDB, log);
                    lobjWorkflowBase.DoProcessActions(lsSourceDB, lsName, log, 100);
                }
                lobjDR.Close();

                log.Info($"C# Timer trigger function executed at: {DateTime.Now}");
            }
            catch (Exception ex)
            {
                log.Error(ex.ToString());
            }
        }

    }
}
