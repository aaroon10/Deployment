/****** Object:  Table [dbo].[g_workflowEscalations_archive]    Script Date: 05/09/2018 16:06:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[g_workflowEscalations_archive](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[archiveDate] [datetime] NOT NULL,
	[created] [datetime] NOT NULL,
	[createdBy] [int] NOT NULL,
	[updated] [datetime] NOT NULL,
	[updatedBy] [int] NOT NULL,
	[escalationDate] [datetime] NULL,
	[workflowPolicyId] [int] NOT NULL,
	[recordId] [int] NULL,
	[statusId] [int] NOT NULL,
	[recycledFlag] [bit] NOT NULL,
	[hardDeletedFlag] [bit] NOT NULL,
	[attachmentParentId] [int] NULL,
	[scheduleBatchId] [uniqueidentifier] NULL,
 CONSTRAINT [PK_g_workflowEscalations_archive] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[g_workflowEscalations_archive] ADD  CONSTRAINT [DF_g_workflowEscalations_archive_archiveDate]  DEFAULT (getdate()) FOR [archiveDate]
GO

ALTER TABLE [dbo].[g_workflowEscalations_archive] ADD  CONSTRAINT [DF_g_workflowEscalations_archive_created]  DEFAULT (getdate()) FOR [created]
GO

ALTER TABLE [dbo].[g_workflowEscalations_archive] ADD  CONSTRAINT [DF_g_workflowEscalations_archive_createdBy]  DEFAULT ((0)) FOR [createdBy]
GO

ALTER TABLE [dbo].[g_workflowEscalations_archive] ADD  CONSTRAINT [DF_g_workflowEscalations_archive_updated]  DEFAULT (getdate()) FOR [updated]
GO

ALTER TABLE [dbo].[g_workflowEscalations_archive] ADD  CONSTRAINT [DF_g_workflowEscalations_archive_updatedBy]  DEFAULT ((0)) FOR [updatedBy]
GO

ALTER TABLE [dbo].[g_workflowEscalations_archive] ADD  CONSTRAINT [DF_g_workflowEscalations_archive_recycledFlag]  DEFAULT ((0)) FOR [recycledFlag]
GO

ALTER TABLE [dbo].[g_workflowEscalations_archive] ADD  CONSTRAINT [DF_g_workflowEscalations_archive_hardDeletedFlag]  DEFAULT ((0)) FOR [hardDeletedFlag]
GO


