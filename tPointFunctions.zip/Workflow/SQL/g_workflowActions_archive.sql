/****** Object:  Table [dbo].[g_workflowActions_archive]    Script Date: 05/09/2018 16:07:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[g_workflowActions_archive](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[archiveDate] [datetime] NOT NULL,
	[created] [datetime] NOT NULL,
	[createdBy] [int] NOT NULL,
	[updated] [datetime] NOT NULL,
	[updatedBy] [int] NOT NULL,
	[recordId] [int] NULL,
	[policyActionId] [int] NULL,
	[actionType] [nvarchar](50) NULL,
	[statusId] [int] NOT NULL,
	[actionDate] [datetime] NULL,
	[recycledFlag] [bit] NOT NULL,
	[hardDeletedFlag] [bit] NOT NULL,
	[attachmentParentId] [int] NULL,
 CONSTRAINT [PK_g_workflowActions_archive] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[g_workflowActions_archive] ADD  CONSTRAINT [DF_g_workflowActions_archive_archiveDate]  DEFAULT (getdate()) FOR [archiveDate]
GO

ALTER TABLE [dbo].[g_workflowActions_archive] ADD  CONSTRAINT [DF_g_workflowActions_archive_created_1]  DEFAULT (getdate()) FOR [created]
GO

ALTER TABLE [dbo].[g_workflowActions_archive] ADD  CONSTRAINT [DF_g_workflowActions_archive_createdBy]  DEFAULT ((0)) FOR [createdBy]
GO

ALTER TABLE [dbo].[g_workflowActions_archive] ADD  CONSTRAINT [DF_g_workflowActions_archive_updated_1]  DEFAULT (getdate()) FOR [updated]
GO

ALTER TABLE [dbo].[g_workflowActions_archive] ADD  CONSTRAINT [DF_g_workflowActions_archive_updatedBy]  DEFAULT ((0)) FOR [updatedBy]
GO

ALTER TABLE [dbo].[g_workflowActions_archive] ADD  CONSTRAINT [DF_g_workflowActions_archive_recycledFlag]  DEFAULT ((0)) FOR [recycledFlag]
GO

ALTER TABLE [dbo].[g_workflowActions_archive] ADD  CONSTRAINT [DF_g_workflowActions_archive_hardDeletedFlag]  DEFAULT ((0)) FOR [hardDeletedFlag]
GO


