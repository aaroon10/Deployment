/****** Object:  StoredProcedure [dbo].[w_workflowGetUnprocessedActions]    Script Date: 05/09/2018 14:07:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[w_workflowGetUnprocessedActions]

  @batchCnt as int = 10

AS

  WITH cte AS (
      SELECT TOP(@batchCnt) Id, statusId, actionType
      FROM g_workflowActions WITH (ROWLOCK, READPAST)
	  WHERE statusId = 0
      AND actionDate < GETDATE()
      ORDER BY Id)
	UPDATE cte
	SET statusId = 1
	OUTPUT deleted.id, deleted.actionType
GO


