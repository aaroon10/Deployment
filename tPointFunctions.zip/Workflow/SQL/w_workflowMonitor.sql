/****** Object:  StoredProcedure [dbo].[w_workflowMonitor]    Script Date: 05/09/2018 15:02:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[w_workflowMonitor]

@batchCnt int = 10

AS

  WITH cte AS (  
	SELECT TOP(@batchCnt) esc.statusId, esc.created, esc.createdBy, esc.updated, esc.updatedBy, esc.recordId, 
	                      a.id, a.actionType, 0 [actionStatusId], dateadd(day, a.escalationDays, esc.escalationDate) [escDate]
	FROM g_workflowEscalations esc WITH (ROWLOCK, READPAST) INNER JOIN
         g_workflowPolicyActions a ON esc.workflowPolicyId = a.workflowPolicyId
    WHERE esc.statusId = 0)
	UPDATE cte
	SET statusId = 1
	OUTPUT deleted.created, deleted.createdBy, deleted.updated, deleted.updatedBy, deleted.recordId, deleted.id, deleted.actionType, deleted.[actionStatusId], deleted.[escDate] 
	INTO g_workflowActions (created, createdBy, updated, updatedBy, recordId, policyActionId, actionType, statusId, actionDate)

  DELETE g_workflowEscalations WITH (ROWLOCK, READPAST)
  OUTPUT deleted.[created], deleted.[createdBy], deleted.[updated], deleted.[updatedBy], deleted.[escalationDate], deleted.[workflowPolicyId], deleted.[recordId], 2, deleted.[recycledFlag], deleted.[hardDeletedFlag], deleted.[attachmentParentId], deleted.[scheduleBatchId]
  INTO g_workflowEscalations_archive ([created], [createdBy],	[updated], [updatedBy],	[escalationDate], [workflowPolicyId], [recordId], [statusId], [recycledFlag], [hardDeletedFlag], [attachmentParentId], [scheduleBatchId])
  WHERE statusId = 1





