/****** Object:  StoredProcedure [dbo].[w_workflowSetActionStatus]    Script Date: 05/09/2018 14:20:48 ******/
SET ANSI_NULLS OFF
GO

SET QUOTED_IDENTIFIER OFF
GO

CREATE PROCEDURE [dbo].[w_workflowSetActionStatus]

@intActionId int,
@intStatusId int

AS

UPDATE g_workflowActions
SET statusId = @intStatusId
FROM g_workflowActions
WHERE statusId = 1
AND Id = @intActionId
AND (actionDate < GETDATE())

insert into g_workflowActions_archive ([created], [createdBy], [updated], [updatedBy], [recordId], [policyActionId], [actionType], [statusId], [actionDate], [recycledFlag], [hardDeletedFlag],	[attachmentParentId])
select [created], [createdBy], [updated], [updatedBy], [recordId], [policyActionId], [actionType], [statusId], [actionDate], [recycledFlag], [hardDeletedFlag],	[attachmentParentId]
from g_workflowActions
where statusId >= 2
and Id = @intActionId
GO


